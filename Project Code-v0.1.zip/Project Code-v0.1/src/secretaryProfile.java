import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class secretaryProfile extends JFrame{
    private JPanel profilePanel;
    private JTextField nameField;
    private JTextField emailField;
    private JTextField usernameField;
    private JTextField typeField;
    private JButton uploadButton;
    private JButton saveButton;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JLabel imagePhoto;
    private JLabel confirmLabel;
    private User user;
    public String uploadedPhotoName;
    public byte[] uploadedPhotoContent;


    public secretaryProfile(JFrame parent, User user) {
        this.user = user;
        setTitle("My Profile");
        setContentPane(profilePanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new secretaryHome(null, user);
            }
        });




    }


}

