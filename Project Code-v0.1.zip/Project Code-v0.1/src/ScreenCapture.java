public class ScreenCapture {
}
