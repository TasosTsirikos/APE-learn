import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class userSubjectProfile extends JFrame{

    private JLabel titleLabel;
    private JLabel infoLabel1;
    private JLabel infoLabel2;
    private JPanel userSubjectProfile;
    private JToolBar jToolBarStudent;
    private JLabel markLabel;
    private JLabel ectsField;
    private JLabel bookField;
    private User user;


    public userSubjectProfile(JFrame parent, User user, String id) {
        this.user = user;

        setTitle("Subject Details");
        setContentPane(userSubjectProfile);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);


        displaySubjectInfo(id);

        JButton seeLectures = new JButton("Lectures");
        JButton seeMarks = new JButton("Grades");
        JButton seeBooks = new JButton("Books");
        JButton projects = new JButton("Projects");
        JButton myTeam = new JButton("My Team");
        JButton attend = new JButton("Attend to Lecture");
        JButton unregister = new JButton("Unregister");


        jToolBarStudent.add(seeLectures);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(seeMarks);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(seeBooks);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(projects);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(myTeam);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(attend);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(unregister);

        seeBooks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                try {
                    new studentSelectBook(null, user, id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        projects.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentSubjectProjects(null, user, id);
            }
        });

        myTeam.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentFindsTeam(null, user, id);
            }
        });

        seeMarks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentSeeMarks(null, user, id);
            }
        });

        seeLectures.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentSeeLectures(null, user, id);
            }
        });

        attend.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new testStudentAttend(null, user, id);
            }
        });



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });
        setVisible(true);
    }

    public void displaySubjectInfo(String id) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        // SQL query to retrieve subject information
        String query = "SELECT subject_name, subject_description, teacher, grade, type, ects FROM my_subjects WHERE id_subject = ?";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Set the parameter (id)
            preparedStatement.setString(1, id);

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();


            // Check if a record is found
            if (resultSet.next()) {
                String subjectName = resultSet.getString("subject_name");
                String subjectDescription = resultSet.getString("subject_description");
                String teacher = resultSet.getString("teacher");
                String type = resultSet.getString("type");
                int mark = resultSet.getInt("grade");
                int ects = resultSet.getInt("ects");

                // Format the information
                String subjectTitleText = id + ": " + subjectName + " (" + type + ")";
                String teacherFieldText = "Professor: " + teacher;
                String infoTextField = "Info: " + subjectDescription;
                String ectsText = "Ects: " + String.valueOf(ects);


                // Set the text to the components
                titleLabel.setText(subjectTitleText);
                infoLabel1.setText(teacherFieldText);
                infoLabel2.setText(infoTextField);
                ectsField.setText(ectsText);

                if (mark == -1){
                    String grade = " ";
                    String markField = "Mark: " + grade;
                    markLabel.setText(markField);
                }
                else{
                    int grade = mark;
                    String markField = "Mark: " + grade;
                    markLabel.setText(markField);
                }

            } else {
                // No record found for the given ID
                JOptionPane.showMessageDialog(this, "Subject not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Example usage:
    public static void main(String[] args) {
    }
}

