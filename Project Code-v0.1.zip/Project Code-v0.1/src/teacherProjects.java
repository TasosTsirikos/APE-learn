import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class teacherProjects extends JFrame{
    private JTextField titleField;
    private JTextField deadlineField;
    private JButton uploadButton;
    private JButton submitButton;
    private JTable projectsTable;
    private JPanel teacherProject;
    private JLabel titleProjects;
    private User user;
    private String subjectName;

    public teacherProjects(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);
        setTitle("My Lectures");
        setContentPane(teacherProject);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        titleProjects.setText("Projects for " + subjectName);


        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherSubjectProfile(null, user, id);
            }
        });

        setVisible(true);
    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }
}
