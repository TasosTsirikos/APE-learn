import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;


public class teacherLectures extends JFrame {
    private JTextField dateField;
    private JTable tableLectures;
    private JLabel blobArchive;
    private JLabel topLabel;
    private JPanel lecturesPanel;
    private JButton uploadButton;
    private JButton submitButton;
    private JScrollPane scrollPanel;
    private JButton deleteButton;
    private JButton searchButton;
    private User user;
    private String subjectName;

    public teacherLectures(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);
        setTitle("My Lectures");
        setContentPane(lecturesPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherSubjectProfile(null, user, id);
            }
        });



        topLabel.setText(topLabel.getText() + " " + subjectName);

        String[] columnNames = {"Date", "Archive"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) tableLectures.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < tableLectures.getColumnCount(); i++) {
            Class<?> columnClass = tableLectures.getColumnClass(i);
            tableLectures.setDefaultEditor(columnClass, null);
        }



    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }


}