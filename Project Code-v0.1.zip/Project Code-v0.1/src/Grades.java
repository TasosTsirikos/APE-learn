public class Grades {
    public String subject_id;
    public String subject_name;
    public String teacher;
    public String student;
    public String date;
    public double mark;
    public int student_id;
    public int idgrades;

    public int getId() {
        return idgrades;
    }
    public int getStudentId() {
        return student_id;
    }
    public String getStudentName() {
        return student;
    }
    public String getTeacher() {
        return teacher;
    }
    public String getSubjectName() {
        return subject_name;
    }
    public String getDate() {
        return date;
    }
    public double getMark() {
        return mark;
    }
    public String getSubjectId() {
        return subject_id;
    }

}
