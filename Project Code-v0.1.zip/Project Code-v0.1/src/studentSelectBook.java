import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class studentSelectBook extends JFrame{
    private JPanel bookPanel;
    private JTextField authorField;
    private JTextField isbnField;
    private JButton searchButton;
    private JTable bookTable;
    private JScrollPane tableBookPanel;
    private JButton selectButton;
    private JLabel titleField;
    private User user;


    public studentSelectBook(JFrame parent, User user, String id) throws SQLException {
        this.user = user;

        setTitle("Select a Book");
        setContentPane(bookPanel);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        DefaultTableModel model = new DefaultTableModel(new Object[]{"ISBN", "Author", "Book Name"}, 0);
        bookTable.setModel(model);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);
            }
        });

        String subjectName = showTitle(id);
        if (subjectName != null) {
            titleField.setText("Select Book for " + subjectName);
        } else {
            titleField.setText("Select Book");
        }




        setVisible(true);
    }

    private String showTitle(String id) throws SQLException {
        String subjectName = null;
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {

            // Prepare SQL statement
            String sql = "SELECT subject_name FROM subjects WHERE idsubjects = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, id);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQLException
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();

            }
        }

        return subjectName;
    }



}

