public class Camera {
}
