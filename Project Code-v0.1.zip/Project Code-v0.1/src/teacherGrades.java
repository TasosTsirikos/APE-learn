import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

public class teacherGrades extends JFrame{
    private JTextField idField;
    private JTextField writtenType;
    private JTextField writtenPer;
    private JTextField project1;
    private JTextField project1Per;
    private JTextField project2;
    private JTextField project2Per;
    private JButton addGradeButton;
    private JPanel gradePanel;
    private JTable gradeTable;
    private JLabel Labell;
    private JLabel addExam;
    private JLabel resultLabel;
    private JPanel newType;
    private JPanel newPer;
    private JPanel newProject;
    private JLabel gradeLabel;
    private JButton calculateButton;
    private User user;

    private String subjectName;
    public int count = 2;
    private ArrayList<JTextField> projectFields = new ArrayList<>();

    public teacherGrades(JFrame parent, User user, String id) {
        this.user = user;

        setTitle("Subject Grades");
        setContentPane(gradePanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherSubjectProfile(null, user, id);
            }
        });

        Labell.setText("Grades for subject: " + subjectName);

        newProject.setLayout(new GridLayout(0, 1));
        newType.setLayout(new GridLayout(0, 1));
        newPer.setLayout(new GridLayout(0, 1));


    }







}
