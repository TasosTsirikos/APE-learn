public class DiplomaThesis {
}
