import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.time.LocalDate;

public class studentMenuu extends JFrame{
    private JList newsList;
    private JLabel nameLabel;
    private JLabel emailLabel;
    private JLabel usernameLabel;
    private JLabel typeLabel;
    private JLabel timeLabel;
    private JPanel studentPanel;
    private JToolBar jToolBarStudent;
    private JList subjectList;
    private JScrollPane scrollNews;
    private JList messagesList;
    private JScrollPane scrollMessages;
    private JScrollPane scrollSubjects;
    private JScrollPane calendarPanel;
    private JTable calendarTable;
    private JLabel bell;
    private LocalDate tillDateBooks;
    private LocalDate tillDateSubjects;

    private User user;

    public SystemApeLearn sal = new SystemApeLearn();

public Student st = new Student();


    public studentMenuu(JFrame parent, User user) {
        this.user = user;
        setTitle("Student Menu");
        setContentPane(studentPanel);

        scrollNews.setViewportView(newsList);
        scrollSubjects.setViewportView(subjectList);
        scrollMessages.setViewportView(messagesList);
        calendarPanel.setViewportView(calendarTable);


        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JButton registerButton = new JButton("Register to Subject");
        JButton sendMessageButton = new JButton("Send a Message");
        JButton findThesisButton = new JButton("Diploma Thesis");
        JButton myProgressButton = new JButton("My Progress");
        JButton editProfileButton = new JButton("My Profile");
        JButton logoutButton = new JButton("Logout");

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                // When registerButton is clicked, open the SubjectRegistrationWindow
                registerSubject registrationWindow = new registerSubject(null, user);
                registrationWindow.setVisible(true);
            }
        });

        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                myProfile profile = new myProfile(null, user);
                profile.setVisible(true);
            }
        });

        sendMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                studentSendMessage sendMessage = new studentSendMessage(null, user);
                sendMessage.setVisible(true);
            }
        });

        myProgressButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                myProgress myProgressWindow = new myProgress(null, user);
                myProgressWindow.setVisible(true);
            }
        });

        jToolBarStudent.add(registerButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        jToolBarStudent.add(sendMessageButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(findThesisButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(myProgressButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(editProfileButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(logoutButton);

        findThesisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                DiplomaThesisStudent dtOpener = new DiplomaThesisStudent(null, user);
                dtOpener.setVisible(true);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login(null);
            }
        });

        st.getStudentInfo(user, nameLabel, emailLabel, usernameLabel, typeLabel);

        // Create a Timer to update the time label every second
        Timer timer = new Timer(1000, e -> sal.updateTime(timeLabel));
        timer.start();

        setContentPane(studentPanel);

        sal.setupCalendar(calendarTable);
        displaySubjectList();

        subjectList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Get the selected subject
                    String selectedValue = (String) subjectList.getSelectedValue();
                    String idWithHtml = selectedValue.split(":")[0].trim();
                    String id = idWithHtml.substring("<html>".length());
                    System.out.println(id);
                    dispose();
                    JFrame profileFrame = new userSubjectProfile(null, user, id);
                    profileFrame.setVisible(true);
                }
            }
        });


        setVisible(true);
    }



private void displaySubjectList(){
    DefaultListModel<String> subjectListModel = new DefaultListModel<>();
    StringBuilder subjectText = new StringBuilder();

    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
        Statement stmt = conn.createStatement();
        PreparedStatement preparedStatement = conn.prepareStatement("SELECT id_subject, subject_name, subject_description, teacher FROM my_subjects WHERE student = ?");
        preparedStatement.setString(1, user.username);
        ResultSet rs = preparedStatement.executeQuery();

        while (rs.next()) {
            String id = rs.getString("id_subject");
            String name = rs.getString("subject_name");
            String description = rs.getString("subject_description");
            String teacher = rs.getString("teacher");

            if (description.length() > 20) {
                description = description.substring(0, 15) + "...";
            }

            // Add the subject information to the list model
            subjectText.append("<html>");
            subjectText.append(id + ": " + name + "<br>" + teacher + "<br>" + description);
            subjectText.append("<br><hr><br></html>");

            subjectListModel.addElement(subjectText.toString());
            subjectText.setLength(0);
        }

        // Close resources
        rs.close();
        stmt.close();
        conn.close();

        subjectList.setModel(subjectListModel);
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


}
