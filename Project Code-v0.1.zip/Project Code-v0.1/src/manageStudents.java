import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class manageStudents extends JFrame{
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTable table1;
    private JButton setButton;
    private User user;

    public manageStudents(JFrame parent, User user) {
        this.user = user;
        setTitle("Manage Students");
        setContentPane(panel1);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new secretaryHome(null, user);
            }
        });

        String[] columnNames = {"ID", "Name", "Year", "Semester"};
        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < table1.getColumnCount(); i++) {
            Class<?> columnClass = table1.getColumnClass(i);
            table1.setDefaultEditor(columnClass, null);
        }




    }


}
