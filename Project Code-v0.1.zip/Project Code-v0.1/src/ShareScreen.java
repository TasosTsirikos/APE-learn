public class ShareScreen {
    // Load the native library
    static {
        System.loadLibrary("ScreenShareNative");
    }

    // Native method declarations
    public native String[] enumerateWindows();
    // Additional methods as needed

    // A main method for testing
    public static void main(String[] args) {
        ShareScreen screenShare = new ShareScreen();
        String[] windowTitles = screenShare.enumerateWindows();
        for (String title : windowTitles) {
            System.out.println(title);
        }
    }
}
