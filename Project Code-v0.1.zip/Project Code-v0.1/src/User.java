public class User {
    public String username;
    public String password;
    public String name;
    public String email;
    public String type;
    public int id_users;

    public String getUsername() {
        return username;
    }
    public String getName() {
        return name;
    }
    public String getType() {
        return type;
    }
    public int getId() {
        return id_users;
    }



}
