public class Projects {
    private int idprojects;
    private String subject;
    private String teacher;
    private String student;
    private byte[] archive; // Representing BLOB as byte array
    private String date;
    private String title;
    private byte[] description;

    public int getIdprojects() {
        return idprojects;
    }



    public String getSubject() {
        return subject;
    }



    public String getTeacher() {
        return teacher;
    }



    public String getStudent() {
        return student;
    }



    public byte[] getArchive() {
        return archive;
    }



    public String getDate() {
        return date;
    }



    public String getTitle() {
        return title;
    }



    public byte[] getDescription() {
        return description;
    }


}
