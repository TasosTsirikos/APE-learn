import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DiplomaThesisTeacher extends JFrame {
    private JTextField titleField;
    private JTextField descriptionField;
    private JButton addButton;
    private JButton searchButton;
    private JButton deleteButton;
    private JTable tableDT;
    private JPanel dtTeacher;
    private JScrollPane dtTable;
    private JTextField idField;
    private User user;

    public DiplomaThesisTeacher(JFrame parent, User user) {
        this.user = user;
        setTitle("My Diploma Thesis");
        setContentPane(dtTeacher);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        tableDT.setDefaultEditor(Object.class, null);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherMenuu(null, user);
            }
        });


    }
}
