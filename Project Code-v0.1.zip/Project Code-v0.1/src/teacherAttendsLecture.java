import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class teacherAttendsLecture extends JFrame{
    private JPanel attendingPanel;
    private JLabel titleAttending;
    private JLabel cameraLabel;
    private JLabel leaveCall;
    private JLabel shareScreenLabel;
    private JLabel microphoneLabel;
    private JButton showParticipantsButton;
    private JPanel chatPanel;
    private JPanel speakerPanel;
    private JLabel speakerLabel;
    private JScrollPane participantsPanel;
    private User user;

    private String subjectName;

    public teacherAttendsLecture(JFrame parent, User user, String id) {
        this.user = user;
        Subjects subject = new Subjects();
        this.subjectName = subject.fetchSubjectName(id);
        setTitle("Subject Details");
        setContentPane(attendingPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherSubjectProfile(null, user, id);
            }
        });

        titleAttending.setText(user.getName() + " attends for subject: " + subjectName);
    }
}
