import java.sql.*;

public class Subjects {
    public String idsubjects;
    public String subject_name;
    public String subject_decription;
    public String subject_teacher;
    public String subject_type;
    public String subject_semester;
    public int subject_year;
    public int subject_ects;

    public String getId() {
        return idsubjects;
    }
    public String getName() {
        return subject_name;
    }
    public String getType() {
        return subject_type;
    }
    public String getSemester() {
        return subject_semester;
    }
    public String getSubject_decription() {
        return subject_decription;
    }
    public int getYear() {
        return subject_year;
    }
    public int getEcts() {
        return subject_ects;
    }

    String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }
}
