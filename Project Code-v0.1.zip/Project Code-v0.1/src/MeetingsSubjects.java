public class MeetingsSubjects extends Meetings{
}
