import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class DiplomaThesisStudent extends JFrame{
    private JTextField teacherSearch;
    private JTextField topicSearch;
    private JPanel dTStudent;
    private JButton takeItButton;
    private JButton searchButton;
    private JTable dtTable;
    private JButton resetButton;
    private JScrollPane scrollTable;

    private User user;

    private DefaultTableModel originalTableModel;

    public DiplomaThesisStudent(JFrame parent, User user) {
        this.user = user;

        setTitle("Diploma Thesis");
        setContentPane(dTStudent);

        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });

        String[] columnHeaders = {"ID", "Title", "Description", "Teacher"};

        // Create a DefaultTableModel with column headers
        DefaultTableModel model = new DefaultTableModel(columnHeaders, 0);

        dtTable.setModel(model);



        originalTableModel = (DefaultTableModel) dtTable.getModel();



    }


}

