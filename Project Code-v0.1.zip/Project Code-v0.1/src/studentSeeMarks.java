import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class studentSeeMarks extends JFrame {
    private JTable tableGrades;
    private JScrollPane gradesTable;
    private JLabel gradesTitle;
    private JPanel gradesPanel;
    private User user;

    public studentSeeMarks(JFrame parent, User user, String id) {
        this.user = user;

        setTitle("Subject Grades");
        setContentPane(gradesPanel);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);

            }
        });

        String[] columnNames = {"Project", "Mark"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) tableGrades.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < tableGrades.getColumnCount(); i++) {
            Class<?> columnClass = tableGrades.getColumnClass(i);
            tableGrades.setDefaultEditor(columnClass, null);
        }

    }
}

