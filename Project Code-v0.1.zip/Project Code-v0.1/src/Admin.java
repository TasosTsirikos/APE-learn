public class Admin extends User{
    public String getUsername() {
        return super.getUsername();
    }

    public String getName() {
        return super.getName();
    }
    public String getType() {
        return super.getType();
    }
    public int getId() {
        return super.getId();
    }
}
