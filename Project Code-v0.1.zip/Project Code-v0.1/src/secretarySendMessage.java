import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class secretarySendMessage extends JFrame {
    private JPanel sendMessage;
    private JTextField recipientField;
    private JCheckBox toAll;
    private JCheckBox toAllTeachers;
    private JCheckBox toAllStudents;
    private JList inList;
    private JList outList;
    private JTextArea messageBody;
    private JPanel sendMessagePanel;
    private JButton sendButton;
    private JLabel titleLabel;
    private JTextField titleField;
    private User user;


    public secretarySendMessage(JFrame parent, User user) {
        this.user = user;
        setTitle("My Messages");
        setContentPane(sendMessagePanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);



        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                    new secretaryHome(null, user);
            }
        });


    }



}

