import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class secretaryHome extends JFrame{
    private JList newsList;
    private JList requestList;
    private JList messagesList;
    private JLabel nameLabel;
    private JLabel usernameLabel;
    private JLabel emailLabel;
    private JToolBar menu;
    private JPanel secretaryMenu;
    private JLabel timeLabel;
    private JLabel typeLabel;
    private User user;

    public secretaryHome(JFrame parent, User user) {
        this.user = user;
        setTitle("Secretary Menu");
        setContentPane(secretaryMenu);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        JButton manageButton = new JButton("Manage Students");
        JButton crAccButton = new JButton("Create Accounts");
        JButton requestsButton = new JButton("Requests");
        JButton regulationsButton = new JButton("Regulations");
        JButton messageButton = new JButton("Send a Message");
        JButton emergencyButton = new JButton("Emergency");
        JButton profile = new JButton("My Profile");
        JButton logoutButton = new JButton("Logout");

        menu.add(manageButton);
        menu.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        menu.add(crAccButton);
        menu.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        menu.add(requestsButton);
        menu.add(new JSeparator(SwingConstants.VERTICAL));
        menu.add(regulationsButton);
        menu.add(new JSeparator(SwingConstants.VERTICAL));
        menu.add(messageButton);
        menu.add(new JSeparator(SwingConstants.VERTICAL));
        menu.add(emergencyButton);
        menu.add(new JSeparator(SwingConstants.VERTICAL));
        menu.add(profile);
        menu.add(new JSeparator(SwingConstants.VERTICAL));
        menu.add(logoutButton);

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login(null);
            }
        });

        manageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new manageStudents(null, user);
            }
        });

        regulationsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new secretaryRegulations(null, user);
            }
        });

        profile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                secretaryProfile secrProfile = new secretaryProfile(null, user);
                secrProfile.setVisible(true);
            }
        });

        messageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                secretarySendMessage sendMessage = new secretarySendMessage(null, user);
                sendMessage.setVisible(true);
            }
        });

        requestsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                secretaryRequests requests = new secretaryRequests(null, user);
                requests.setVisible(true);
            }
        });

        crAccButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                secretaryCrAccount crAcc = new secretaryCrAccount(null, user);
                crAcc.setVisible(true);
            }
        });

        emergencyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                secretaryEmergency emergency = new secretaryEmergency(null, user);
                emergency.setVisible(true);
            }
        });

        populateLabels();

        Timer timer = new Timer(1000, e -> updateTime());
        timer.start();
    }

    private void updateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        timeLabel.setText(formattedDateTime);
    }

    private void populateLabels(){
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            // Prepare the SQL query
            String query = "SELECT type, username, name, email FROM users WHERE username = '" + user.username + "'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if result set has data
            if (resultSet.next()) {
                // Update the JLabels with fetched information
                typeLabel.setText("Type: " + resultSet.getString("type"));
                nameLabel.setText("Name: " + resultSet.getString("name"));
                usernameLabel.setText("Username: " + resultSet.getString("username"));
                emailLabel.setText("Email: " + resultSet.getString("email"));
            }else {
                System.out.println("No data found for user ID: " + user.getId());
            }

            // Close the result set and prepared statement
            resultSet.close();
            preparedStatement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
}

