import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class teacherSubjectParticipants extends JFrame {
    private JTable table1;
    private JPanel participantsPanel;
    private User user;

    public teacherSubjectParticipants(JFrame parent, User user, String id) {
        this.user = user;
        setTitle("My Profile");
        setContentPane(participantsPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new teacherSubjectProfile(null, user, id);
            }
        });

    }
}
