import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class myProgress extends JFrame{
    private JTable progressTable;
    private JButton swornRequestButton;
    private JLabel passedSubjects;
    private JPanel myProgressPanel;
    private JScrollPane scrollTable;
    private JLabel takenECTS;
    private JLabel averageGrade;
    private User user;


    public myProgress(JFrame parent, User user) {
        this.user = user;

        setTitle("My Progress");
        setContentPane(myProgressPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });


    }


}
