import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class adminEmergency extends JFrame{
    private JTable table1;
    private JButton authorizeButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton searchButton;
    private JPanel adminEmergencyPanel;
    private User user;

    public adminEmergency(JFrame parent, User user) {
        this.user = user;
        setTitle("Admin Menu");
        setContentPane(adminEmergencyPanel);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new adminHome(null, user);
            }
        });

    }
}
