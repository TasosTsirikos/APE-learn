import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class adminAnnouncement extends JFrame{
    private JTextField textField1;
    private JTextArea textArea1;
    private JTable table1;
    private JButton submitButton;
    private JPanel adminAnnouncementPanel;
    private JCheckBox checkBox1;
    private User user;

    public adminAnnouncement(JFrame parent, User user) {
        this.user = user;
        setTitle("Admin Menu");
        setContentPane(adminAnnouncementPanel);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new adminHome(null, user);
            }
        });

    }
}
