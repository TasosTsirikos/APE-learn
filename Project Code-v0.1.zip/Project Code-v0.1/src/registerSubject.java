import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class registerSubject extends JFrame{
    private JPanel subjectTable;
    private JTable table_subjects;
    private JScrollPane subject_table;
    private JButton registerBtn;
    private User user;
    private Announcements announcement;
    private Messages message;
    private Subjects subject;

    // Constructor
    public registerSubject(JFrame parent, User user) {
        this.user = user;
        setTitle("Register to Subjects");
        setContentPane(subjectTable);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);


        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });

    }



}
