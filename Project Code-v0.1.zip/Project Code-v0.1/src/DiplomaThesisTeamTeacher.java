import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class DiplomaThesisTeamTeacher extends JFrame{
    private JTree tree1;
    private JButton uploadFilesButton;
    private JButton messagesButton;
    private JButton enterCallButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton newBranchButton;
    private JTextField textField4;
    private JButton submitButton;
    private JPanel coSharepanel;
    private User user;

    public DiplomaThesisTeamTeacher(JFrame parent, User user) {
        this.user = user;
        setTitle("Diploma Thesis Co-Share");
        setContentPane(coSharepanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new teacherMenuu(null, user);
            }
        });
    }
}
