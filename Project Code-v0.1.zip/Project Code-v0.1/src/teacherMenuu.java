import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class teacherMenuu extends JFrame {
    private User user;
    private JLabel timeLabel;
    private JLabel nameLabel;
    private JLabel emailLabel;
    private JLabel usernameLabel;
    private JLabel typeLabel;
    private JPanel teacherPanel;
    private JList subjectList;
    private JList newsList;
    private JList messageList;
    private JScrollPane newsPanel;
    private JScrollPane messagePanel;
    private JToolBar jToolBarTeacher;
    private JScrollPane subjectPanel;
    private JButton editProfileButton;
    private JTable calendarTable;

    public SystemApeLearn sal = new SystemApeLearn();


    private JScrollPane calendarPanel;

    public teacherMenuu(JFrame parent, User user) {
        this.user = user;
        setTitle("Teacher Menu");
        setContentPane(teacherPanel);


        newsPanel.setViewportView(newsList);
        subjectPanel.setViewportView(subjectList);
        messagePanel.setViewportView(messageList);

        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        sal.setupCalendar(calendarTable);

        JButton subjectsButton = new JButton("My Subjects");
        JButton dtTeamButton = new JButton("Diploma Thesis Teams");
        JButton editProfileButton = new JButton("Edit Profile");
        JButton sendMessageButton = new JButton("Send a Message");
        JButton dThesisButton = new JButton("Diploma Thesis");
        JButton logoutButton = new JButton("Logout");

        jToolBarTeacher.add(subjectsButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        jToolBarTeacher.add(dtTeamButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        jToolBarTeacher.add(sendMessageButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarTeacher.add(dThesisButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarTeacher.add(editProfileButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarTeacher.add(logoutButton);

        subjectsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                teacherSubjects subjects = new teacherSubjects(null, user);
                subjects.setVisible(true);
            }
        });

        sendMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                teacherSendMessage sendMessage = new teacherSendMessage(null, user);
                sendMessage.setVisible(true);
            }
        });

        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                teacherProfile profile = new teacherProfile(null, user);
                profile.setVisible(true);
            }
        });

        dThesisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                DiplomaThesisTeacher dtTeacher = new DiplomaThesisTeacher(null, user);
                dtTeacher.setVisible(true);
            }
        });

        dtTeamButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                DiplomaThesisTeamTeacher dtTeam = new DiplomaThesisTeamTeacher(null, user);
                dtTeam.setVisible(true);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login(null);
            }
        });



        Timer timer = new Timer(1000, e -> sal.updateTime(timeLabel));
        timer.start();


        showUserInfo();
        showMySubjects();

        subjectList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Get the selected item from the subjectList
                    String selectedItem = (String) subjectList.getSelectedValue();

                    // Check if selectedItem is not null and contains "<br>"
                    if (selectedItem != null && selectedItem.contains("<br>")) {
                        // Extract the subject ID before "<br>"
                        String subjectId = selectedItem.substring(0, selectedItem.indexOf("<br>")).trim();
                        String idWithHtml = subjectId.split(":")[0].trim();
                        String id = idWithHtml.substring("<html>".length());
                        System.out.println(id);
                        String name = selectedItem.substring(1, selectedItem.indexOf("<br>")).trim();
                        System.out.println(name);
                        dispose();

                        // Open the teacherSubjectProfile panel with subject details
                        teacherSubjectProfile subjectProfile = new teacherSubjectProfile(null, user, id);
                        subjectProfile.setVisible(true);
                    }
                }
            }
        });


    }


    private void showUserInfo(){
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            Statement statement = connection.createStatement();

            // Execute query to get user information
            ResultSet resultSet = statement.executeQuery("SELECT name, email, username, type FROM users WHERE username = '" + user.username + "'");
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String userType = resultSet.getString("type");

                // Set retrieved information to the JLabels
                nameLabel.setText("Name: " + name);
                emailLabel.setText("Email: " + email);
                usernameLabel.setText("Username: " + user.username);
                typeLabel.setText("Type: " + userType);
            } else {
                JOptionPane.showMessageDialog(this, "User not found!");
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: Unable to connect to the database.");
        }
    }





    private void showMySubjects(){
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            Statement stmt = conn.createStatement();

            // Query to select data from subjects table for the given user
            String query = "SELECT idsubjects, subject_name, subject_decription, type, ects, year, semester " +
                    "FROM subjects " +
                    "WHERE teacher = '" + user.getName() + "'";

            ResultSet rs = stmt.executeQuery(query);

            // Create a DefaultListModel to store subject details
            DefaultListModel<String> subjectListModel = new DefaultListModel<>();

            // Iterate through the result set and add subject details to the list model
            while (rs.next()) {
                String id = rs.getString("idsubjects");
                String name = rs.getString("subject_name");
                String description = rs.getString("subject_decription");

                if (description.length() > 20) {
                    description = description.substring(0, 15) + "...";
                }

                // Construct the string representation of the subject
                String subjectInfo = "<html>" + id + "<br>Name: " + name + "<br>About: " + description + "<br><br><hr>";

                // Add the subject info to the list model
                subjectListModel.addElement(subjectInfo);
            }

            // Set the subject list model to your JList
            subjectList.setModel(subjectListModel);

            System.out.println("Number of items in subjectList: " + subjectListModel.getSize());

            // Close the result set, statement, and connection
            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
