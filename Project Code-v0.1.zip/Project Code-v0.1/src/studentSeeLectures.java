import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class studentSeeLectures extends JFrame{
    private JTextField dateField;
    private JButton searchButton;
    private JScrollPane lecturePanel;
    private JTable lectureTable;
    private JLabel lecturesTitle;
    private JPanel lectures;
    private User user;

    private String subjectName;


    public studentSeeLectures(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);

        setTitle("Subject Lectures");
        setContentPane(lectures);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        lecturesTitle.setText("Lectures for Subject: " + subjectName);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);
            }
        });

        String[] columnNames = {"Date", "Archive"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) lectureTable.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < lectureTable.getColumnCount(); i++) {
            Class<?> columnClass = lectureTable.getColumnClass(i);
            lectureTable.setDefaultEditor(columnClass, null);
        }

    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }


}
