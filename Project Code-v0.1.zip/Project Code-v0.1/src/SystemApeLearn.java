import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

public class SystemApeLearn {
    public void updateTime(JLabel timeLabel) {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        timeLabel.setText(formattedDateTime);
    }

    public void setupCalendar(JTable calendarTable) {
        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Get the current month and year
        YearMonth currentYearMonth = YearMonth.from(currentDate);
        int year = currentYearMonth.getYear();
        int month = currentYearMonth.getMonthValue();

        // Set up table model and headers
        String[] columns = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        int numRows = 6; // Maximum number of rows in a month
        DefaultTableModel model = new DefaultTableModel(columns, numRows);
        calendarTable.setModel(model);

        // Get the first day of the month
        LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);

        // Get the day of the week for the first day of the month
        int startDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7;

        // Get the number of days in the month
        int daysInMonth = currentYearMonth.lengthOfMonth();

        // Populate the table with dates
        int row = 0;
        int column = startDayOfWeek;
        for (int day = 1; day <= daysInMonth; day++) {
            model.setValueAt(day, row, column);
            if (column == 6) {
                // Move to the next row if it's Saturday
                row++;
                column = 0;
            } else {
                // Move to the next column
                column++;
            }
        }

        calendarTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                // Invoke super method to get the default renderer
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Get the value in the cell
                Object cellValue = table.getValueAt(row, column);

                // Highlight the cell if the value is the current day
                if (cellValue != null && cellValue instanceof Integer && ((int) cellValue) == LocalDate.now().getDayOfMonth()) {
                    c.setBackground(new Color(255, 204, 204)); // Light pink color
                } else {
                    // Reset background color for other cells
                    c.setBackground(Color.WHITE);
                }

                return c;
            }
        });
    }
}
