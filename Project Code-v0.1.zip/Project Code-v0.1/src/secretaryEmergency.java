import javax.swing.*;
import java.awt.*;

public class secretaryEmergency extends JFrame{
    private JLabel timeLabel;
    private JToolBar menuStudents;
    private JToolBar menuTeachers;
    private JPanel secrEmergencyPanel;
    private User user;

    public secretaryEmergency(JFrame parent, User user) {
        this.user = user;
        setTitle("Secretary Menu");
        setContentPane(secrEmergencyPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        JButton subjectButton = new JButton("Enroll to Subjects");
        JButton booksButton = new JButton("Select Books");
        JButton projectButton = new JButton("Upload Project");
        JButton equipButton = new JButton("Equipment Failure");

        menuStudents.add(subjectButton);
        menuStudents.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        menuStudents.add(booksButton);
        menuStudents.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        menuStudents.add(projectButton);

        menuTeachers.add(equipButton);

    }
}
