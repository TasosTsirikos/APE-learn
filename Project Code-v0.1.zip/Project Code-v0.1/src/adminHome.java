import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class adminHome extends JFrame{
    private JLabel hourLabel;
    private JLabel nameLabel;
    private JPanel adminPanel;
    private JLabel usernameLabel;
    private JLabel emailLabel;
    private JLabel typeLabel;
    private JToolBar toolBarAdmin;
    private User user;

    public adminHome(JFrame parent, User user) {
        this.user = user;
        setTitle("Admin Menu");
        setContentPane(adminPanel);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        JButton createAccButton = new JButton("Create Account");
        JButton manageDBButton = new JButton("Handle DB");
        JButton emergencyButton = new JButton("Emergency Events");
        JButton announceButton = new JButton("Announcement");
        JButton logoutButton = new JButton("Logout");

        toolBarAdmin.add(createAccButton);
        toolBarAdmin.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        toolBarAdmin.add(manageDBButton);
        toolBarAdmin.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarAdmin.add(emergencyButton);
        toolBarAdmin.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarAdmin.add(announceButton);
        toolBarAdmin.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarAdmin.add(logoutButton);

        Timer timer = new Timer(1000, e -> updateTime());
        timer.start();

        createAccButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new adminCreateAcc(null, user);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login(null);
            }
        });

        manageDBButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new adminHandleDB(null, user);
            }
        });

        announceButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new adminAnnouncement(null, user);
            }
        });

        emergencyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new adminEmergency(null, user);
            }
        });
    }

    private void updateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        hourLabel.setText(formattedDateTime);
    }
}
