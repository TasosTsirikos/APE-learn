import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class studentFindsTeam extends  JFrame{
    private JList list1;
    private JList list2;
    private JTextField textField2;
    private JTextField textField3;
    private JButton searchButton;
    private JTextField textField1;
    private JButton sentRequestsButton;
    private JButton joinTeamButton;
    private JPanel findTeamPanel;
    private User user;

    public studentFindsTeam(JFrame parent, User user, String id) {
        this.user = user;
        setTitle("My Diploma Thesis");
        setContentPane(findTeamPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);

            }
        });
    }
}
