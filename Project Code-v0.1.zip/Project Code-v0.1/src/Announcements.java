public class Announcements {
    public int idannouncements;
    public String text;
    public String teacher_name;
    public String title;
    public String about;
    public String date;
    public String subject_id;

    public String getText() {
        return text;
    }
    public String getTeacher() {
        return teacher_name;
    }
    public String getAbout() {
        return about;
    }

    public String getSubject() {
        return subject_id;
    }
    public int getId() {
        return idannouncements;
    }


}
