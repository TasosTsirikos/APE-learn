public class Messages {
    public String sender;
    public String recipient;
    public String message_text;
    public String message_title;
    public String message_date;
    public int id_message;

    public String getSender() {
        return sender;
    }
    public String getRecipient() {
        return recipient;
    }
    public String getText() {
        return message_text;
    }
    public String getTitle() {
        return message_title;
    }
    public String getDate() {
        return message_date;
    }
    public int getId_message() {
        return id_message;
    }
}
