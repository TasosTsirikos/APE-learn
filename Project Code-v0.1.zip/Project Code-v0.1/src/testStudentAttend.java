import org.opencv.core.Core;
import org.opencv.videoio.VideoCapture;

import javax.sound.sampled.TargetDataLine;
import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class testStudentAttend extends JFrame {
    private JLabel speakerLabel;
    private JPanel attendingPanel;
    private JLabel titleAttending;
    private VideoCapture capture;
    private JButton showParticipantsButton;
    private JPanel speakerPanel;
    private JPanel chatPanel;
    private JLabel cameraLabel;
    private JLabel microphoneLabel;
    private JLabel shareScreenLabel;
    private JLabel leaveCall;
    private JScrollPane participantsPanel;
    private JPanel studentAttendsLecturePanel;

    private User user;

    private String subjectName;
    private TargetDataLine line;
    private final Object cameraLock = new Object();
    private final Object microphoneLock = new Object();


    public testStudentAttend(JFrame parent, User user, String id) {
        this.user = user;
        setTitle("Attending Lecture for Subject: ");
        setContentPane(attendingPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {

                new userSubjectProfile(null, user, id);
            }
        });

        titleAttending.setText(user.getName() + " attends for subject: " + subjectName);

        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        int response = JOptionPane.showConfirmDialog(this,
                "This application needs to access your camera and microphone. Do you agree?",
                "Camera and Microphone Access",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (response != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Access denied. Returning to Subject Profile.");
            dispose();
            new userSubjectProfile(null, user, id);
        }




    }


}

