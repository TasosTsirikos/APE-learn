CREATE DATABASE  IF NOT EXISTS `softengin23_24` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `softengin23_24`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: softengin23_24
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `diploma_thesis`
--

DROP TABLE IF EXISTS `diploma_thesis`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diploma_thesis` (
  `id_diploma_thesis` int NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `description` tinytext NOT NULL,
  `teacher` varchar(45) NOT NULL,
  `assign_date` date DEFAULT NULL,
  `student` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_diploma_thesis`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diploma_thesis`
--

LOCK TABLES `diploma_thesis` WRITE;
/*!40000 ALTER TABLE `diploma_thesis` DISABLE KEYS */;
INSERT INTO `diploma_thesis` VALUES (1,'Enhancing Network Security using Blockchain Technology','Investigating the application of blockchain for enhancing network security protocols.','Maria N','2023-02-10',''),(2,'Machine Learning Applications in Healthcare Informatics','Exploring the utilization of machine learning algorithms for healthcare data analysis and decision support systems.','Xenia Z','2022-11-15',''),(3,'Developing a Real-time Traffic Management System using IoT','Designing and implementing a real-time traffic management system leveraging Internet of Things (IoT) technologies.','Kostas P','2023-04-22',''),(4,'Enhancing Cloud Computing Security through Homomorphic Encryption','Investigating the use of homomorphic encryption to improve security in cloud computing environments.','Xristos P','2023-08-05',''),(5,'Designing a Scalable Big Data Analytics Platform','Design and implementation of a scalable big data analytics platform for processing large datasets efficiently.','Elena B','2023-10-17',''),(6,'Exploring Quantum Computing Algorithms for Optimization Problems','Researching quantum computing algorithms and their applications for solving optimization problems.','Makis K','2022-09-28',''),(7,'Cyber-Physical Systems for Smart Cities','Developing cyber-physical systems tailored for smart city applications to improve urban infrastructure and services.','Xristos P','2023-01-08',''),(8,'Securing Internet of Things (IoT) Devices through Firmware Analysis','Investigating security vulnerabilities in IoT devices and proposing firmware analysis techniques for enhancing security.','Dimitris T','2022-12-30',''),(9,'Application of Natural Language Processing in Sentiment Analysis','Utilizing natural language processing techniques for sentiment analysis in social media and customer feedback data.','Pavlos N','2023-05-12',''),(10,'Designing Energy-Efficient Embedded Systems for IoT Applications','Design and optimization of energy-efficient embedded systems suitable for Internet of Things (IoT) applications.','Xenia Z','2023-07-20',''),(11,'Implementing a Recommender System for E-commerce Platforms','Design and implementation of a personalized recommender system using machine learning algorithms for e-commerce platforms.','Spyros N','2022-10-05',''),(12,'Blockchain-based Supply Chain Management System','Developing a supply chain management system using blockchain technology to enhance transparency and traceability.','Xristos P','2023-03-15','');
/*!40000 ALTER TABLE `diploma_thesis` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-27 16:11:12
