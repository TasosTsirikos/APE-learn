CREATE DATABASE  IF NOT EXISTS `softengin23_24` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `softengin23_24`;
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: softengin23_24
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `idannouncements` int NOT NULL AUTO_INCREMENT,
  `text` mediumtext NOT NULL,
  `teacher_name` varchar(45) NOT NULL,
  `title` varchar(60) NOT NULL,
  `about` varchar(70) NOT NULL,
  `date` date DEFAULT NULL,
  `subject_id` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`idannouncements`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'Η προθεσμία για την υποβολή της εργασίας είναι μέχρι την Κυριακή 3 Μαρτίου 23:55','Xristos P','Υποβολή Εργασίας','Data Structures','2024-02-26','CS002'),(2,'Reminder: Midterm exam will be held next week on Friday, March 1, 10:00-12:00.','Maria N','Midterm Exam','Computer Networks','2024-02-27','CS003'),(3,'Please note the change in the schedule. The lecture on Wednesday, February 28, will be postponed to Thursday, March 1.','Elena M','Schedule Change','Artificial Intelligence','2024-02-28','CS005'),(4,'Don\'t forget to submit your project proposal by Friday, March 1. Late submissions will not be accepted.','Spyros N','Project Proposal Deadline','Web Development','2024-02-29','CS006'),(5,'The lab session scheduled for Monday, March 4, has been canceled. Make sure to check for any updates regarding rescheduling.','Xenia Z','Canceled Lab Session','Operating Systems','2024-03-01','CS007'),(6,'The guest lecture on Friday, March 1, will cover advanced topics in software engineering. Attendance is highly recommended.','Makis K','Guest Lecture','Software Engineering','2024-03-01','CS008'),(7,'The deadline for the final project submission is approaching. Ensure to submit it by Sunday, March 10, 23:59.','Pavlos N','Final Project Deadline','Computer Graphics','2024-03-02','CS009'),(8,'There will be a review session for the upcoming exam on Monday, March 4, from 14:00 to 16:00 in room 203.','Kostas P','Exam Review Session','Programming Languages','2024-03-02','CS011'),(9,'Reminder: The quiz scheduled for Friday, March 8, will cover chapters 5 to 8. Make sure to prepare thoroughly.','Dimitris T','Quiz Announcement','Information Security','2024-03-03','CS012'),(10,'The deadline for submitting the research paper proposal is extended to Tuesday, March 12, 23:59.','Lampros F','Research Proposal Deadline','Machine Learning','2024-03-04','CS010'),(11,'System let me make an announcement!!','Xenia Z','Don\'t take this announcement into account','Operating Systems','2024-03-06','CS007'),(12,'Today the System will be updated at 4-6 p.m.','admin','System Update','System','2024-05-14',NULL);
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-27 16:11:15
