import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.time.LocalDate;
import java.util.Vector;

public class Requests {
    public static String checkRequests(User user) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String dbUsername = "root";
        String dbPassword = "W45@jqr#8CX";
        LocalDate today = LocalDate.now();
        System.out.println(today);

        // SQL query to retrieve status, date_completed, and about
        String query = "SELECT status, date_completed, about FROM requests WHERE username = ?";

        StringBuilder message = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(url, dbUsername, dbPassword);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, user.getUsername());

            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    String status = resultSet.getString("status");
                    String dateCompleted = resultSet.getString("date_completed");
                    String about = resultSet.getString("about");

                    if (dateCompleted.equals(today)) {
                        if (status.equals("completed")) {
                            message.append("Your request for '").append(about).append("' has been '").append(status)
                                    .append("' on ").append(dateCompleted);
                        } else {
                            message.append("Your request for '").append(about).append("' has been '").append(status).append("'");
                        }
                    }else{
                        message.append("No processed requests for now");
                    }
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            message.append("Error retrieving request status");
        }
        return message.toString();
    }

    public void loadRequestsData(JTable table1) {
        try {

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            // Prepare the SQL query
            String query = "SELECT * FROM requests";
            Statement statement = connection.createStatement();

            // Execute the query and obtain the result set
            ResultSet resultSet = statement.executeQuery(query);

            // Get the metadata of the result set
            ResultSetMetaData metaData = resultSet.getMetaData();

            // Number of columns in the result set
            int columnCount = metaData.getColumnCount();

            // Column names
            Vector<String> columnNames = new Vector<>();
            for (int column = 1; column <= columnCount; column++) {
                columnNames.add(metaData.getColumnName(column));
            }

            // Data of the table
            Vector<Vector<Object>> data = new Vector<>();
            while (resultSet.next()) {
                Vector<Object> vector = new Vector<>();
                for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                    vector.add(resultSet.getObject(columnIndex));
                }
                data.add(vector);
            }

            resultSet.close();
            statement.close();
            connection.close();

            // Set the table model
            DefaultTableModel model = new DefaultTableModel(data, columnNames);
            table1.setModel(model);
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data from database", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
