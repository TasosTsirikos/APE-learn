import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.time.LocalDate;

public class studentSendMessage extends JFrame {
    private JPanel sendMessage;
    private JTextField recipientField;
    private JCheckBox toAll;
    private JCheckBox toAllTeachers;
    private JCheckBox toAllStudents;
    private JList inList;
    private JList outList;
    private JTextArea messageBody;
    private JPanel sendMessagePanel;
    private JButton sendButton;
    private JLabel titleLabel;
    private JTextField titleField;
    private User user;


    public studentSendMessage(JFrame parent, User user) {
        this.user = user;
        Messages message = new Messages();
        setTitle("My Messages");
        setContentPane(sendMessagePanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                sendMessage();
                new studentSendMessage(null, user);
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if(user.getType().equals("student")) {
                    new studentMenuu(null, user);
                }else if(user.getType().equals("teacher")){
                    new teacherMenuu(null, user);
                }else{
                    new secretaryHome(null, user);
                }
            }
        });

        message.showInMessages(user, inList);
        message.showOutMessages(user, outList);
    }

    private void sendMessage() {
        String recipient = recipientField.getText().trim();
        String messageText = messageBody.getText();
        String title = titleField.getText();
        Date currentDate = Date.valueOf(LocalDate.now());

        if (recipient.isEmpty() && (!toAll.isSelected()) && (!toAllTeachers.isSelected()) && (!toAllStudents.isSelected())) {
            JOptionPane.showMessageDialog(this, "Please select a recipient.");
            return;
        }

        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please give a title to your message.");
            return;
        }

        if (messageText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your message doesn't have any body.");
            return;
        }

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            if(toAll.isSelected()){
                String getUsersQuery = "SELECT username FROM users WHERE username NOT LIKE ?";
                PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);
                getUsersStatement.setString(1, user.username);

                ResultSet resultSet = getUsersStatement.executeQuery();

                // Insert message for each user
                while (resultSet.next()) {
                    String recipientUsername = resultSet.getString("username");

                    // Prepare the SQL statement
                    PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                    preparedStatement.setString(1, user.getUsername());
                    preparedStatement.setString(2, recipientUsername);
                    preparedStatement.setString(3, messageText);
                    preparedStatement.setString(4, title);
                    preparedStatement.setDate(5, currentDate);

                    preparedStatement.executeUpdate();

                    preparedStatement.close();
                }

                resultSet.close();
                getUsersStatement.close();
            }
            else if(toAllTeachers.isSelected()){
                String getUsersQuery = "SELECT type,username FROM users WHERE type NOT LIKE 'student'";
                PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);

                ResultSet resultSet = getUsersStatement.executeQuery();

                // Insert message for each user
                while (resultSet.next()) {
                    String recipientUsername = resultSet.getString("username");

                    // Prepare the SQL statement
                    PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                    preparedStatement.setString(1, user.getUsername());
                    preparedStatement.setString(2, recipientUsername);
                    preparedStatement.setString(3, messageText);
                    preparedStatement.setString(4, title);
                    preparedStatement.setDate(5, currentDate);

                    preparedStatement.executeUpdate();

                    preparedStatement.close();
                }

                resultSet.close();
                getUsersStatement.close();
            }
            else if(toAllStudents.isSelected()){
                String getUsersQuery = "SELECT type,username FROM users WHERE type NOT LIKE 'teacher'";
                PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);

                ResultSet resultSet = getUsersStatement.executeQuery();

                // Insert message for each user
                while (resultSet.next()) {
                    String recipientUsername = resultSet.getString("username");

                    // Prepare the SQL statement
                    PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                    // Set parameters
                    preparedStatement.setString(1, user.getUsername());
                    preparedStatement.setString(2, recipientUsername);
                    preparedStatement.setString(3, messageText);
                    preparedStatement.setString(4, title);
                    preparedStatement.setDate(5, currentDate);

                    preparedStatement.executeUpdate();

                    preparedStatement.close();
                }

                resultSet.close();
                getUsersStatement.close();
            }
            else{

                // Prepare the SQL statement
                PreparedStatement preparedStatement = connection.prepareStatement(
                        "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                preparedStatement.setString(1, user.getUsername());
                preparedStatement.setString(2, recipient);
                preparedStatement.setString(3, messageText);
                preparedStatement.setString(4, title);
                preparedStatement.setDate(5, currentDate);

                preparedStatement.executeUpdate();

                preparedStatement.close();
            }
            connection.close();

            // Display a success message
            JOptionPane.showMessageDialog(this, "Message sent successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending message: " + ex.getMessage());
        }
    }
}
