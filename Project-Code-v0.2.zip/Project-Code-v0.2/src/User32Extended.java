import com.sun.jna.Native;
import com.sun.jna.platform.win32.WinDef.HDC;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.win32.StdCallLibrary;

public interface User32Extended extends StdCallLibrary {
    User32Extended INSTANCE = (User32Extended) Native.load("user32", User32Extended.class);

    boolean PrintWindow(HWND hwnd, HDC hdcBlt, int nFlags);
    HDC GetWindowDC(HWND hWnd);

}

