import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class teacherSubjectParticipants extends JFrame {
    private JTable table1;
    private JPanel participantsPanel;
    private User user;

    public teacherSubjectParticipants(JFrame parent, User user, String id) {
        this.user = user;
        setTitle("My Profile");
        setContentPane(participantsPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new teacherSubjectProfile(null, user, id);
            }
        });

        String[] columnNames = {"Id", "Name", "Year", "Semester", "Garde"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < table1.getColumnCount(); i++) {
            Class<?> columnClass = table1.getColumnClass(i);
            table1.setDefaultEditor(columnClass, null);
        }


    }
}
