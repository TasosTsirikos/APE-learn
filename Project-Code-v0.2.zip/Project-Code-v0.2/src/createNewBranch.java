import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class createNewBranch extends  JFrame{
    private JTextField newBranch;
    private JComboBox parentBranchescomboBox;
    private JButton OKButton;
    private JPanel newBranchPanel;
    private User user;
    private String teamID;

    public createNewBranch(JFrame parent, User user, String teamID) {
        this.user = user;
        this.teamID = teamID;
        setTitle("Diploma Thesis Co-Share");
        setContentPane(newBranchPanel);
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new DiplomaThesisTeamTeacher(null, user, teamID);
            }
        });


        populateParentBranches();

        OKButton.addActionListener(e -> {
            try {
                if (!validateAndInsertNewBranch()) {
                    return;
                }
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
            new DiplomaThesisTeamTeacher(null, user, teamID);

        });
    }

    private boolean validateAndInsertNewBranch() throws SQLException {
        String branchName = newBranch.getText().trim();
        if (branchName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "You must give a name to the new Branch.");
            return false;
        }

        Object selectedItem = parentBranchescomboBox.getSelectedItem();
        if (selectedItem == null || selectedItem == "No Parent (Main Branch)") {
            JOptionPane.showMessageDialog(this, "You didn't choose a parent branch. This means the new branch will be a main branch.");
        }

        if (branchAlreadyExists(branchName, selectedItem)) {
            JOptionPane.showMessageDialog(this, "This branch has already been created inside the ParentBranch.");
            return false;
        }

        return insertNewBranch(branchName, selectedItem);
    }

    private void populateParentBranches() {
        parentBranchescomboBox.addItem("No Parent (Main Branch)"); // Special item for no parent
        String URL = "jdbc:mysql://localhost:3306/softengin23_24";
        String USERNAME = "root";
        String PASSWORD = "W45@jqr#8CX";
        String sql = "SELECT branchName, parentBranchName FROM co_share_branch_diploma_thesis WHERE teamId = ?";

        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, teamID);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String branchName = rs.getString("branchName");
                String parentBranchName = rs.getString("parentBranchName");
                String comboBoxEntry = branchName + " (Parent: " + parentBranchName + ")";
                parentBranchescomboBox.addItem(comboBoxEntry);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        }
    }

    private boolean insertNewBranch(String branchName, Object selectedItem) throws SQLException {
        String URL = "jdbc:mysql://localhost:3306/softengin23_24";
        String USERNAME = "root";
        String PASSWORD = "W45@jqr#8CX";
        String sql = "INSERT INTO co_share_branch_diploma_thesis (parentBranchId, teamId, username, date, branchName, parentBranchName, teamId) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            String parentBranchName = null;
            stmt.setString(7, this.teamID);
            if (selectedItem != null || selectedItem != "No Parent (Main Branch)") {
                String selectedEntry = selectedItem.toString();
                parentBranchName = selectedEntry.split(" \\(Parent: ")[0];

                stmt.setNull(1, java.sql.Types.INTEGER);
                stmt.setString(2, null);
                stmt.setString(3, this.user.getUsername());
                stmt.setString(4, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                stmt.setString(5, branchName);
                stmt.setString(6, parentBranchName);
            } else {
                stmt.setNull(1, java.sql.Types.INTEGER);
                stmt.setString(2, null);
                stmt.setString(3, this.user.getUsername());
                stmt.setString(4, new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
                stmt.setString(5, branchName);
                stmt.setNull(6, java.sql.Types.VARCHAR);
            }

            int result = stmt.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Branch created successfully.");
                dispose(); // Close the frame after successful operation
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create branch.");
                return false;
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
            throw ex;
        }
    }

    private boolean branchAlreadyExists(String branchName, Object selectedItem) throws SQLException {
        String parentBranchName = selectedItem == null ? null : selectedItem.toString().split(" \\(Parent: ")[0];

        String URL = "jdbc:mysql://localhost:3306/softengin23_24";
        String USERNAME = "root";
        String PASSWORD = "W45@jqr#8CX";
        String sql = "SELECT COUNT(*) FROM co_share_branch_diploma_thesis WHERE branchName = ? AND parentBranchName = ? AND teamId = ?";

        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, branchName);
            stmt.setString(2, parentBranchName);
            stmt.setString(3, this.teamID);

            ResultSet rs = stmt.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) {
                return true; // Branch already exists
            }
            return false; // No such branch exists
        }
    }
}
