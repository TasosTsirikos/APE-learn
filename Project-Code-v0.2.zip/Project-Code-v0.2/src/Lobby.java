import javax.swing.*;
import java.util.HashSet;
import java.util.Set;

public class Lobby {
    public static Set<LobbyEntry> entries = new HashSet<>();
    public void addUserToLobby(String username, String subjectId) {
        entries.add(new LobbyEntry(username, subjectId));    }

    public void removeUserFromLobby(String username, String subjectId) {
        entries.remove(new LobbyEntry(username, subjectId));
    }

    public static void updateLobbyList(JList list1) {
        if (entries.isEmpty()) {
            list1.setListData(new String[]{"Lobby has no waiting attendees"});
        } else {
            list1.setListData(entries.stream().map(LobbyEntry::getUsername).toArray(String[]::new));
        }
    }


}
