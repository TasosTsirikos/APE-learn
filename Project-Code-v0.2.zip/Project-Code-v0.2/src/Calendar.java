import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.List;
import java.util.*;

public class Calendar {
    private User user;
    private Map<LocalDate, String[]> projectDetails = new HashMap<>();
    private Map<LocalDate, String[]> announcementDetails = new HashMap<>();
   private Map<String, List<String[]>> detailsMeetings = new HashMap<>();
    private Map<LocalDate, List<String[]>> userReminders = new HashMap<>();

    public void drawCalendar(JTable calendarTable, User user) {
        LocalDate DcurrentDate = LocalDate.now();

        Projects project = new Projects();
        project.loadProjectDates(user, projectDetails);

        Announcements ann = new Announcements();
        ann.loadAnnouncementDates(announcementDetails);

        Meetings meet = new Meetings();
        meet.loadUserSubjectMeetings(user, detailsMeetings);

        loadUserReminders(user);

        // retrieve year and month
        YearMonth currentYearMonth = YearMonth.from(DcurrentDate);
        int year = currentYearMonth.getYear();
        int month = currentYearMonth.getMonthValue();

        // set the table and the headers
        String[] cols = {"Sun", "Mond", "Tues", "Wedn", "Thur", "Frid", "Sat"};
        int numRows = 6; // Max num of rows in a month
        DefaultTableModel modelCal = new DefaultTableModel(cols, numRows) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make cell non-editable
                return false;
            }
        };
        calendarTable.setModel(modelCal);

        // first day of the month
        LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);

        // get the day of the week for the first day of the month
        int startDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7;

        // number of days in the month
        int daysInMonth = currentYearMonth.lengthOfMonth();

        // populate the table
        int row = 0;
        int col = startDayOfWeek;
        for (int day = 1; day <= daysInMonth; day++) {
            modelCal.setValueAt(day, row, col);
            if (col == 6) {
                // move to the next row if it's Saturday
                row++;
                col = 0;
            } else {
                // move to the next column
                col++;
            }
        }

        calendarTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                // invoke super method to get the default renderer
                JLabel c = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                LocalDate cellDate = firstDayOfMonth.plusDays((row * 7) + column - startDayOfWeek);
                String dayOfWeekFull = cellDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);

                boolean hasProject = projectDetails.containsKey(cellDate);
                boolean hasAnnouncement = announcementDetails.containsKey(cellDate);
                boolean hasMeeting = detailsMeetings.containsKey(dayOfWeekFull);

                // retrieve the value in the cell
                Object cellValue = table.getValueAt(row, column);

                // set the color cell of today's day to gray
                if (cellValue != null && cellValue instanceof Integer && ((int) cellValue) == LocalDate.now().getDayOfMonth()) {
                    c.setBackground(new Color(205, 204, 204));
                } else {
                    // reset background color for the rest of the cells
                    c.setBackground(Color.WHITE);
                }

                if (hasProject && hasAnnouncement && hasMeeting) {
                    c.setIcon(new MultipleDotsIcon(Color.BLUE, Color.RED, Color.GREEN));
                    c.setToolTipText("Multiple events, click for details");
                } else if (hasProject) {
                    c.setIcon(new DotIcon(Color.BLUE));
                    c.setToolTipText("Project deadline, click for details");
                } else if (hasAnnouncement) {
                    c.setIcon(new DotIcon(Color.RED));
                    c.setToolTipText("Announcement today, click for details");
                } else if (hasMeeting) {
                    c.setIcon(new DotIcon(Color.GREEN));
                    c.setToolTipText("Meeting today, click for details");
                } else {
                    c.setIcon(null);
                }

                if (userReminders.containsKey(cellDate)) {
                    c.setIcon(new DotIcon(Color.BLACK));
                    String reminderTooltip = "<html>";
                    for (String[] details : userReminders.get(cellDate)) {
                        reminderTooltip += "Reminder: " + details[0] + " - " + details[1] + "<br>";
                    }
                    reminderTooltip += "</html>";
                    c.setToolTipText(reminderTooltip);
                }

                c.setHorizontalAlignment(JLabel.CENTER); // Ensure text is centered
                return c;
            }
        });

        calendarTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Check for double click
                    int row = calendarTable.rowAtPoint(e.getPoint());
                    int column = calendarTable.columnAtPoint(e.getPoint());
                    LocalDate firstDayOfMonth = LocalDate.of(currentYearMonth.getYear(), currentYearMonth.getMonthValue(), 1);
                    int startDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7;
                    LocalDate cellDate = firstDayOfMonth.plusDays((row * 7) + column - startDayOfWeek);
                    Reminder reminder = new Reminder();
                    reminder.handleReminderInput(cellDate, calendarTable, user);
                }
            }
        });

        calendarTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    int row = calendarTable.rowAtPoint(e.getPoint());
                    int column = calendarTable.columnAtPoint(e.getPoint());
                    LocalDate cellDate = firstDayOfMonth.plusDays((row * 7) + column - startDayOfWeek);
                    String dayOfWeekFull = cellDate.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH);

                    if (projectDetails.containsKey(cellDate)) {
                        String[] details = projectDetails.get(cellDate);
                        String message = "Today is the deadline for the " + details[1] + " in " + details[0];
                        JOptionPane.showMessageDialog(calendarTable, message, "Project Deadline", JOptionPane.INFORMATION_MESSAGE);
                    }

                    if (announcementDetails.containsKey(cellDate)) {
                        String[] ann_details = announcementDetails.get(cellDate);
                        String message = ann_details[1] + " says: " + ann_details[0];
                        JOptionPane.showMessageDialog(calendarTable, message, ann_details[2], JOptionPane.INFORMATION_MESSAGE);
                    }

                    if (userReminders.containsKey(cellDate)) {
                        List<String[]> rem_details = userReminders.get(cellDate);
                        StringBuilder message = new StringBuilder();
                        for (String[] details : rem_details) {
                            if (message.length() > 0) {
                                message.append("\n");
                            }
                            message.append("Reminder: ").append(details[0]).append(" - ").append(details[1]);
                        }
                        JOptionPane.showMessageDialog(calendarTable, message.toString(), "Reminders", JOptionPane.INFORMATION_MESSAGE);
                    }

                    if (detailsMeetings.containsKey(dayOfWeekFull)) {
                        List<String[]> meetings = detailsMeetings.get(dayOfWeekFull);
                        for (String[] meetingDetails : meetings) {
                            String status = meetingDetails[4];
                            String meetingSubject = meetingDetails[0];
                            String startTime = meetingDetails[2];
                            String endTime = meetingDetails[3];

                            String alertMessage;
                            if ("canceled".equalsIgnoreCase(status)) {
                                alertMessage = "The meeting for " + meetingSubject + " has been canceled.";
                            } else if ("postponed".equalsIgnoreCase(status)) {
                                alertMessage = "The meeting for " + meetingSubject + " has been postponed. You will be notified of the specific day and hour.";
                            } else {
                                alertMessage = "Your meeting for " + meetingSubject + " is " + status + " for today at " + startTime + " - " + endTime;
                            }
                            JOptionPane.showMessageDialog(calendarTable, alertMessage, "Meeting Status", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
        });

    }

    public void setupCalendar(JTable calendarTable) {
        // Get the current date
        LocalDate currentDate = LocalDate.now();

        // Get the current month and year
        YearMonth currentYearMonth = YearMonth.from(currentDate);
        int year = currentYearMonth.getYear();
        int month = currentYearMonth.getMonthValue();

        // Set up table model and headers
        String[] columns = {"Sun", "Mond", "Tues", "Wedn", "Thur", "Fri", "Sat"};
        int numRows = 6; // Maximum number of rows in a month
        DefaultTableModel model = new DefaultTableModel(columns, numRows);
        calendarTable.setModel(model);

        // Get the first day of the month
        LocalDate firstDayOfMonth = LocalDate.of(year, month, 1);

        // Get the day of the week for the first day of the month
        int startDayOfWeek = firstDayOfMonth.getDayOfWeek().getValue() % 7;

        // Get the number of days in the month
        int daysInMonth = currentYearMonth.lengthOfMonth();

        // Populate the table with dates
        int row = 0;
        int column = startDayOfWeek;
        for (int day = 1; day <= daysInMonth; day++) {
            model.setValueAt(day, row, column);
            if (column == 6) {
                // Move to the next row if it's Saturday
                row++;
                column = 0;
            } else {
                // Move to the next column
                column++;
            }
        }

        calendarTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                // Invoke super method to get the default renderer
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Get the value in the cell
                Object cellValue = table.getValueAt(row, column);

                // Highlight the cell if the value is the current day
                if (cellValue != null && cellValue instanceof Integer && ((int) cellValue) == LocalDate.now().getDayOfMonth()) {
                    c.setBackground(new Color(255, 204, 204)); // Light pink color
                } else {
                    // Reset background color for other cells
                    c.setBackground(Color.WHITE);
                }

                return c;
            }
        });
    }

    private void loadUserReminders(User user) {
        String sql = "SELECT date, remindersTitle, remindersText FROM reminders WHERE username = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user.getUsername());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                LocalDate reminderDate = rs.getDate("date").toLocalDate();
                String title = rs.getString("remindersTitle");
                String text = rs.getString("remindersText");

                if (!userReminders.containsKey(reminderDate)) {
                    userReminders.put(reminderDate, new ArrayList<>());
                }
                userReminders.get(reminderDate).add(new String[] {title, text});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

