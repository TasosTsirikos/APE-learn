import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LobbyGUITeacher extends JFrame{
    private JList list1;
    private JButton acceptAllStudentsButton;
    private JButton acceptSelectedStudentsButton;
    private JPanel lobbyPanel;
    private User user;

    public LobbyGUITeacher(JFrame parent, User user, String id) {
        this.user = user;
        Subjects subject = new Subjects();
        Lobby lobby = new Lobby();
        setTitle("Lobby...");
        setContentPane(lobbyPanel);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        lobby.updateLobbyList(list1);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });

        acceptAllStudentsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                acceptAllStudents(id);
            }
        });

        setVisible(true);
    }

    private void acceptAllStudents(String subjectId) {
        for (LobbyEntry entry : Lobby.entries) {
            new studentAttend(null, new User(entry.getUsername()), subjectId);
        }
        Lobby.entries.clear();
        Lobby.updateLobbyList(list1);
    }
}
