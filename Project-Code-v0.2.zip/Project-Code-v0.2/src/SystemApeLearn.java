import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class SystemApeLearn {


    public void updateTime(JLabel timeLabel) {
        LocalDateTime nowDate = LocalDateTime.now();
        DateTimeFormatter formDate = DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm:ss");
        String formedDateTime = nowDate.format(formDate);
        timeLabel.setText(formedDateTime);
    }

    public User getAuthenticateUser(String username, String password, User user){
        user = null;

        final String URL = "jdbc:mysql://localhost:3306/softengin23_24";
        final String USERNAME = "root";
        final String PASSWORD = "W45@jqr#8CX";

        try{
            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                user = new User(null);
                user.username = resultSet.getString("username");
                user.password = resultSet.getString("password");
                user.name = resultSet.getString("name");
                user.email = resultSet.getString("email");
                user.type = resultSet.getString("type");
            }

            stmt.close();
            conn.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }

        return user;
    }

    public void openFileWithDesktopApp(String fileInfo) {
        String filePath = extractFilePath(fileInfo);
        File fileToOpen = new File(filePath);
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();
            try {
                desktop.open(fileToOpen);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(null, "Unable to open file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Desktop is not supported on this platform.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String extractFilePath(String fileInfo) {
        return "/path/to/file";
    }

    public void resetTable(JTable dtTable) {
        // clear current table model
        DefaultTableModel dtTableModel = (DefaultTableModel) dtTable.getModel();
        DefaultTableModel model = (DefaultTableModel) dtTable.getModel();
        model.setRowCount(0); // Clear rows

        // reload original table model
        for (int i = 0; i < dtTableModel.getRowCount(); i++) {
            Object[] row = new Object[dtTableModel.getColumnCount()];
            for (int j = 0; j < dtTableModel.getColumnCount(); j++) {
                row[j] = dtTableModel.getValueAt(i, j);
            }
            model.addRow(row);
        }
        dtTable.setModel(model);
        DiplomaThesis dt = new DiplomaThesis();
        dt.populateTable(dtTable, dtTableModel);
    }

    public void displayEnrollmentPeriodClosedMessage() {
        JOptionPane.showMessageDialog(null, "There is no open enrollment period for Diploma Thesis. You will be redirected to student Menu in 3 seconds.");
    }

    public void handleSendToAdmin(JTextField textField1, JTextField textField2) {
        String username = textField1.getText();
        String reason = textField2.getText();

        // Check if either of the text fields is empty
        if (username.isEmpty() || reason.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Missing information. Please fill out all fields.", "Missing Information", JOptionPane.ERROR_MESSAGE);
            return; // Exit the method if validation fails
        }

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            // Prepare the SQL INSERT query
            String insertQuery = "INSERT INTO emergencies (username, reason) VALUES (?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, reason);

            // Execute the INSERT query
            int rowsAffected = preparedStatement.executeUpdate();

            // Check if the insertion was successful
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Emergency sent to admin!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to send to admin", "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Close resources
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error saving emergency to database", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
