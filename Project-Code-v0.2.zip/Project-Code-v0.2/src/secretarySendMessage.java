import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.time.LocalDate;

public class secretarySendMessage extends JFrame {
    private JPanel sendMessage;
    private JTextField recipientField;
    private JCheckBox toAll;
    private JCheckBox toAllTeachers;
    private JCheckBox toAllStudents;
    private JList inList;
    private JList outList;
    private JTextArea messageBody;
    private JPanel sendMessagePanel;
    private JButton sendButton;
    private JLabel titleLabel;
    private JTextField titleField;
    private User user;


    public secretarySendMessage(JFrame parent, User user) {
        this.user = user;
        setTitle("My Messages");
        setContentPane(sendMessagePanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                sendMessage();
                new secretarySendMessage(null, user);
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                    new secretaryHome(null, user);
            }
        });

        showInMessages();
        showOutMessages();
    }


    private void showInMessages() {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        DefaultListModel<String> inListModel = new DefaultListModel<>();
        StringBuilder inListText = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String recipient = user.username;

            String sql = "SELECT sender, recipient, message_text, title, date " +
                    "FROM my_messages " +
                    "WHERE recipient = ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, recipient);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String sender = resultSet.getString("sender");
                String messageRecipient = resultSet.getString("recipient");
                String messageText = resultSet.getString("message_text");
                String title = resultSet.getString("title");
                String date = resultSet.getString("date");

                inListText.append("<html>");
                inListText.append(sender + " to " + messageRecipient + "<br>About: " + title + "<br>" );

                String textSub = null;
                if (messageText.length() > 65) {
                    textSub = messageText.substring(0, 65) + "...";
                    inListText.append(textSub).append("<br>");
                }
                else{
                    inListText.append(messageText).append("<br>");
                }

                inListText.append("<br>On: " + date);
                inListText.append("<br><hr><br></html>");

                inListModel.addElement(inListText.toString());
                inListText.setLength(0);

            }

            resultSet.close();
            statement.close();
            connection.close();

            inList.setModel(inListModel);

        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    private void showOutMessages() {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        DefaultListModel<String> outListModel = new DefaultListModel<>();
        StringBuilder outListText = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String recipient = user.username;

            String sql = "SELECT sender, recipient, message_text, title, date " +
                    "FROM my_messages " +
                    "WHERE sender = ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, recipient);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String sender = resultSet.getString("sender");
                String messageRecipient = resultSet.getString("recipient");
                String messageText = resultSet.getString("message_text");
                String title = resultSet.getString("title");
                String date = resultSet.getString("date");

                outListText.append("<html>");
                outListText.append(sender + " to " + messageRecipient + "<br>About: " + title + "<br>" );

                String textSub = null;
                if (messageText.length() > 65) {
                    textSub = messageText.substring(0, 65) + "...";
                    outListText.append(textSub).append("<br>");
                }
                else{
                    outListText.append(messageText).append("<br>");
                }

                outListText.append("<br>On: " + date);
                outListText.append("<br><hr><br></html>");

                outListModel.addElement(outListText.toString());
                outListText.setLength(0);

            }

            resultSet.close();
            statement.close();
            connection.close();

            outList.setModel(outListModel);

        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    private void sendMessage() {
        String recipient = recipientField.getText().trim();
        String messageText = messageBody.getText();
        String title = titleField.getText();
        Date currentDate = Date.valueOf(LocalDate.now());

        if (recipient.isEmpty() && (!toAll.isSelected()) && (!toAllTeachers.isSelected()) && (!toAllStudents.isSelected())) {
            JOptionPane.showMessageDialog(this, "Please select a recipient.");
            return;
        }

        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please give a title to your message.");
            return;
        }

        if (messageText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your message doesn't have any body.");
            return;
        }

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            if(toAll.isSelected()){
                String getUsersQuery = "SELECT username FROM users WHERE username NOT LIKE ?";
                PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);
                getUsersStatement.setString(1, user.username);

                ResultSet resultSet = getUsersStatement.executeQuery();

                // Insert message for each user
                while (resultSet.next()) {
                    String recipientUsername = resultSet.getString("username");

                    // Prepare the SQL statement
                    PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                    // Set parameters
                    preparedStatement.setString(1, user.getUsername());
                    preparedStatement.setString(2, recipientUsername);
                    preparedStatement.setString(3, messageText);
                    preparedStatement.setString(4, title);
                    preparedStatement.setDate(5, currentDate);

                    preparedStatement.executeUpdate();

                    // Close the prepared statement
                    preparedStatement.close();
                }

                resultSet.close();
                getUsersStatement.close();
            }
            else if(toAllTeachers.isSelected()){
                String getUsersQuery = "SELECT type,username FROM users WHERE type NOT LIKE 'student'";
                PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);

                ResultSet resultSet = getUsersStatement.executeQuery();

                // Insert message for each user
                while (resultSet.next()) {
                    String recipientUsername = resultSet.getString("username");

                    // Prepare the SQL statement
                    PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                    // Set parameters
                    preparedStatement.setString(1, user.getUsername());
                    preparedStatement.setString(2, recipientUsername);
                    preparedStatement.setString(3, messageText);
                    preparedStatement.setString(4, title);
                    preparedStatement.setDate(5, currentDate);

                    preparedStatement.executeUpdate();

                    preparedStatement.close();
                }

                resultSet.close();
                getUsersStatement.close();
            }
            else if(toAllStudents.isSelected()){
                String getUsersQuery = "SELECT type,username FROM users WHERE type NOT LIKE 'teacher'";
                PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);

                ResultSet resultSet = getUsersStatement.executeQuery();

                // Insert message for each user
                while (resultSet.next()) {
                    String recipientUsername = resultSet.getString("username");

                    // Prepare the SQL statement
                    PreparedStatement preparedStatement = connection.prepareStatement(
                            "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                    // Set parameters
                    preparedStatement.setString(1, user.getUsername());
                    preparedStatement.setString(2, recipientUsername);
                    preparedStatement.setString(3, messageText);
                    preparedStatement.setString(4, title);
                    preparedStatement.setDate(5, currentDate);

                    preparedStatement.executeUpdate();

                    preparedStatement.close();
                }

                resultSet.close();
                getUsersStatement.close();
            }
            else{

                PreparedStatement preparedStatement = connection.prepareStatement(
                        "INSERT INTO my_messages (sender, recipient, message_text, title, date) VALUES (?, ?, ?, ?, ?)");

                // Set parameters
                preparedStatement.setString(1, user.getUsername());
                preparedStatement.setString(2, recipient);
                preparedStatement.setString(3, messageText);
                preparedStatement.setString(4, title);
                preparedStatement.setDate(5, currentDate);

                preparedStatement.executeUpdate();

                preparedStatement.close();
            }
            connection.close();

            // Display success message
            JOptionPane.showMessageDialog(this, "Message sent successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending message: " + ex.getMessage());
        }
    }
}

