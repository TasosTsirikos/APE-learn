import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class studentSubjectProjects extends  JFrame{
    private JTable projectTable;
    private JPanel projectPanel;
    private JLabel projectsTitle;
    private JButton saveButton;
    private User user;

    public studentSubjectProjects(JFrame parent, User user, String id) {
        this.user = user;
        setTitle("My Diploma Thesis");
        setContentPane(projectPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);

            }
        });

        String[] columnNames = {"Project Id", "Project Title", "Project Description", "Till Date", "Upload File"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) projectTable.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < projectTable.getColumnCount(); i++) {
            Class<?> columnClass = projectTable.getColumnClass(i);
            projectTable.setDefaultEditor(columnClass, null);
        }
    }
}
