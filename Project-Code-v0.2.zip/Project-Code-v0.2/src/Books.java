public class Books {
    String isbn_books, booksName, booksAuthor, forSubject, subjectId;

}
