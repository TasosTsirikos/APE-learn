import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class userSubjectProfile extends JFrame{

    private JLabel titleLabel;
    private JLabel infoLabel1;
    private JLabel infoLabel2;
    private JPanel userSubjectProfile;
    private JToolBar jToolBarStudent;
    private JLabel markLabel;
    private JLabel ectsField;
    private JLabel bookField;
    private User user;


    public userSubjectProfile(JFrame parent, User user, String id) {
        this.user = user;
        Subjects subject = new Subjects();
        setTitle("Subject Details");
        setContentPane(userSubjectProfile);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);


        subject.displaySubjectInfo(id, titleLabel, infoLabel1, infoLabel2, ectsField, markLabel);

        JButton seeLectures = new JButton("Lectures");
        JButton seeMarks = new JButton("Grades");
        JButton seeBooks = new JButton("Books");
        JButton projects = new JButton("Projects");
        JButton myTeam = new JButton("My Team");
        JButton attend = new JButton("Attend to Lecture");
        JButton unregister = new JButton("Unregister");


        jToolBarStudent.add(seeLectures);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(seeMarks);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(seeBooks);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(projects);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(myTeam);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(attend);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(unregister);

        seeBooks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                try {
                    new studentSelectBook(null, user, id);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        projects.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentSubjectProjects(null, user, id);
            }
        });

        myTeam.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create the custom dialog
                JDialog dialog = new JDialog((Frame)null, "Enter Project ID", true);
                dialog.setLayout(new FlowLayout());

                JLabel label = new JLabel("Enter the Project ID you want to see your team for:");
                JTextField textField = new JTextField(20);
                JButton okButton = new JButton("OK");
                JButton findTeamButton = new JButton("Find Team");
                JButton cancelButton = new JButton("Cancel");

                dialog.add(label);
                dialog.add(textField);
                dialog.add(okButton);
                dialog.add(cancelButton);
                dialog.add(findTeamButton);

                // Handle OK button action
                okButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String projectId = textField.getText();
                        if (!projectId.trim().isEmpty() && isValidProjectId(projectId.trim())) {
                            if (userExistsInTeamProjects(user.getUsername(), projectId.trim())) {
                                JOptionPane.showMessageDialog(dialog, "You have a team, moving to CoShare!");
                                dialog.dispose();
                                dispose();
                                new StudentTeam(null, user, id, projectId.trim());
                            } else {
                                dialog.dispose();
                                dispose();
                                new studentFindsTeam(null, user, projectId.trim());
                            }
                        } else {
                            JOptionPane.showMessageDialog(dialog, "Invalid Project ID. Please try again.");
                        }
                    }
                });

                findTeamButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        String projectId = textField.getText();
                        dialog.dispose();
                        dispose();
                        new studentFindsTeam(null, user, id);
                    }
                });

                cancelButton.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dialog.dispose();
                    }
                });

                dialog.pack();
                dialog.setLocationRelativeTo(null);
                dialog.setVisible(true);
            }
        });


        seeMarks.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentSeeMarks(null, user, id);
            }
        });

        seeLectures.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new studentSeeLectures(null, user, id);
            }
        });

        attend.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String subjectName = null;
                String querySubject = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

                try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
                     PreparedStatement preparedStatementSubject = connection.prepareStatement(querySubject)) {

                    preparedStatementSubject.setString(1, id);
                    try (ResultSet resultSet = preparedStatementSubject.executeQuery()) {
                        if (resultSet.next()) {
                            subjectName = resultSet.getString("subject_name");
                        } else {
                            JOptionPane.showMessageDialog(null, "No subject found with the given ID.");
                            return; // Exit the action listener if no subject is found
                        }
                    }

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
                    return; // Exit the action listener if there is a database error
                }

                String queryMeeting = "SELECT every1, startTime, status FROM meetings_schedule_subjects WHERE meetingsAbout = ?";

                try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
                     PreparedStatement preparedStatementMeeting = connection.prepareStatement(queryMeeting)) {

                    preparedStatementMeeting.setString(1, subjectName);

                    try (ResultSet resultSet = preparedStatementMeeting.executeQuery()) {
                        if (resultSet.next()) {
                            String every1 = resultSet.getString("every1");
                            String startTimeStr = resultSet.getString("startTime");
                            String status = resultSet.getString("status");

                            // Check the status
                            if ("canceled".equalsIgnoreCase(status)) {
                                JOptionPane.showMessageDialog(null, "The lecture has been canceled. Let me redirect you to studentMenu");
                                    Timer timer = new Timer(1000, r -> {
                                        dispose();
                                        new studentMenuu(null, user);
                                    });
                                    timer.setRepeats(false);
                                    timer.start();

                            } else if ("scheduled".equalsIgnoreCase(status)) {
                                // Get the current day name and time
                                String todayDayName = DayOfWeek.from(LocalDate.now()).name().toLowerCase();
                                LocalTime startTime = LocalTime.parse(startTimeStr, DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH));
                                LocalTime currentTime = LocalTime.now();

                                // Calculate the difference in minutes
                                long minutesDifference = java.time.Duration.between(currentTime, startTime).toMinutes();

                                if (every1.toLowerCase().contains(todayDayName) && minutesDifference > 30) {
                                    JOptionPane.showMessageDialog(null, "The lecture will begin in " + minutesDifference + " minutes.");
                                } else {
                                    dispose();
                                    new LobbyGUIStudent(null, user, id);
                                }
                            } else {
                                dispose();
                                new LobbyGUIStudent(null, user, id);
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "No meeting schedule found.");
                        }
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
                }
            }
        });

        unregister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform SELECT query from my_subjects table
                try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX")) {
                    String query = "SELECT * FROM my_subjects WHERE id_subject = ?";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, id);
                    ResultSet resultSet = preparedStatement.executeQuery();
                    if (resultSet.next()) {
                        String subjectName = resultSet.getString("subject_name");
                        String subjectDescription = resultSet.getString("subject_description");
                        String teacher = resultSet.getString("teacher");
                        String type = resultSet.getString("type");
                        int mark = resultSet.getInt("grade");

                        if (mark >= 5 || (mark < 5 && type.equals("selective"))) {
                            // Perform deletion
                            String deleteQuery = "DELETE FROM my_subjects WHERE id_subject = ?";
                            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery)) {
                                deleteStatement.setString(1, id);
                                deleteStatement.executeUpdate();
                                // perform deletion from my_progress_subjects table
                                String deleteProgress = "DELETE FROM my_progress_subjects WHERE id_subject = ?";
                                try (PreparedStatement deleteProgressStatement = connection.prepareStatement(deleteProgress)) {
                                    deleteProgressStatement.setString(1, id);
                                    deleteProgressStatement.executeUpdate();
                                    JOptionPane.showMessageDialog(null, "Subject unregistered successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

                                } catch (SQLException ex) {
                                    ex.printStackTrace();
                                    JOptionPane.showMessageDialog(null, "Error unregistering subject progress: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                                }
                            } catch (SQLException ex) {
                                ex.printStackTrace();
                                JOptionPane.showMessageDialog(null, "Error unregistering subject: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            // Display message indicating grade does not meet criteria for deletion
                            JOptionPane.showMessageDialog(null, "Subject grade is not sufficient for deletion.", "Information", JOptionPane.INFORMATION_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(userSubjectProfile, "Subject not found!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(userSubjectProfile, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });
        setVisible(true);
    }


    private boolean userExistsInTeamProjects(String username, String projectId) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String user = "root";
        String password = "W45@jqr#8CX";
        String query = "SELECT COUNT(*) AS count FROM teams_projects WHERE username = ? AND id_team_project = ?";

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = DriverManager.getConnection(url, user, password);

            stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, projectId);
            rs = stmt.executeQuery();

            // Check if the count is greater than zero
            if (rs.next() && rs.getInt("count") > 0) {
                return true;
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return false; // No records found
    }

    private boolean isValidProjectId(String projectId) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String user = "root";
        String password = "W45@jqr#8CX";
        String query = "SELECT COUNT(*) AS count FROM projects WHERE idprojects = ?";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, projectId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next() && rs.getInt("count") > 0) {
                    return true;  // Project ID exists
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false; // Project ID does not exist
    }
}

