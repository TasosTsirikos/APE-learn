import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class myProgress extends JFrame{
    private JTable progressTable;
    private JButton swornRequestButton;
    private JLabel passedSubjects;
    private JPanel myProgressPanel;
    private JScrollPane scrollTable;
    private JLabel takenECTS;
    private JLabel averageGrade;
    private User user;


    public myProgress(JFrame parent, User user) {
        this.user = user;

        setTitle("My Progress");
        setContentPane(myProgressPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });

        swornRequestButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String passedSubjectsText = passedSubjects.getText();
                String takenECTSText = takenECTS.getText();

                if (passedSubjectsText.equals("Passed Subjects: 50 / 50") &&
                        takenECTSText.equals("Taken ECTS: 170 / 170")) {
                    JOptionPane.showMessageDialog(null, "You took the Degree!");

                }
                else{
                    System.out.println("You can't take the Certificate");
                    JOptionPane.showMessageDialog(null, "You can't take the Degree", "Error", JOptionPane.ERROR_MESSAGE);

                }
            }
        });

        showPassedSubjects();
        showTakenEcts();
        showAverageGrade();
        populateTable();

    }

    private void populateTable() {
        // Define column names
        String[] columnNames = {"ID", "Subject Name", "Grade", "Type", "Ects"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) progressTable.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < progressTable.getColumnCount(); i++) {
            Class<?> columnClass = progressTable.getColumnClass(i);
            progressTable.setDefaultEditor(columnClass, null);
        }

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            Statement statement = connection.createStatement();

            // Execute query to get user information
            ResultSet resultSet = statement.executeQuery("SELECT id_subject, subject_name, student, grade, type, ects FROM my_progress_subjects WHERE student = '" + user.username + "'");

            // Iterate through the result set and add rows to the table
            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getString("id_subject"),
                        resultSet.getString("subject_name"),
                        resultSet.getInt("grade"),
                        resultSet.getString("type"),
                        resultSet.getInt("ects")
                };
                model.addRow(rowData);
            }

            // Close resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void showPassedSubjects(){
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT COUNT(*) FROM my_progress_subjects WHERE grade >= 5 AND student = '" + user.username + "'";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {
                if (resultSet.next()) {
                    int count = resultSet.getInt(1);
                    System.out.println("Number of rows with grade >= 5: " + count);
                    passedSubjects.setText("Passed Subjects: " + count + " / 50");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showTakenEcts(){
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT SUM(ects) AS total_ects FROM my_progress_subjects WHERE student = '" + user.username + "'";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {
                if (resultSet.next()) {
                    int totalEcts = resultSet.getInt("total_ects");
                    takenECTS.setText("Taken ECTS: " + totalEcts + " / 170");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showAverageGrade(){
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT AVG(grade) AS average_grade FROM my_progress_subjects WHERE student = '" + user.username + "'";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(sql)) {
                if (resultSet.next()) {
                    double averageGradeValue = resultSet.getDouble("average_grade");
                    String averageGradeString = String.valueOf(averageGradeValue);
                    averageGrade.setText("Average Grade: " + averageGradeString);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
