import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class secretaryRequests extends JFrame {
    private JTable table1;
    private JButton sendToAdminButton;
    private JTextField textField1;
    private JTextField textField2;
    private JPanel requestsPanel;
    private JCheckBox checkBox1;
    private User user;

    public secretaryRequests(JFrame parent, User user) {
        this.user = user;
        setTitle("Secretary Menu");
        setContentPane(requestsPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
        Requests requests = new Requests();
        SystemApeLearn sal = new SystemApeLearn();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new secretaryHome(null, user);
            }
        });

        // Load and populate the table with data
        requests.loadRequestsData(table1);

        // Add action listener to sendToAdminButton
        sendToAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sal.handleSendToAdmin(textField1, textField2);
            }
        });
    }
}


