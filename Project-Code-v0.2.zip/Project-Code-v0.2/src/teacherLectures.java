import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;


public class teacherLectures extends JFrame {
    private JTextField dateField;
    private JTable tableLectures;
    private JLabel blobArchive;
    private JLabel topLabel;
    private JPanel lecturesPanel;
    private JButton uploadButton;
    private JButton submitButton;
    private JScrollPane scrollPanel;
    private JButton deleteButton;
    private JButton searchButton;
    private User user;
    private String subjectName;

    public teacherLectures(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);
        setTitle("My Lectures");
        setContentPane(lecturesPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherSubjectProfile(null, user, id);
            }
        });

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                int result = fileChooser.showOpenDialog(teacherLectures.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    System.out.println("Selected File Path: " + selectedFile.getAbsolutePath());
                    blobArchive.setText(selectedFile.getAbsolutePath());
                }
            }
        });

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (dateField.getText().isEmpty() || blobArchive.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(teacherLectures.this, "You need to complete all necessary information for your lecture.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

                    File selectedFile = new File(blobArchive.getText());
                    FileInputStream fis = new FileInputStream(selectedFile);
                    byte[] fileData = new byte[(int) selectedFile.length()];
                    fis.read(fileData);
                    fis.close();

                    String sql = "INSERT INTO lectures (lecture_subject, teacher, date, archive, archive_name) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, subjectName);
                    // Set parameters for the prepared statement
                    statement.setString(2, user.getName());

                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String currentDate = sdf.format(new java.util.Date());
                    statement.setString(3, currentDate);

                    statement.setBytes(4, fileData);
                    statement.setString(5, selectedFile.getName());

                    statement.executeUpdate();

                    statement.close();
                    connection.close();

                    JOptionPane.showMessageDialog(teacherLectures.this, "Record inserted successfully.");

                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(teacherLectures.this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (FileNotFoundException ex) {
                    throw new RuntimeException(ex);
                } catch (IOException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        topLabel.setText(topLabel.getText() + " " + subjectName);

        String[] columnNames = {"Date", "Archive"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) tableLectures.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < tableLectures.getColumnCount(); i++) {
            Class<?> columnClass = tableLectures.getColumnClass(i);
            tableLectures.setDefaultEditor(columnClass, null);
        }

        populateTable();

        tableLectures.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = tableLectures.rowAtPoint(e.getPoint());
                int column = tableLectures.columnAtPoint(e.getPoint());
                if (column == 1) { // Check if the click was in the "Archive" column
                    String filePath = (String) tableLectures.getValueAt(row, column);
                    openFile(filePath);
                }
            }
        });
    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }

    private void populateTable(){
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String sql = "SELECT date, archive, archive_name FROM lectures WHERE lecture_subject = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, subjectName);

            ResultSet resultSet = statement.executeQuery();

            // Create a DefaultTableModel to hold the data
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Date");
            model.addColumn("Archive");

            // Populate the model with data from the result set
            while (resultSet.next()) {
                String date = resultSet.getString("date");
                Blob blob = resultSet.getBlob("archive");
                byte[] fileData = blob.getBytes(1, (int) blob.length());
                // Get the archive name
                String archiveName = resultSet.getString("archive_name");
                // Save the file data to a temporary file using the retrieved archive name
                saveBytesToFile(archiveName, fileData);
                model.addRow(new Object[]{date, archiveName});
            }

            // Set the table model to the tableLectures
            tableLectures.setModel(model);

            tableLectures.getColumnModel().getColumn(1).setCellRenderer(new LinkRenderer());


            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(teacherLectures.this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void saveBytesToFile(String fileName, byte[] bytes) throws IOException {
        FileOutputStream fos = new FileOutputStream(fileName);
        fos.write(bytes);
        fos.close();
    }

    private void openFile(String filePath) {
        try {
            File file = new File(filePath);
            if (Desktop.isDesktopSupported() && file.exists()) {
                Desktop desktop = Desktop.getDesktop();
                desktop.open(file);
            } else {
                JOptionPane.showMessageDialog(teacherLectures.this, "File does not exist or Desktop API is not supported.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(teacherLectures.this, "Error opening file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}