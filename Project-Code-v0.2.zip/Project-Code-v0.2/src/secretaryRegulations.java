import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class secretaryRegulations extends JFrame{
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton setButton;
    private JPanel secrRegPanel;
    private User user;

    public secretaryRegulations(JFrame parent, User user) {
        this.user = user;
        setTitle("Secretary Menu");
        setContentPane(secrRegPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new secretaryHome(null, user);
            }
        });
    }
}
