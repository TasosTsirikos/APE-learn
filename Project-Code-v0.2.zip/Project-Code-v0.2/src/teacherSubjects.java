import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class teacherSubjects extends JFrame{
    private JTextField titleField;
    private JTextField everyField;
    private JTextField startTimeField;
    private JTextField endTimeField;
    private JTextField descriptionField;
    private JComboBox typeComboBox;
    private JComboBox yearComboBox;
    private JComboBox semesterComboBox;
    private JTextField idField;
    private JTable table1;
    private JButton addSubjectButton;
    private JPanel newEndTime;
    private JPanel newEnd;
    private JPanel newStartTime;
    private JPanel newStart;
    private JPanel mySubjectPanel;
    private JButton deleteSubjectButton;
    private User user;

    public teacherSubjects(JFrame parent, User user) {
        this.user = user;
        setTitle("My Subjects");
        setContentPane(mySubjectPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherMenuu(null, user);
            }
        });
        setVisible(true);
    }
}
