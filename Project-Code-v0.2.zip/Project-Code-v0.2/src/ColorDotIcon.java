import javax.swing.*;
import java.awt.*;

class ColorDotIcon implements Icon {
    private final Color color;
    private final int diameter;

    public ColorDotIcon(Color color, int diameter) {
        this.color = color;
        this.diameter = diameter;
    }

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.fillOval(x, y, diameter, diameter);
    }

    @Override
    public int getIconWidth() {
        return diameter;
    }

    @Override
    public int getIconHeight() {
        return diameter;
    }
}