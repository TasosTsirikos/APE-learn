public class Secretary extends User{
    public Secretary(String username) {
        super(username);
    }

    public String getUsername() {
        return super.getUsername();
    }

    public String getName() {
        return super.getName();
    }
    public String getType() {
        return super.getType();
    }
    public int getId() {
        return super.getId();
    }
}
