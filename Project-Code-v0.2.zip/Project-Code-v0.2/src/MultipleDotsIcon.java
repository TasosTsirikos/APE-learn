import javax.swing.*;
import java.awt.*;

class MultipleDotsIcon implements Icon {
    private final Color[] colors;
    private final int diameter = 6;
    private final int padding = 4;

    public MultipleDotsIcon(Color... colors) {
        this.colors = colors;
    }

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        for (int i = 0; i < colors.length; i++) {
            g.setColor(colors[i]);
            g.fillOval(x + (diameter + padding) * i, y, diameter, diameter);
        }
    }

    @Override
    public int getIconWidth() {
        return (diameter + padding) * colors.length - padding;
    }

    @Override
    public int getIconHeight() {
        return diameter;
    }
}
