import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class DiplomaThesis {
    public void populateTable(JTable dtTable, DefaultTableModel dtTableModel) {
        // column names
        String[] columnNames = {"ID", "Title", "Description", "Teacher"};

        DefaultTableModel model = (DefaultTableModel) dtTable.getModel();
        model.setColumnIdentifiers(columnNames);

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            Statement statement = con.createStatement();
            ResultSet res = statement.executeQuery("SELECT id_diploma_thesis, title, description, teacher FROM diploma_thesis");

            while (res.next()) {
                int id = res.getInt("id_diploma_thesis");
                String title = res.getString("title");
                String description = res.getString("description");
                String teacher = res.getString("teacher");
                model.addRow(new Object[]{id, title, description, teacher});
            }

            // close connections
            res.close();
            statement.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        dtTable.setModel(model);
        dtTableModel = model;
    }

    public void searchDiplomaThesis(String teacher, String title, JTable dtTable) {
        DefaultTableModel dtModel = (DefaultTableModel) dtTable.getModel();
        dtModel.setRowCount(0); // clear previous search results

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            Statement statement = connection.createStatement();

            // execute sql query based on search info
            String query;
            if (!teacher.isEmpty()) {
                query = "SELECT * FROM diploma_thesis WHERE teacher LIKE '%" + teacher + "%'";
            } else if (!title.isEmpty()) {
                query = "SELECT * FROM diploma_thesis WHERE title LIKE '%" + title + "%'";
            } else {
                // if both fields are empty, display all records
                query = "SELECT * FROM diploma_thesis";
            }

            ResultSet resultSet = statement.executeQuery(query);

            // populate JTable with the results
            boolean found = false;
            while (resultSet.next()) {
                found = true;
                int id = resultSet.getInt("id_diploma_thesis");
                String titleDT = resultSet.getString("title");
                String description = resultSet.getString("description");
                String teacherDT = resultSet.getString("teacher");
                dtModel.addRow(new Object[]{id, titleDT, description, teacherDT});
            }

            // close connection
            resultSet.close();
            statement.close();
            connection.close();

            if (!found) {
                JOptionPane.showMessageDialog(null, "No diploma theses found for given information", "No Results", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public String getDiplomaThesisTeamID(String username) {
        String teamID = null;
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String dbUser = "root";
        String dbPassword = "W45@jqr#8CX";

        try (Connection connection = DriverManager.getConnection(url, dbUser, dbPassword)) {
            String query = "SELECT iddiplomaThesisTeams FROM diplomathesisteams WHERE student = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        teamID = resultSet.getString("iddiplomaThesisTeams");
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return teamID;
    }
}
