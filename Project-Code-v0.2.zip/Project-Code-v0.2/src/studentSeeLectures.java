import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.*;

public class studentSeeLectures extends JFrame{
    private JTextField dateField;
    private JButton searchButton;
    private JScrollPane lecturePanel;
    private JTable lectureTable;
    private JLabel lecturesTitle;
    private JPanel lectures;
    private User user;

    private String subjectName;


    public studentSeeLectures(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);

        setTitle("Subject Lectures");
        setContentPane(lectures);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        lecturesTitle.setText("Lectures for Subject: " + subjectName);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);
            }
        });

        String[] columnNames = {"Date", "Archive"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) lectureTable.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < lectureTable.getColumnCount(); i++) {
            Class<?> columnClass = lectureTable.getColumnClass(i);
            lectureTable.setDefaultEditor(columnClass, null);
        }

        populateTable();
    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");

            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }

    private void populateTable(){
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");

            // Prepare SQL statement to select date and archive based on lecture subject
            String sql = "SELECT date, archive, archive_name FROM lectures WHERE lecture_subject = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, subjectName);

            ResultSet resultSet = statement.executeQuery();

            //DefaultTableModel to hold the data
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Date");
            model.addColumn("Archive");

            // Populate the model with data from the result set
            while (resultSet.next()) {
                String date = resultSet.getString("date");
                Blob blob = resultSet.getBlob("archive");
                byte[] fileData = blob.getBytes(1, (int) blob.length());
                // Get the archive name
                String archiveName = resultSet.getString("archive_name");
                // Save the file data to a temporary file using the retrieved archive name
                saveBytesToFile(archiveName, fileData);
                model.addRow(new Object[]{date, archiveName});
            }

            // Set the table model to the tableLectures
            lectureTable.setModel(model);

            lectureTable.getColumnModel().getColumn(1).setCellRenderer(new LinkRenderer());


            resultSet.close();
            statement.close();
            connection.close();

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(studentSeeLectures.this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        lectureTable.setDefaultEditor(Object.class, null);
    }

    private void saveBytesToFile(String fileName, byte[] bytes) throws IOException {
        FileOutputStream fos = new FileOutputStream(fileName);
        fos.write(bytes);
        fos.close();
    }
}
