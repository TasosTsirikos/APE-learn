import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class studentSelectBook extends JFrame{
    private JPanel bookPanel;
    private JTextField authorField;
    private JTextField isbnField;
    private JButton searchButton;
    private JTable bookTable;
    private JScrollPane tableBookPanel;
    private JButton selectButton;
    private JLabel titleField;
    private User user;


    public studentSelectBook(JFrame parent, User user, String id) throws SQLException {
        this.user = user;

        setTitle("Select a Book");
        setContentPane(bookPanel);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        DefaultTableModel model = new DefaultTableModel(new Object[]{"ISBN", "Author", "Book Name"}, 0);
        bookTable.setModel(model);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);
            }
        });

        String subjectName = showTitle(id);
        if (subjectName != null) {
            titleField.setText("Select Book for " + subjectName);
        } else {
            titleField.setText("Select Book");
        }

        bookTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = bookTable.getSelectedRow();
                    if (selectedRow != -1) {
                        String isbn = (String) model.getValueAt(selectedRow, 0);
                        String author = (String) model.getValueAt(selectedRow, 1);
                        String bookName = (String) model.getValueAt(selectedRow, 2);
                        showBookDetails(isbn, author, bookName);
                    }
                }
            }
        });

        selectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = bookTable.getSelectedRow();
                if (selectedRow != -1) {
                    String isbn = bookTable.getValueAt(selectedRow, 0).toString();
                    String subjectId = id;

                    String url = "jdbc:mysql://localhost:3306/softengin23_24";
                    String username = "root";
                    String password = "W45@jqr#8CX";

                    try (Connection connection = DriverManager.getConnection(url, username, password)){
                        // Query to check if the user has already taken this book for the selected subject
                        String query = "SELECT isbn_book FROM my_subjects WHERE id_subject = ? AND isbn_book = ? AND student = ?";
                        PreparedStatement preparedStatement = connection.prepareStatement(query);
                        preparedStatement.setString(1, subjectId);
                        preparedStatement.setString(2, isbn);
                        preparedStatement.setString(3, user.getUsername());
                        ResultSet resultSet = preparedStatement.executeQuery();

                        if (resultSet.next()) {
                            // User has already taken this book for the selected subject
                            JOptionPane.showMessageDialog(studentSelectBook.this, "You have already taken this book.");
                        } else {
                            addBooksInDatabase(subjectId);
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(studentSelectBook.this, "Please select a book from the table.");
                }
            }
        });

        showTitle(id);
        populateTable(id);

        setVisible(true);
    }

    private String showTitle(String id) throws SQLException {
        String subjectName = null;
        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {

            // Prepare SQL statement
            String sql = "SELECT subject_name FROM subjects WHERE idsubjects = ?";
            statement = connection.prepareStatement(sql);
            statement.setString(1, id);

            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return subjectName;
    }

    private void populateTable(String subjectId) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "SELECT isbn_books, booksAuthor, booksName FROM books WHERE subjectId = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, subjectId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    DefaultTableModel model = (DefaultTableModel) bookTable.getModel();
                    while (resultSet.next()) {
                        String isbn = resultSet.getString("isbn_books");
                        String author = resultSet.getString("booksAuthor");
                        String bookName = resultSet.getString("booksName");
                        model.addRow(new Object[]{isbn, author, bookName});
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showBookDetails(String isbn, String author, String bookName) {

        JOptionPane.showMessageDialog(this, "ISBN: " + isbn + "\nAuthor: " + author + "\nBook Name: " + bookName, "Book Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void addBooksInDatabase(String id) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // Update my_subjects table
            String updateQuery1 = "UPDATE my_subjects SET isbn_book = ? WHERE id_subject = ?";
            try (PreparedStatement statement1 = connection.prepareStatement(updateQuery1)) {
                String selectedISBN = getSelectedISBN();
                statement1.setString(1, selectedISBN);
                statement1.setString(2, id);
                statement1.executeUpdate();
            }

            // Update my_progress_subjects table
            String updateQuery2 = "UPDATE my_progress_subjects SET isbn_book = ? WHERE id_subject = ?";
            try (PreparedStatement statement2 = connection.prepareStatement(updateQuery2)) {
                String selectedISBN = getSelectedISBN();
                statement2.setString(1, selectedISBN);
                statement2.setString(2, id);
                statement2.executeUpdate();
                JOptionPane.showMessageDialog(null, "Book selected successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String getSelectedISBN() {
        int selectedRow = bookTable.getSelectedRow();
        if (selectedRow != -1) {
            return (String) bookTable.getValueAt(selectedRow, 0);
        }
        return null;
    }


}

