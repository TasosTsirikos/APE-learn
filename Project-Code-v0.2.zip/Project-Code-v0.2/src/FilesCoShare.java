import javax.swing.*;
import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.util.Base64;
import java.util.Date;
public class FilesCoShare {
    private File selectedFile;
    private User user;
    private String teamID;

    public FilesCoShare(User user, File selectedFile, String teamID) {
        this.user = user;
        this.selectedFile = selectedFile;
        this.teamID = teamID;
    }

    public void setSelectedFile(File file) {
        this.selectedFile = file;
    }

    public void insertFileIntoDatabase(String branchName, byte[] fileContent) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";
        String selectBranchIdSQL = "SELECT idbranch, teamId FROM co_share_branch_projects WHERE branchName = ?";
        String insertFileSQL = "INSERT INTO co_share_file_projects (fileName, fileType, fileSize, dateUploaded, ownerUsername, branchId, version, description, teamID, fileContent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement selectStmt = conn.prepareStatement(selectBranchIdSQL);
             PreparedStatement insertStmt = conn.prepareStatement(insertFileSQL)) {

            selectStmt.setString(1, branchName);
            ResultSet rs = selectStmt.executeQuery();
            if (rs.next()) {
                int branchId = rs.getInt("idbranch");
                int teamID = rs.getInt("teamId");

                insertStmt.setString(1, selectedFile.getName());
                insertStmt.setString(2, getFileExtension(selectedFile.getName()));
                insertStmt.setLong(3, selectedFile.length());
                insertStmt.setTimestamp(4, new Timestamp(new Date().getTime()));
                insertStmt.setString(5, user.getUsername());
                insertStmt.setInt(6, branchId);
                insertStmt.setString(7, "0.1");
                insertStmt.setNull(8, Types.VARCHAR);
                insertStmt.setString(9, this.teamID);
                insertStmt.setBytes(10, fileContent);

                insertStmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "File successfully uploaded.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Branch not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private String getBranchPath(String branchName, Connection conn) throws SQLException {
        String query = "SELECT parentBranchName FROM co_share_branch_diploma_thesis WHERE branchName = ?";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, branchName);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            String parentBranchName = rs.getString("parentBranchName");
            if (parentBranchName != null && parentBranchName != "No Parent (Main Branch)" && !parentBranchName.isEmpty()) {
                return getBranchPath(parentBranchName, conn) + "/" + branchName;
            }
        }
        return branchName;
    }

    public void insertFileIntoDatabaseDT(String branchName, byte[] fileContent) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";
        String selectBranchIdSQL = "SELECT idbranch, teamId FROM co_share_branch_diploma_thesis WHERE branchName = ?";
        String insertFileSQL = "INSERT INTO co_share_file_diploma_thesis (fileName, fileType, fileSize, dateUploaded, ownerUsername, branchId, version, description, teamID, fileContent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement selectStmt = conn.prepareStatement(selectBranchIdSQL);
             PreparedStatement insertStmt = conn.prepareStatement(insertFileSQL)) {

            selectStmt.setString(1, branchName);
            ResultSet rs = selectStmt.executeQuery();
            if (rs.next()) {
                int branchId = rs.getInt("idbranch");
                int teamID = rs.getInt("teamId");

                insertStmt.setString(1, selectedFile.getName());
                insertStmt.setString(2, getFileExtension(selectedFile.getName()));
                insertStmt.setLong(3, selectedFile.length());
                insertStmt.setTimestamp(4, new Timestamp(new Date().getTime()));
                insertStmt.setString(5, user.getUsername());
                insertStmt.setInt(6, branchId);
                insertStmt.setString(7, "0.1");
                insertStmt.setNull(8, Types.VARCHAR);
                insertStmt.setString(9, this.teamID);
                insertStmt.setBytes(10, fileContent);

                insertStmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "File successfully uploaded.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Branch not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return dotIndex > 0 ? fileName.substring(dotIndex + 1) : "";
    }

    public String checkFile(String fileName, byte[] fileContent) throws SQLException, NoSuchAlgorithmException {
        String fileHash = hashFileContent(fileContent);
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmtName = conn.prepareStatement("SELECT fileName FROM co_share_file_diploma_thesis WHERE fileName = ?");
             PreparedStatement stmtContent = conn.prepareStatement("SELECT fileContent FROM co_share_file_diploma_thesis WHERE fileContent = ?")) {

            // Check for same file name
            stmtName.setString(1, fileName);
            ResultSet rsName = stmtName.executeQuery();
            if (rsName.next()) {
                return "sameName";
            }

            // Check for same file content
            stmtContent.setString(1, fileHash);
            ResultSet rsContent = stmtContent.executeQuery();
            if (rsContent.next()) {
                return "sameContent";
            }
        }
        return "allOk";
    }

    public String checkFileProjects(String fileName, byte[] fileContent) throws SQLException, NoSuchAlgorithmException {
        String fileHash = hashFileContent(fileContent);
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement stmtName = conn.prepareStatement("SELECT fileName FROM co_share_file_projects WHERE fileName = ?");
             PreparedStatement stmtContent = conn.prepareStatement("SELECT fileContent FROM co_share_file_projects WHERE fileContent = ?")) {

            // Check for same file name
            stmtName.setString(1, fileName);
            ResultSet rsName = stmtName.executeQuery();
            if (rsName.next()) {
                return "sameName";
            }

            // Check for same file content
            stmtContent.setString(1, fileHash);
            ResultSet rsContent = stmtContent.executeQuery();
            if (rsContent.next()) {
                return "sameContent";
            }
        }
        return "allOk";
    }

    private String hashFileContent(byte[] fileContent) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] encodedhash = digest.digest(fileContent);
        return Base64.getEncoder().encodeToString(encodedhash);
    }

    public void updateVersion(String branchName, byte[] fileContent, File selectedFile, User user){
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";
        String selectBranchIdSQL = "SELECT idbranch, teamId FROM co_share_branch_projects WHERE branchName = ?";
        String insertFile = "INSERT INTO co_share_file_projects (fileName, fileType, fileSize, dateUploaded, ownerUsername, branchId, version, description, teamID, fileContent) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        String selectLatestVersion = "SELECT version FROM co_share_file_projects WHERE branchId = ? ORDER BY dateUploaded DESC LIMIT 1";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement selectBranchStmt = conn.prepareStatement(selectBranchIdSQL);
             PreparedStatement insertStmt = conn.prepareStatement(insertFile);
             PreparedStatement selectVersionStmt = conn.prepareStatement(selectLatestVersion)) {

            selectBranchStmt.setString(1, branchName);
            ResultSet rsBranch = selectBranchStmt.executeQuery();
            if (rsBranch.next()) {
                int branchId = rsBranch.getInt("idbranch");
                int teamID = rsBranch.getInt("teamId");

                selectVersionStmt.setInt(1, branchId);
                ResultSet rsVersion = selectVersionStmt.executeQuery();
                String version = "0.1"; // Default version if no records found
                if (rsVersion.next()) {
                    float lastVersion = Float.parseFloat(rsVersion.getString("version"));
                    version = String.format("%.1f", lastVersion + 0.1);
                }

                insertStmt.setString(1, selectedFile.getName());
                insertStmt.setString(2, getFileExtension(selectedFile.getName()));
                insertStmt.setLong(3, selectedFile.length());
                insertStmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
                insertStmt.setString(5, user.getUsername());
                insertStmt.setInt(6, branchId);
                insertStmt.setString(7, version);
                insertStmt.setNull(8, Types.VARCHAR);
                insertStmt.setString(9, Integer.toString(teamID));
                insertStmt.setBytes(10, fileContent);

                insertStmt.executeUpdate();
                JOptionPane.showMessageDialog(null, "New version " + version + " of the file created successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Branch not found.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void replaceFile(String teamId){
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";
        String selectIdSQL = "SELECT idfile FROM co_share_file_projects WHERE fileName = ? AND teamID = ?";
        String updateFileSQL = "UPDATE co_share_file_projects SET fileName = ? WHERE idfile = ? AND teamID = ?";

        try (Connection conn = DriverManager.getConnection(url, username, password);
             PreparedStatement selectStmt = conn.prepareStatement(selectIdSQL);
             PreparedStatement updateStmt = conn.prepareStatement(updateFileSQL)) {

            // Prepare and execute the select statement to find the idfile
            selectStmt.setString(1, selectedFile.getName());
            selectStmt.setString(2, teamId);
            ResultSet rs = selectStmt.executeQuery();

            // Check if the result set has at least one entry
            if (rs.next()) {
                int idFile = rs.getInt("idfile");

                // Prepare and execute the update statement
                updateStmt.setString(1, selectedFile.getName());
                updateStmt.setInt(2, idFile);
                updateStmt.setString(3, teamId);
                int affectedRows = updateStmt.executeUpdate();

                // feedback about the operation
                if (affectedRows > 0) {
                    JOptionPane.showMessageDialog(null, "File replaced successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No changes were made. File not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "File not found in database.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

