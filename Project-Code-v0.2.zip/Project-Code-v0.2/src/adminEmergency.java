import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Timer;
import java.util.TimerTask;

public class adminEmergency extends JFrame {
    private JTable table1;
    private JButton authorizeButton;
    private JPanel adminEmergencyPanel;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JButton searchButton;
    private static boolean isAuthorized = false; // Static variable to track authorization state
    private static long authorizationTime;
    private static final long ONE_HOUR = 3600000L; // 1 hour in milliseconds
    private User user;

    public adminEmergency(JFrame parent, User user) {
        this.user = user;
        setTitle("Admin Emergency");
        setContentPane(adminEmergencyPanel);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);
        Emergencies emergencies = new Emergencies();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new adminHome(null, user);
            }
        });

        // Load and populate the table with data from the emergencies table
        emergencies.loadEmergencyData(table1);

        authorizeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isAuthorized = true;
                authorizationTime = System.currentTimeMillis();
                JOptionPane.showMessageDialog(adminEmergency.this, "User authorized for 1 hour.", "Authorization", JOptionPane.INFORMATION_MESSAGE);

                // Start the timer to revoke authorization after 1 hour
                new Timer().schedule(new TimerTask() {
                    @Override
                    public void run() {
                        isAuthorized = false;
                        System.out.println("You reached the time limit. Admin will be notified. You will be redirected to secretary Menu.");
                        SwingUtilities.invokeLater(() -> new secretaryHome(null, user));
                        dispose();
                    }
                }, ONE_HOUR);
            }
        });
    }
    public static boolean isAuthorized() {
        return isAuthorized;
    }
}



