import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.List;

public class studentFindsTeam extends  JFrame{
    private JList<String> list1;
    private JList list2;
    private JTextField textField2;
    private JTextField textField3;
    private JButton searchButton;
    private JTextField textField1;
    private JButton sentRequestsButton;
    private JButton joinTeamButton;
    private JPanel findTeamPanel;
    private JList<String> list3;
    private JButton declareTeamButton;
    private JTextField textField4;
    private User user;
    private String subjectName;

    public studentFindsTeam(JFrame parent, User user, String id) {
        this.user = user;
        Subjects subj = new Subjects();
        subjectName = subj.fetchSubjectName(id);
        setTitle("My Diploma Thesis");
        setContentPane(findTeamPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);

            }
        });

        sentRequestsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                sendRequest();
            }
        });

        subj.loadStudents(user, id, list1);

    }

    private void sendRequest() {
        String projectId = textField1.getText();
        Projects project = new Projects();
        int maxTeamNumber = project.getMaxTeamNumber(projectId, subjectName);
        if (maxTeamNumber == 1) {
            JOptionPane.showMessageDialog(this, "This project is for only 1 person.");
            return;
        }

        List<String> selectedStudents = list1.getSelectedValuesList();
        DefaultListModel<String> model = (DefaultListModel<String>) list3.getModel();

        for (String student : selectedStudents) {
            if (model.getSize() + 1 > maxTeamNumber) {
                JOptionPane.showMessageDialog(this, "You have exceeded the max number of members for your team.");
                break; // Stop adding more members as limit is reached
            }
            if (!model.contains(student)) { // Prevents duplicate entries
                model.addElement(student);
                TeamProjects team = new TeamProjects();
                if (!team.studentBelongsToTeam(student, projectId)) {
                    project.updateProject(student, projectId, subjectName);
                    JOptionPane.showMessageDialog(this, "Request sent successfully.");
                } else {
                    model.removeElement(student); // Remove the student from the model if they are already in a team
                }
            }
        }
    }

    private void createUIComponents() {
        list1 = new JList<>(new DefaultListModel<>());

        list3 = new JList<>(new DefaultListModel<>());
    }



}
