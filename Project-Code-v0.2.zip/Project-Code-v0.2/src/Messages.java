import javax.swing.*;
import java.sql.*;
import java.util.List;

public class Messages {
    public String sender;
    public String recipient;
    public String message_text;
    public String message_title;
    public String message_date;
    public int id_message;

    public String getSender() {
        return sender;
    }
    public String getRecipient() {
        return recipient;
    }
    public String getText() {
        return message_text;
    }
    public String getTitle() {
        return message_title;
    }
    public String getDate() {
        return message_date;
    }
    public int getId_message() {
        return id_message;
    }

    public void showEMessages(User user, JList messagesList, List<String> textsMessage){
        DefaultListModel<String> messageListModel = new DefaultListModel<>();
        StringBuilder textMessage = new StringBuilder();
        //establish db connection
        String URL = "jdbc:mysql://localhost:3306/softengin23_24";
        String USERNAME = "root";
        String PASSWORD = "W45@jqr#8CX";

        try {
            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            Statement statement = con.createStatement();
            String sql = "SELECT sender, recipient, message_text, title, date FROM my_messages WHERE recipient = ?";
            PreparedStatement prepStatement = con.prepareStatement(sql);
            prepStatement.setString(1, user.username);
            ResultSet res = prepStatement.executeQuery();

            while (res.next()) {
                String sender = res.getString("sender");
                String recipient = res.getString("recipient");
                String text = res.getString("message_text");
                String title = res.getString("title");
                String date = res.getString("date");

                //if message > 50 letters then dont print all the message
                if (text.length() > 55) {
                    text = text.substring(0, 55) + "...";
                }

                textMessage.append("<html>");
                textMessage.append(sender + " to " + recipient + "<br>" + title + "<br>" + text + "<br>On: " + date);
                textMessage.append("<br><hr><br></html>");
                textsMessage.add("<html>" + sender + " to " + recipient + "<br>Title: " + title + "<br>" + text + "<br>On: " + date + "<br><hr></html>");

                messageListModel.addElement(textMessage.toString());
                textMessage.setLength(0);
            }

            // close resources
            res.close();
            statement.close();
            con.close();

            messagesList.setModel(messageListModel);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error registering subjects: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

        }
    }

    public void showInMessages(User user, JList inList) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        DefaultListModel<String> inListModel = new DefaultListModel<>();
        StringBuilder inListText = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String recipient = user.username;

            String sql = "SELECT sender, recipient, message_text, title, date " +
                    "FROM my_messages " +
                    "WHERE recipient = ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, recipient);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String sender = resultSet.getString("sender");
                String messageRecipient = resultSet.getString("recipient");
                String messageText = resultSet.getString("message_text");
                String title = resultSet.getString("title");
                String date = resultSet.getString("date");

                inListText.append("<html>");
                inListText.append(sender + " to " + messageRecipient + "<br>About: " + title + "<br>" );

                String textSub = null;
                if (messageText.length() > 65) {
                    textSub = messageText.substring(0, 65) + "...";
                    inListText.append(textSub).append("<br>");
                }
                else{
                    inListText.append(messageText).append("<br>");
                }

                inListText.append("<br>On: " + date);
                inListText.append("<br><hr><br></html>");

                inListModel.addElement(inListText.toString());
                inListText.setLength(0);

            }

            resultSet.close();
            statement.close();
            connection.close();

            inList.setModel(inListModel);

        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public void showOutMessages(User user, JList outList) {
        String url = "jdbc:mysql://localhost:3306/softengin23_24";
        String username = "root";
        String password = "W45@jqr#8CX";

        DefaultListModel<String> outListModel = new DefaultListModel<>();
        StringBuilder outListText = new StringBuilder();

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String recipient = user.username;

            String sql = "SELECT sender, recipient, message_text, title, date, archive_name1, archive_content1, archive_name2, archive_content2  " +
                    "FROM my_messages " +
                    "WHERE sender = ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, recipient);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String sender = resultSet.getString("sender");
                String messageRecipient = resultSet.getString("recipient");
                String messageText = resultSet.getString("message_text");
                String title = resultSet.getString("title");
                String date = resultSet.getString("date");
                String archiveName1 = resultSet.getString("archive_name1");
                byte[] archiveContent1 = resultSet.getBytes("archive_content1");
                String archiveName2 = resultSet.getString("archive_name2");
                byte[] archiveContent2 = resultSet.getBytes("archive_content2");

                outListText.append("<html>");
                outListText.append(sender + " to " + messageRecipient + "<br>About: " + title + "<br>" );

                String textSub = null;
                if (messageText.length() > 65) {
                    textSub = messageText.substring(0, 65) + "...";
                    outListText.append(textSub).append("<br>");
                }
                else{
                    outListText.append(messageText).append("<br>");
                }
                if (archiveName1 != null && archiveContent1 != null) {
                    outListText.append("<br>Attachment 1: ").append(archiveName1).append(" (").append(archiveContent1.length).append(" bytes)");
                }

                if (archiveName2 != null && archiveContent2 != null) {
                    outListText.append("<br>Attachment 2: ").append(archiveName2).append(" (").append(archiveContent2.length).append(" bytes)");
                }

                outListText.append("<br>On: " + date);
                outListText.append("<br><hr><br></html>");

                outListModel.addElement(outListText.toString());
                outListText.setLength(0);

            }

            resultSet.close();
            statement.close();
            connection.close();

            outList.setModel(outListModel);

        } catch (SQLException e) {
            e.printStackTrace();

        }
    }
}
