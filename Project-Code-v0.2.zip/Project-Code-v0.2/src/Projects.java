import java.sql.*;
import java.time.LocalDate;
import java.util.Map;

public class Projects {
    private int idprojects;
    private String subject;
    private String teacher;
    private String student;
    private byte[] archive; // Representing BLOB as byte array
    private String date;
    private String title;
    private byte[] description;

    public int getIdprojects() {
        return idprojects;
    }



    public String getSubject() {
        return subject;
    }



    public String getTeacher() {
        return teacher;
    }



    public String getStudent() {
        return student;
    }



    public byte[] getArchive() {
        return archive;
    }



    public String getDate() {
        return date;
    }



    public String getTitle() {
        return title;
    }



    public byte[] getDescription() {
        return description;
    }

    public int getMaxTeamNumber(String projectId, String subjectName) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int maxTeamNumber = 0;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            String sql = "SELECT maxTeamNumber FROM projects WHERE idprojects = ? AND subject = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, projectId);
            pstmt.setString(2, subjectName);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                maxTeamNumber = rs.getInt("maxTeamNumber");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        return maxTeamNumber;
    }

    public void updateProject(String student, String projectId, String subjectName) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
            String sql = "UPDATE projects SET student = ? WHERE idprojects = ? AND subject = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, student);
            pstmt.setString(2, projectId);
            pstmt.setString(3, subjectName);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void loadProjectDates(User user, Map<LocalDate, String[]> projectDetails) {
        String sql = "SELECT date, subject, title FROM projects WHERE date >= CURDATE() AND student = ?";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user.getUsername());
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                LocalDate date = rs.getDate("date").toLocalDate();
                String subject = rs.getString("subject");
                String title = rs.getString("title");
                projectDetails.put(date, new String[]{subject, title});
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
