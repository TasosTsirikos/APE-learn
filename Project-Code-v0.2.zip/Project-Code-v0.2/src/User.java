import javax.swing.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class User {
    public String username;
    public String password;
    public String name;
    public String email;
    public String type;
    public int id_users;

    public User(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
    public String getName() {
        return name;
    }
    public String getType() {
        return type;
    }
    public int getId() {
        return id_users;
    }

    public static List<String> getRecipients(Connection connection, User user, JCheckBox toAll, JCheckBox toAllTeachers, JCheckBox toAllStudents, JTextField recipientField) throws SQLException {
        List<String> recipients = new ArrayList<>();

        if (toAll.isSelected()) {
            String getUsersQuery = "SELECT username FROM users WHERE username NOT LIKE ?";
            PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);
            getUsersStatement.setString(1, user.username);

            ResultSet resultSet = getUsersStatement.executeQuery();
            while (resultSet.next()) {
                recipients.add(resultSet.getString("username"));
            }

            resultSet.close();
            getUsersStatement.close();
        } else if (toAllTeachers.isSelected()) {
            String getUsersQuery = "SELECT username FROM users WHERE type NOT LIKE 'student'";
            PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);

            ResultSet resultSet = getUsersStatement.executeQuery();
            while (resultSet.next()) {
                recipients.add(resultSet.getString("username"));
            }

            resultSet.close();
            getUsersStatement.close();
        } else if (toAllStudents.isSelected()) {
            String getUsersQuery = "SELECT username FROM users WHERE type NOT LIKE 'teacher'";
            PreparedStatement getUsersStatement = connection.prepareStatement(getUsersQuery);

            ResultSet resultSet = getUsersStatement.executeQuery();
            while (resultSet.next()) {
                recipients.add(resultSet.getString("username"));
            }

            resultSet.close();
            getUsersStatement.close();
        } else {
            recipients.add(recipientField.getText().trim());
        }

        return recipients;
    }

}
