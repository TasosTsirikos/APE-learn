import java.sql.*;
import java.time.LocalDate;

public class Regulations {
    private LocalDate tillDateSubjects;
    private LocalDate tillDateBooks;

    public Regulations() {
    }

    public Regulations(LocalDate tillDateSubjects, LocalDate tillDateBooks) {
        this.tillDateSubjects = tillDateSubjects;
        this.tillDateBooks = tillDateBooks;
    }

    public LocalDate getTillDateSubjects() {
        return tillDateSubjects;
    }

    public LocalDate getTillDateBooks() {
        return tillDateBooks;
    }

    public Regulations retrieveRegulationDates() {
        LocalDate tillDateSubjects = null;
        LocalDate tillDateBooks = null;
        try {
            String URL = "jdbc:mysql://localhost:3306/softengin23_24";
            String USERNAME = "root";
            String PASSWORD = "W45@jqr#8CX";

            Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            Statement statement = con.createStatement();
            String sql = "SELECT tillDateSubjects, tillDateBooks FROM regulations";
            ResultSet res = statement.executeQuery(sql);

            if (res.next()) {
                Date tillDateSubjectsDB = res.getDate("tillDateSubjects");
                Date tillDateBooksDB = res.getDate("tillDateBooks");

                tillDateSubjects = ((java.sql.Date) tillDateSubjectsDB).toLocalDate();
                tillDateBooks = ((java.sql.Date) tillDateBooksDB).toLocalDate();
            }

            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return new Regulations(tillDateSubjects, tillDateBooks);
    }

    public boolean isEnrollmentPeriodOpen() {
        LocalDate today = LocalDate.now();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/softengin23_24", "root", "W45@jqr#8CX");
             PreparedStatement statement = conn.prepareStatement("SELECT tillDateDiplomaThesis FROM regulations");
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                Date tillDateSubjects = resultSet.getDate("tillDateDiplomaThesis");
                return tillDateSubjects.toLocalDate().isAfter(today);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
