import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinUser;

import javax.swing.*;
import java.util.concurrent.atomic.AtomicReference;

public class ScreenCapture {
    public void populateWindows(JComboBox comboBox1) {
        User32.INSTANCE.EnumWindows(new WinUser.WNDENUMPROC() {
            @Override
            //set the combobox with the window titles found
            public boolean callback(WinDef.HWND hWnd, Pointer arg1) {
                if (User32.INSTANCE.IsWindowVisible(hWnd)) {
                    char[] windowText = new char[512];
                    User32.INSTANCE.GetWindowText(hWnd, windowText, 512);
                    String windowTitle = Native.toString(windowText).trim();
                    if (!windowTitle.isEmpty() && !windowTitle.equals("Program Manager") && !windowTitle.equals("Εμπειρία εισόδου των Windows") && !windowTitle.equals("Ρυθμίσεις") && !windowTitle.equals("Attending Lecture for Subject:")) {
                        SwingUtilities.invokeLater(() -> comboBox1.addItem(windowTitle));
                    }
                }
                return true; // continue enumeration
            }
        }, null);
    }

    public WinDef.HWND findWindowByTitle(String windowTitle) {
        final AtomicReference<WinDef.HWND> foundWindow = new AtomicReference<>();

        User32.INSTANCE.EnumWindows(new WinUser.WNDENUMPROC() {
            @Override
            //find the opened window pc has right now

            public boolean callback(WinDef.HWND hWnd, Pointer userData) {
                char[] windowBuffer = new char[1024];
                User32.INSTANCE.GetWindowText(hWnd, windowBuffer, windowBuffer.length);
                String title = Native.toString(windowBuffer);

                if (title.equals(windowTitle)) {
                    foundWindow.set(hWnd);
                    return false; // stop enumeration
                }
                return true; // continue enumeration
            }
        }, null);

        return foundWindow.get();
    }
}
