import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DiplomaThesisStudent extends JFrame{
    private JTextField teacherSearch;
    private JTextField topicSearch;
    private JPanel dTStudent;
    private JButton takeItButton;
    private JButton searchButton;
    private JTable dtTable;
    private JButton resetButton;
    private JScrollPane scrollTable;

    private User user;

    private DefaultTableModel dtTableModel;
    private int selectedRow = -1;

    public DiplomaThesisStudent(JFrame parent, User user) {
        DiplomaThesis dt = new DiplomaThesis();
        this.user = user;
        Regulations regulations = new Regulations();
        SystemApeLearn sal = new SystemApeLearn();
        Subjects subjects = new Subjects();
        DiplomaThesisApplications dta = new DiplomaThesisApplications();
        setTitle("Diploma Thesis");
        setContentPane(dTStudent);

        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        if (!regulations.isEnrollmentPeriodOpen()) {
            sal.displayEnrollmentPeriodClosedMessage();
            redirectToStudentMenu();
            return;
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });

        String[] columnHeaders = {"ID", "Title", "Description", "Teacher"};

        // DefaultTableModel with column headers
        DefaultTableModel model = new DefaultTableModel(columnHeaders, 0);

        dtTable.setModel(model);

        dt.populateTable(dtTable, dtTableModel);

        dtTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // get the selected row
                    selectedRow = dtTable.getSelectedRow();
                    if (selectedRow != -1) {
                        // retrieve the data from the selected row
                        int id = (int) dtTable.getValueAt(selectedRow, 0);
                        String title = (String) dtTable.getValueAt(selectedRow, 1);
                        String description = (String) dtTable.getValueAt(selectedRow, 2);
                        String teacher = (String) dtTable.getValueAt(selectedRow, 3);

                        // open a new window to display the selected diploma thesis
                        displaySelectedData(id, title, description, teacher);
                    }
                }
            }
        });

        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String teacher = teacherSearch.getText();
                String title = topicSearch.getText();
                if (teacher.isEmpty() && title.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "You must fill in the fields to search for diploma theses", "Empty Fields", JOptionPane.WARNING_MESSAGE);
                } else {
                    dt.searchDiplomaThesis(teacher, title, dtTable);
                }
            }
        });



        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // clear text fields
                teacherSearch.setText("");
                topicSearch.setText("");
                SystemApeLearn sal = new SystemApeLearn();
                sal.resetTable(dtTable);
            }
        });

        takeItButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedRow != -1) {
                    String student = user.getUsername();
                    if (subjects.getPassedSubjectsCount(student) > 40) {
                        String title = (String) dtTable.getValueAt(selectedRow, 1);
                        String teacher = (String) dtTable.getValueAt(selectedRow, 3);

                        if (dta.isTopicAssignedToAnotherStudent(title, student)) {
                            JOptionPane.showMessageDialog(null, "This topic has already been assigned. Please choose another subject.", "Topic Assigned", JOptionPane.WARNING_MESSAGE);
                        } else {
                            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
                            dta.insertDiplomaThesisApplication(student, date, title, teacher);
                            JOptionPane.showMessageDialog(null, "Diploma Thesis application submitted successfully!");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Your application for the diploma thesis cannot be completed. Prerequisites not met.", "Prerequisites Not Met", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please select a diploma thesis to apply for.", "No Selection", JOptionPane.WARNING_MESSAGE);
                }
            }
        });

    }

    private void displaySelectedData(int id, String title, String description, String teacher) {
        JFrame frame = new JFrame("Selected Diploma Thesis");
        frame.setSize(500, 400);
        frame.setLocationRelativeTo(this);

        JPanel panel = new JPanel(new GridLayout(4, 1));
        panel.add(new JLabel("<html>ID: " + id + "<br>Title: " + title + "<br>Supervisor/Teacher: " + teacher + "<br>Description: " + description + "<br><hr></html>"));

        frame.add(panel);
        frame.setVisible(true);
    }

    private void redirectToStudentMenu() {
        Timer timer = new Timer(2000, e -> {
            dispose();
            new studentMenuu(null, user);
        });
        timer.setRepeats(false);
        timer.start();
    }
}

