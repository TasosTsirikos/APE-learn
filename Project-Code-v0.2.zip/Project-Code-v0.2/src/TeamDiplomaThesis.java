public class TeamDiplomaThesis {
}
