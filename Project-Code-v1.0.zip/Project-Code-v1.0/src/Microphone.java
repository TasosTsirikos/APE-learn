import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.TargetDataLine;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Microphone {
    private TargetDataLine line;
    private JLabel microphoneLabel;

    public Microphone(JLabel microphoneLabel) {
        this.microphoneLabel = microphoneLabel;
    }

    public synchronized void openMicrophone() {
        releaseMicrophone(); // Release previous microphone if opened

        AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);

        try {
            line = (TargetDataLine) AudioSystem.getLine(info);
            line.open(format);
            line.start();

            new Thread(() -> {
                try {
                    byte[] buffer = new byte[1024];
                    while (line.isOpen()) {
                        int bytesRead = line.read(buffer, 0, buffer.length);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    releaseMicrophone(); // Release microphone on thread completion
                }
            }).start();
        } catch (Exception e) {
            e.printStackTrace();
        }
        ImageIcon micOpenLabelIcon = new ImageIcon("src/microphone-black-shape.png");
        microphoneLabel.setIcon(micOpenLabelIcon);
    }

    public synchronized void releaseMicrophone() {
        if (line != null) {
            line.stop();
            line.close();
            System.out.println("Microphone released");
            ImageIcon micOpenLabelIcon = new ImageIcon("src/microphone-off.png");
            microphoneLabel.setIcon(micOpenLabelIcon);
        }
    }
}
