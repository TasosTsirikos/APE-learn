import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JDialog{
    private JTextField tfUsername;
    private JPasswordField pfPassword;
    private JButton btnOK;
    private JButton btnCancel;
    private JPanel loginPanel;
public    User user;

    public Login(JFrame parent){
        super(parent);
        setTitle("Login");
        setContentPane(loginPanel);
        setMinimumSize(new Dimension(900, 700));
        setModal(true);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        SystemApeLearn sal = new SystemApeLearn();


        btnOK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = tfUsername.getText();
                String password = String.valueOf(pfPassword.getPassword());


                user = sal.getAuthenticateUser(username, password, user);

                if (user != null) {
                    dispose();
                    if (user.type.equalsIgnoreCase("student")) {
                        // Open student menu
                        new studentMenuu(null, user);
                    } else if (user.type.equalsIgnoreCase("teacher")) {
                        // Open teacher menu
                        new teacherMenuu(null, user);
                    } else if (user.type.equalsIgnoreCase("admin")) {
                        // Open admin menu
                        new adminHome(null, user);
                    } else if (user.type.equalsIgnoreCase("secretary")) {
                        // Open secretary menu
                        new secretaryHome(null, user);
                    } else {
                        JOptionPane.showMessageDialog(Login.this, "Unknown user type",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
                else{
                    JOptionPane.showMessageDialog(Login.this, "Username or Password not Valid!",
                            "Try again!", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
            }
        });

        setVisible(true);
    }

    public void setDefaultCloseOperation(int disposeOnClose) {
    }

    public static void main(String[] args) {
        Login login = new Login(null);
        User user = login.user;
        if(user != null){
            System.out.println("Successful Authentication for: " + user.name);
            System.out.println("    Username: " + user.username);
            System.out.println("    Email: " + user.email);
            System.out.println("    Type(Student or Teacher): " + user.type);
        }
        else{
            System.out.println("Authentication canceled");
        }
    }
}
