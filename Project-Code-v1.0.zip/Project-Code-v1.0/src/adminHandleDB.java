import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class adminHandleDB extends JFrame{
    private JComboBox comboBoxTable;
    private JComboBox comboBoxCrud;
    private JComboBox comboBoxWhereVar;
    private JTextField textFieldValue;
    private JComboBox comboBoxWherePunct;
    private JButton saveButton;
    private JButton resetButton;
    private JTable table1;
    private JComboBox comboBoxVarAffected;
    private JPanel handleDBPanel;
    private User user;

    public adminHandleDB(JFrame parent, User user) {
        this.user = user;
        setTitle("Admin Menu");
        setContentPane(handleDBPanel);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new adminHome(null, user);
            }
        });

    }
}
