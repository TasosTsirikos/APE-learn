import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.videoio.VideoCapture;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;

public class Camera {
    private VideoCapture capture;
    private JLabel cameraLabel;
    private JLabel speakerLabel;

    public Camera(JLabel cameraLabel, JLabel speakerLabel) {
        this.cameraLabel = cameraLabel;
        this.speakerLabel = speakerLabel;
    }

    public synchronized void openCamera() {
        releaseCamera(); // Release previous camera if opened

        System.setProperty("org.opencv.videoio.registry", "ffmpeg");
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        capture = new VideoCapture(0);

        new Thread(() -> {
            try {
                while (capture != null && capture.isOpened()) {
                    Mat frame = new Mat();
                    if (capture.read(frame)) {
                        ImageIcon imageIcon = new ImageIcon(Mat2BufferedImage(frame));
                        speakerLabel.setIcon(imageIcon);
                        speakerLabel.setSize(imageIcon.getIconWidth(), imageIcon.getIconHeight());
                        Thread.sleep(50); // Control frame rate
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                releaseCamera(); // Release camera on thread completion
            }
        }).start();

        ImageIcon camOpenLabelIcon = new ImageIcon("src/video-camera.png");
        cameraLabel.setIcon(camOpenLabelIcon);
    }

    public synchronized void releaseCamera() {
        if (capture != null && capture.isOpened()) {
            capture.release();
            speakerLabel.setIcon(null);
            ImageIcon camCloseIcon = new ImageIcon("src/no-speak.png");
            speakerLabel.setIcon(camCloseIcon);

            ImageIcon camCloseLabelIcon = new ImageIcon("src/no-video.png");
            cameraLabel.setIcon(camCloseLabelIcon);
        }
    }

    private BufferedImage Mat2BufferedImage(Mat m) {
        int type = BufferedImage.TYPE_BYTE_GRAY;
        if (m.channels() > 1) {
            type = BufferedImage.TYPE_3BYTE_BGR;
        }
        int bufferSize = m.channels() * m.cols() * m.rows();
        byte[] b = new byte[bufferSize];
        m.get(0, 0, b);
        BufferedImage img = new BufferedImage(m.cols(), m.rows(), type);
        final byte[] targetPixels = ((DataBufferByte) img.getRaster().getDataBuffer()).getData();
        System.arraycopy(b, 0, targetPixels, 0, b.length);
        return img;
    }
}
