import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class Emergencies {
    public void loadEmergencyData(JTable table1) {
        try {
            Connection connection = DB_config.getConnection();
            String query = "SELECT * FROM emergencies";
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(query);
            DefaultTableModel model = new DefaultTableModel();
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();
            for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++) {
                model.addColumn(metaData.getColumnName(columnIndex));
            }
            while (resultSet.next()) {
                Object[] rowData = new Object[columnCount];
                for (int i = 0; i < columnCount; i++) {
                    rowData[i] = resultSet.getObject(i + 1);
                }
                model.addRow(rowData);
            }
            table1.setModel(model);
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data from database", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
