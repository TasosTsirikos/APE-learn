import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.awt.event.*;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;


public class StudentTeam extends JFrame {
    private JTree tree1;
    private JButton uploadFilesButton;
    private JButton messagesButton;
    private JButton enterCallButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField fileName;

    private JButton newBranchButton;
    private JTextField textField4;
    private JButton submitButton;
    private JPanel coSharepanel;
    private User user;
    private File selectedFile;
    private FilesCoShare fileManager;
    private String teamID;

    public StudentTeam(JFrame parent, User user, String id, String teamID) {
        this.user = user;
        this.teamID = teamID;
        this.fileManager = new FilesCoShare(user, selectedFile, teamID);
        Branches branch = new Branches();
        setTitle("Diploma Thesis Co-Share");
        setContentPane(coSharepanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        branch.populateJTree(tree1, teamID);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new userSubjectProfile(null, user, id);
            }
        });


        newBranchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                createNewBranchProjects cnb = new createNewBranchProjects(null, user, id, teamID);
                cnb.setVisible(true);
            }
        });

        uploadFilesButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int option = fileChooser.showOpenDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                selectedFile = fileChooser.getSelectedFile();
                fileManager.setSelectedFile(selectedFile);
                try {
                    String fileContent = new String(Files.readAllBytes(selectedFile.toPath()), StandardCharsets.UTF_8);
                    fileName.setText(selectedFile.getName());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error reading file: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        submitButton.addActionListener(e -> {
            String branchName = textField4.getText();
            if (!fileName.getText().trim().isEmpty() && !branchName.isEmpty()) {
                try {
                    byte[] fileContent = Files.readAllBytes(selectedFile.toPath());
                    String checkResult = fileManager.checkFileProjects(selectedFile.getName(), fileContent);
                    Dialog dialog = new Dialog(StudentTeam.this, selectedFile, user, teamID);
                    if ("sameName".equals(checkResult)) {
                        dialog.showFileExistsDialog(branchName, fileContent);
                    } else if ("sameContent".equals(checkResult)) {
                        dialog.sameContentDialog(branchName, fileContent);
                    } else {
                        fileManager.insertFileIntoDatabase(branchName, fileContent);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a file and specify a branch.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        });

        tree1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    TreePath path = tree1.getPathForLocation(e.getX(), e.getY());
                    if (path != null) {
                        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) path.getLastPathComponent();
                        if (selectedNode.isLeaf()) {
                            Object userObject = selectedNode.getUserObject();
                            if (userObject instanceof String) {
                                String fileInfo = userObject.toString();
                                if (fileInfo.endsWith("KB)")) { //check to identify file nodes
                                    SystemApeLearn sal = new SystemApeLearn();
                                    sal.openFileWithDesktopApp(fileInfo); // Method to extract file path and open
                                }
                            }
                        }
                    }
                }
            }
        });
    }



}
