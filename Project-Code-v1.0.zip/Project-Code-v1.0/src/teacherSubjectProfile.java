import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.text.SimpleDateFormat;

public class teacherSubjectProfile extends JFrame {
    private JPanel teacherSubjectProfile;
    private JLabel titleLabel;
    private JLabel infoLabel1;
    private JLabel infoLabel2;
    private JToolBar toolBarTeacher;
    private JLabel ectsField;
    private JTextField titleField;
    private JButton publishButton;
    private JTextField announcementField;
    private User user;
    private String subjectName;



    public teacherSubjectProfile(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);

        setTitle("Subject Details");
        setContentPane(teacherSubjectProfile);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JButton seeLectures = new JButton("My Lectures");
        JButton projects = new JButton("Projects");
        JButton seeMarks = new JButton("Grades");
        JButton attend = new JButton("Attend to Lecture");
        JButton participants = new JButton("Participants");

        toolBarTeacher.add(seeLectures);
        toolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarTeacher.add(projects);
        toolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarTeacher.add(seeMarks);
        toolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarTeacher.add(attend);
        toolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        toolBarTeacher.add(participants);

        seeLectures.addActionListener(e -> {
            dispose();
            teacherLectures lecturesWindow = new teacherLectures(this, user, id);
            lecturesWindow.setVisible(true);
        });

        attend.addActionListener(e -> {
            dispose();
            teacherAttendsLecture attends = new teacherAttendsLecture(this, user, id);
            attends.setVisible(true);
        });

        projects.addActionListener(e -> {
            dispose();
            teacherProjects projectsTeacher = new teacherProjects(this, user, id);
            projectsTeacher.setVisible(true);
        });

        seeMarks.addActionListener(e -> {
            dispose();
            teacherGrades grades = new teacherGrades(this, user, id);
            grades.setVisible(true);
        });

        participants.addActionListener(e -> {
            dispose();
            teacherSubjectParticipants grades = new teacherSubjectParticipants(this, user, id);
            grades.setVisible(true);
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherMenuu(null, user);
            }
        });
        setVisible(true);

        displaySubjectInfo(id);

        publishButton.addActionListener(e -> {
            try {

                Connection connection = DB_config.getConnection();

                String query = "INSERT INTO announcements (text, teacher_name, title, about, date, subject_id) VALUES (?, ?, ?, ?, ?, ?)";

                PreparedStatement preparedStatement = connection.prepareStatement(query);

                preparedStatement.setString(1, announcementField.getText());
                preparedStatement.setString(2, user.getName());
                preparedStatement.setString(3, titleField.getText());
                preparedStatement.setString(4, subjectName);
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                String currentDate = sdf.format(new java.util.Date());
                preparedStatement.setString(5, currentDate);
                preparedStatement.setString(6, id);

                preparedStatement.executeUpdate();

                preparedStatement.close();
                connection.close();

                // Display a message to the user indicating success
                JOptionPane.showMessageDialog(null, "Announcement published successfully!");
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error publishing announcement: " + ex.getMessage());
            }
        });
    }

    public void displaySubjectInfo(String id) {
        // SQL query to retrieve subject information
        String query = "SELECT subject_name, subject_decription, type, ects, year, semester FROM subjects WHERE idsubjects = ?";

        try (Connection connection = DB_config.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if a record is found
            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
                String subjectDescription = resultSet.getString("subject_decription");
                String type = resultSet.getString("type");
                int ects = resultSet.getInt("ects");
                int year = resultSet.getInt("year");
                String semester = resultSet.getString("semester");

                // Format the information
                String subjectTitleText = id + ": " + subjectName + " (" + type + ")";
                String infoFieldText = "Year: " + year + ", Semester: " + semester ;
                String infoTextField = "Info: " + subjectDescription;
                String ectsText = "Ects: " + String.valueOf(ects);


                // Set the text to the components
                titleLabel.setText(subjectTitleText);
                infoLabel1.setText(infoTextField);
                infoLabel2.setText(infoFieldText);
                ectsField.setText(ectsText);

            } else {
                // No record found for the given ID
                JOptionPane.showMessageDialog(this, "Subject not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Connection connection = DB_config.getConnection();
            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }
}