import javax.swing.*;
import java.sql.*;
import java.util.Vector;

public class Subjects {
    public String idsubjects;
    public String subject_name;
    public String subject_decription;
    public String subject_teacher;
    public String subject_type;
    public String subject_semester;
    public int subject_year;
    public int subject_ects;

    public String getId() {
        return idsubjects;
    }
    public String getName() {
        return subject_name;
    }
    public String getType() {
        return subject_type;
    }
    public String getSemester() {
        return subject_semester;
    }
    public String getSubject_decription() {
        return subject_decription;
    }
    public int getYear() {
        return subject_year;
    }
    public int getEcts() {
        return subject_ects;
    }

    String fetchSubjectName(String id) {
        String subjectName = null;

        try {
            Connection con = DB_config.getConnection();

            String sql = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement prepStatement = con.prepareStatement(sql);

            prepStatement.setString(1, id);

            ResultSet res = prepStatement.executeQuery();

            if (res.next()) {
                subjectName = res.getString("subject_name");
            }

            // Close resources
            res.close();
            prepStatement.close();
            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }

    public void retrieveStudentSubjects(JList subjectList, User user){
        DefaultListModel<String> subjectListModel = new DefaultListModel<>();
        StringBuilder subjectText = new StringBuilder();

        try {
            Connection con = DB_config.getConnection();
            Statement stmt = con.createStatement();
            String sql = "SELECT id_subject, subject_name, subject_description, teacher FROM my_subjects WHERE student = ?";
            PreparedStatement prepStatement = con.prepareStatement(sql);
            prepStatement.setString(1, user.username);
            ResultSet res = prepStatement.executeQuery();

            while (res.next()) {
                String id = res.getString("id_subject");
                String name = res.getString("subject_name");
                String description = res.getString("subject_description");
                String teacher = res.getString("teacher");

                if (description.length() > 20) {
                    description = description.substring(0, 15) + "...";
                }

                // Add the subject information to the list model
                subjectText.append("<html>");
                subjectText.append(id + ": " + name + "<br>" + teacher + "<br>" + description);
                subjectText.append("<br><hr><br></html>");

                subjectListModel.addElement(subjectText.toString());
                subjectText.setLength(0);
            }

            // Close resources
            res.close();
            stmt.close();
            con.close();

            subjectList.setModel(subjectListModel);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void displaySubjectInfo(String id, JLabel titleLabel, JLabel infoLabel1, JLabel infoLabel2, JLabel ectsField, JLabel markLabel) {

        // SQL query to retrieve subject information
        String query = "SELECT subject_name, subject_description, teacher, grade, type, ects FROM my_subjects WHERE id_subject = ?";

        try (Connection connection = DB_config.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, id);

            // Execute the query
            ResultSet resultSet = preparedStatement.executeQuery();


            // Check if a record is found
            if (resultSet.next()) {
                String subjectName = resultSet.getString("subject_name");
                String subjectDescription = resultSet.getString("subject_description");
                String teacher = resultSet.getString("teacher");
                String type = resultSet.getString("type");
                int mark = resultSet.getInt("grade");
                int ects = resultSet.getInt("ects");

                // Format the information
                String subjectTitleText = id + ": " + subjectName + " (" + type + ")";
                String teacherFieldText = "Professor: " + teacher;
                String infoTextField = "Info: " + subjectDescription;
                String ectsText = "Ects: " + String.valueOf(ects);


                // Set the text to the components
                titleLabel.setText(subjectTitleText);
                infoLabel1.setText(teacherFieldText);
                infoLabel2.setText(infoTextField);
                ectsField.setText(ectsText);

                if (mark == -1){
                    String grade = " ";
                    String markField = "Mark: " + grade;
                    markLabel.setText(markField);
                }
                else{
                    int grade = mark;
                    String markField = "Mark: " + grade;
                    markLabel.setText(markField);
                }

            } else {
                // No record found for the given ID
                JOptionPane.showMessageDialog(null, "Subject not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void showTeacherSubjects(JList subjectList, User user){
        try {
            Connection conn = DB_config.getConnection();
            Statement stmt = conn.createStatement();

            String query = "SELECT idsubjects, subject_name, subject_decription, type, ects, year, semester " +
                    "FROM subjects " +
                    "WHERE teacher = '" + user.getName() + "'";

            ResultSet rs = stmt.executeQuery(query);

            //DefaultListModel to store subject details
            DefaultListModel<String> subjectListModel = new DefaultListModel<>();

            while (rs.next()) {
                String id = rs.getString("idsubjects");
                String name = rs.getString("subject_name");
                String description = rs.getString("subject_decription");

                if (description.length() > 20) {
                    description = description.substring(0, 15) + "...";
                }

                // Construct the string representation of the subject
                String subjectInfo = "<html>" + id + "<br>Name: " + name + "<br>About: " + description + "<br><br><hr>";

                // Add the subject info to the list model
                subjectListModel.addElement(subjectInfo);
            }

            subjectList.setModel(subjectListModel);

            System.out.println("Number of items in subjectList: " + subjectListModel.getSize());

            rs.close();
            stmt.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void loadStudents(User user, String subjectId, JList<String> list1) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = DB_config.getConnection();
            String sql = "SELECT student FROM my_subjects WHERE id_subject = ? AND student <> ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, subjectId);
            pstmt.setString(2, user.getUsername());
            rs = pstmt.executeQuery();

            Vector<String> students = new Vector<>();
            while (rs.next()) {
                students.add(rs.getString("student"));
            }
            list1.setListData(students);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    public int getPassedSubjectsCount(String student) {
        int count = 0;

        try (Connection connection = DB_config.getConnection()) {
            String query = "SELECT COUNT(*) FROM my_subjects WHERE grade >= 5 AND student = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, student);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        count = resultSet.getInt(1);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return count;
    }
}
