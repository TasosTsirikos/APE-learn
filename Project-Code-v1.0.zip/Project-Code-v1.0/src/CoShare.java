public class CoShare {
}
