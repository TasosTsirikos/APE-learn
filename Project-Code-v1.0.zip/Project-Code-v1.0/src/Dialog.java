import javax.swing.*;
import java.awt.*;
import java.io.File;

public class Dialog {
    private JFrame parent;
    private File selectedFile;
    private User user;
    private String teamId;
    public Dialog(JFrame parent, File selectedFile, User user, String teamId) {
        this.parent = parent;
        this.selectedFile = selectedFile;
        this.user = user;
        this.teamId = teamId;
    }

    public void showFileExistsDialog(String branchName, byte[] fileContent) {
        JDialog fileExistsDialog = new JDialog(parent, "File Exists", true);
        fileExistsDialog.setLayout(new BorderLayout());

        // Message
        JLabel messageLabel = new JLabel("<html>A file with the same name already exists.<br>Should I create a new version or replace the old file with the new one?</html>");
        fileExistsDialog.add(messageLabel, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton newVersionButton = new JButton("New Version");
        JButton replaceButton = new JButton("Replace");
        JButton cancelButton = new JButton("Cancel");

        buttonPanel.add(newVersionButton);
        buttonPanel.add(replaceButton);
        buttonPanel.add(cancelButton);
        fileExistsDialog.add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        newVersionButton.addActionListener(e -> {
            createNewVersion(branchName, fileContent, selectedFile, user);
            fileExistsDialog.dispose();
        });

        replaceButton.addActionListener(e -> {
            replaceExistingFile(branchName, fileContent);
            fileExistsDialog.dispose();
        });

        cancelButton.addActionListener(e -> {
            fileExistsDialog.dispose();
        });

        // Display the dialog
        fileExistsDialog.pack();
        fileExistsDialog.setLocationRelativeTo(parent);
        fileExistsDialog.setVisible(true);
    }

    public void sameContentDialog(String branchName, byte[] fileContent) {
        JDialog fileExistsDialog = new JDialog(parent, "File has same content", true);
        fileExistsDialog.setLayout(new BorderLayout());

        // Message
        JLabel messageLabel = new JLabel("<html>A file with the same content already exists.<br>A file with the same content already exists. Should i replace thw new file with the new one?</html>");
        fileExistsDialog.add(messageLabel, BorderLayout.CENTER);

        // Buttons panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton yes = new JButton("Yes");
        JButton no = new JButton("No");

        buttonPanel.add(yes);
        buttonPanel.add(no);
        fileExistsDialog.add(buttonPanel, BorderLayout.SOUTH);

        // Button actions

        yes.addActionListener(e -> {
            replaceExistingFile(branchName, fileContent);
            fileExistsDialog.dispose();
        });

        no.addActionListener(e -> {
            fileExistsDialog.dispose();
        });

        // Display the dialog
        fileExistsDialog.pack();
        fileExistsDialog.setLocationRelativeTo(parent);
        fileExistsDialog.setVisible(true);
    }

        private void createNewVersion(String branchName, byte[] fileContent, File selectedFile, User user) {
            FilesCoShare fcs = new FilesCoShare(user, selectedFile, teamId);
            fcs.updateVersion(branchName, fileContent, selectedFile, user);
        }


    private void replaceExistingFile(String branchName, byte[] fileContent) {
          FilesCoShare fcs = new FilesCoShare(user, selectedFile, teamId);
          fcs.replaceFile(teamId);
        }
}
