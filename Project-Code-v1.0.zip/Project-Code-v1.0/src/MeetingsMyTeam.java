public class MeetingsMyTeam extends Meetings{
}
