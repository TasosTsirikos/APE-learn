import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class manageStudents extends JFrame{
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTable table1;
    private JButton setButton;
    private User user;

    public manageStudents(JFrame parent, User user) {
        this.user = user;
        setTitle("Manage Students");
        setContentPane(panel1);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new secretaryHome(null, user);
            }
        });

        String[] columnNames = {"ID", "Name", "Year", "Semester"};
        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < table1.getColumnCount(); i++) {
            Class<?> columnClass = table1.getColumnClass(i);
            table1.setDefaultEditor(columnClass, null);
        }

        setButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (textField1.getText().isEmpty() || textField2.getText().isEmpty() || textField3.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill in all the fields to update students.");
                } else {
                    updateDatabase();
                }
            }
        });

        populateTable();
    }

    private void populateTable(){
        String[] columnNames = {"ID", "Name", "Year", "Semester"};
        DefaultTableModel model = (DefaultTableModel) table1.getModel();
        model.setColumnIdentifiers(columnNames);
        model.setRowCount(0);

        try {
            Connection conn = DB_config.getConnection();

            String query = "SELECT id_users, name, year, semester FROM users WHERE type = 'student'";

            PreparedStatement pstmt = conn.prepareStatement(query);

            ResultSet rs = pstmt.executeQuery();

            // Populate the table with the retrieved data
            while (rs.next()) {
                Object[] rowData = {
                        rs.getInt("id_users"),
                        rs.getString("name"),
                        rs.getInt("year"),
                        rs.getString("semester")
                };
                model.addRow(rowData);
            }

            // Close the resources
            rs.close();
            pstmt.close();
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to fetch data from database.");
        }
    }

    private void updateDatabase() {
        try {
            Connection conn = DB_config.getConnection();
            String query = "UPDATE users SET year = ?, semester = ? WHERE year = ? AND type = ?";

            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(textField1.getText()));
            pstmt.setString(2, textField2.getText());
            pstmt.setInt(3, Integer.parseInt(textField3.getText()));
            pstmt.setString(4, "student");

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Database updated successfully.");
                // Refresh the table after update
                populateTable();
            } else {
                JOptionPane.showMessageDialog(null, "No records updated. Please check your input values.");
            }

            pstmt.close();
            conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to update database.");
        }
    }
}
