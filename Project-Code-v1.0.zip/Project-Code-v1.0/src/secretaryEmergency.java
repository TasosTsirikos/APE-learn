import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.Duration;
import java.time.LocalTime;

public class secretaryEmergency extends JFrame {
    private JLabel timeLabel;
    private JToolBar menuStudents;

    private JToolBar menuTeachers;

    private JPanel secrEmergencyPanel;
    private User user;
    private Timer timer;
    private LocalTime endTime;

    public secretaryEmergency(JFrame parent, User user) {
        if (!adminEmergency.isAuthorized()) {
            JOptionPane.showMessageDialog(null, "You are not authorized to access this window.", "Access Denied", JOptionPane.ERROR_MESSAGE);
            new secretaryHome(null, user);
            dispose();
            return;
        }
        this.user = user;
        setTitle("Secretary Menu");

        secrEmergencyPanel = new JPanel(new BorderLayout(10, 10));
        secrEmergencyPanel.setBackground(new Color(246, 255, 171)); // Set the background color to the custom RGB color
        secrEmergencyPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        setContentPane(secrEmergencyPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        // Initialize toolbars
        menuStudents = createToolbar();

        // Add toolbar to the panel
        secrEmergencyPanel.add(menuStudents, BorderLayout.NORTH);

        // Initialize and add the time label
        timeLabel = new JLabel();
        timeLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        timeLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Add the time label to the menuStudents toolbar
        menuStudents.add(Box.createHorizontalGlue()); // Push timeLabel to the right
        menuStudents.add(timeLabel);

        // Create and add buttons to toolbar
        addButtonsToToolbar();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new secretaryHome(null, user);
            }
        });

        // Set end time to 1 hour from now
        endTime = LocalTime.now().plusHours(1);
        startTimer();
        setVisible(true);
    }

    private JToolBar createToolbar() {
        JToolBar toolbar = new JToolBar();
        toolbar.setFloatable(false);
        return toolbar;
    }

    private void addButtonsToToolbar() {
        JButton subjectButton = new JButton("Enroll to Subjects");
        JButton booksButton = new JButton("Select Books");
        JButton projectButton = new JButton("Upload Project");
        JButton equipButton = new JButton("Equipment Failure");
        JButton completeExitButton = new JButton("Complete & Exit");

        menuStudents.add(subjectButton);
        menuStudents.addSeparator();
        menuStudents.add(booksButton);
        menuStudents.addSeparator();
        menuStudents.add(projectButton);
        menuStudents.addSeparator();
        menuStudents.add(equipButton);
        menuStudents.addSeparator();
        menuStudents.add(completeExitButton);

        completeExitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new secretaryHome(null, user); // Redirect to the main menu
                dispose();
            }
        });
    }
    private void startTimer() {
        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Duration duration = Duration.between(LocalTime.now(), endTime);
                long seconds = duration.getSeconds();

                if (seconds <= 0) {
                    timer.stop();
                    timeLabel.setText("00:00:00");
                } else {
                    long hours = seconds / 3600;
                    long minutes = (seconds % 3600) / 60;
                    long secs = seconds % 60;
                    timeLabel.setText(String.format("%02d:%02d:%02d", hours, minutes, secs));
                }
            }
        });
        timer.start();
    }
}


