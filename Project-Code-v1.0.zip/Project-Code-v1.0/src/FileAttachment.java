import java.io.File;
import java.nio.file.Files;
import java.io.IOException;

public class FileAttachment {
    private String fileName;
    private byte[] fileContent;

    public FileAttachment(File file) throws IOException {
        this.fileName = file.getName();
        this.fileContent = Files.readAllBytes(file.toPath());
    }

    public String getFileName() {
        return fileName;
    }

    public byte[] getFileContent() {
        return fileContent;
    }
}
