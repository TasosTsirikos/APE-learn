import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class adminCreateAcc extends  JFrame{
    private JTextField textFieldUsername;
    private JTextField textFieldPassword;
    private JTextField textFieldName;
    private JTextField textFieldEmail;
    private JTextField textFieldType;
    private JButton saveButton;
    private JPanel adminCreateAccPanel;
    private User user;

    public adminCreateAcc(JFrame parent, User user) {
        this.user = user;
        setTitle("My Profile");
        setContentPane(adminCreateAccPanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new adminHome(null, user);
            }
        });

    }
}
