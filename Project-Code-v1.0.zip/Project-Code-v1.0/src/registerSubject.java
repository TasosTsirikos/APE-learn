import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.time.LocalDate;

public class registerSubject extends JFrame{
    private JPanel subjectTable;
    private JTable table_subjects;
    private JScrollPane subject_table;
    private JButton registerBtn;
    private User user;
    private Announcements announcement;
    private Messages message;
    private Subjects subject;

    public registerSubject(JFrame parent, User user) {
        this.user = user;
        this.announcement = announcement;
        this.message = message;
        this.subject = subject;
        setTitle("Register to Subjects");
        setContentPane(subjectTable);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        if (!isEnrollmentPeriodOpen()) {
            displayEnrollmentPeriodClosedMessage();
            redirectToStudentMenu();
            return; // Stop further initialization
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });

        ListSelectionModel selectionModel = table_subjects.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table_subjects.getSelectedRow();
                    if (selectedRow != -1) {
                        String id = (String) table_subjects.getValueAt(selectedRow, 0);

                        subjectProfile profileWindow = new subjectProfile(null, user, id);
                        profileWindow.setVisible(true);
                    }
                }
            }
        });

        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerSubjects();
            }
        });


        populateTable();
    }

    private void populateTable() {
        // Define column names
        String[] columnNames = {"ID", "Subject Name", "Description", "Teacher", "Type", "Ects", "Year", "Semester"};

        // Initialize table model with column names
        DefaultTableModel model = (DefaultTableModel) table_subjects.getModel();
        model.setColumnIdentifiers(columnNames);
        for (int i = 0; i < table_subjects.getColumnCount(); i++) {
            Class<?> columnClass = table_subjects.getColumnClass(i);
            table_subjects.setDefaultEditor(columnClass, null);
        }

        try {
            Connection connection = DB_config.getConnection();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM subjects");

            // Iterate through the result set and add rows to the table
            while (resultSet.next()) {
                Object[] rowData = {
                        resultSet.getString("idsubjects"),
                        resultSet.getString("subject_name"),
                        resultSet.getString("subject_decription"),
                        resultSet.getString("teacher"),
                        resultSet.getString("type"),
                        resultSet.getInt("ects"),
                        resultSet.getInt("year"),
                        resultSet.getString("semester")

                };
                model.addRow(rowData);
            }

            // Close resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void registerSubjects() {
        DefaultTableModel model = (DefaultTableModel) table_subjects.getModel();
        int[] selectedRows = table_subjects.getSelectedRows();

        try {
            Connection connection = DB_config.getConnection();
            // Prepare statement to check user's eligibility
            PreparedStatement eligibilityCheckStatement = connection.prepareStatement("SELECT * FROM users WHERE username = ?");
            eligibilityCheckStatement.setString(1, user.getUsername());
            ResultSet userResult = eligibilityCheckStatement.executeQuery();
            userResult.next();
            int userYear = userResult.getInt("year");
            String userSemester = userResult.getString("semester");
            userResult.close();

            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO my_subjects (id_subject, subject_name, subject_description, teacher, student, grade, type, ects, year, semester) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            PreparedStatement preparedStatement1 = connection.prepareStatement("INSERT INTO my_progress_subjects (id_subject, subject_name, student, grade, type, ects) VALUES (?, ?, ?, ?, ?, ?)");
            PreparedStatement checkStatement = connection.prepareStatement("SELECT COUNT(*) FROM my_subjects WHERE id_subject = ? AND student = ?");

            checkStatement.setString(2, user.getUsername());

            for (int row : selectedRows) {
                String subjectId = (String) model.getValueAt(row, 0);
                checkStatement.setString(1, subjectId);

                ResultSet resultSet = checkStatement.executeQuery();
                resultSet.next();
                int count = resultSet.getInt(1);
                resultSet.close();

                // Check user's eligibility
                int subjectYear = (int) model.getValueAt(row, 6);
                String subjectSemester = (String) model.getValueAt(row, 7);
                if (userYear < subjectYear || !userSemester.equals(subjectSemester)) {
                    JOptionPane.showMessageDialog(this, "You can only register for subjects in your current year and semester.", "Eligibility Error", JOptionPane.ERROR_MESSAGE);
                    continue; // Skip registering this subject
                }

                if (count > 0) {
                    JOptionPane.showMessageDialog(this, "You are already registered for the subject: " + model.getValueAt(row, 1), "Already Registered", JOptionPane.WARNING_MESSAGE);
                    continue; // Skip registering this subject
                }

                // Register the subject
                preparedStatement.setString(1, (String) model.getValueAt(row, 0)); // ID
                preparedStatement.setString(2, (String) model.getValueAt(row, 1)); // Subject Name
                preparedStatement.setString(3, (String) model.getValueAt(row, 2)); // Description
                preparedStatement.setString(4, (String) model.getValueAt(row, 3)); // Teacher
                preparedStatement.setString(5, user.getUsername()); // Student
                preparedStatement.setInt(6, 0); // Grade
                System.out.println(model.getValueAt(row, 4));
                preparedStatement.setString(7, (String) model.getValueAt(row, 4)); // Type
                preparedStatement.setInt(8, (int) model.getValueAt(row, 5)); // ECTS
                preparedStatement.setInt(9, (int) model.getValueAt(row, 6)); // Year
                preparedStatement.setString(10, (String) model.getValueAt(row, 7)); // Semester
                preparedStatement.executeUpdate();

                preparedStatement1.setString(1, (String) model.getValueAt(row, 0)); // ID
                preparedStatement1.setString(2, (String) model.getValueAt(row, 1)); // Subject Name
                preparedStatement1.setString(3, user.getUsername()); // Student
                System.out.println(model.getValueAt(row, 4));
                preparedStatement1.setString(5, (String) model.getValueAt(row, 4)); // Type
                preparedStatement1.setInt(4, -1); // Grade
                preparedStatement1.setInt(6, (int) model.getValueAt(row, 5)); // ECTS
                preparedStatement1.executeUpdate();
            }

            // Close resources
            preparedStatement.close();
            preparedStatement1.close();
            checkStatement.close();
            connection.close();

            JOptionPane.showMessageDialog(this, "Subject registered successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean isEnrollmentPeriodOpen() {
        LocalDate today = LocalDate.now();
        try (Connection conn = DB_config.getConnection();
             PreparedStatement statement = conn.prepareStatement("SELECT tillDateSubjects FROM regulations");
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                Date tillDateSubjects = resultSet.getDate("tillDateSubjects");
                return tillDateSubjects.toLocalDate().isAfter(today);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void displayEnrollmentPeriodClosedMessage() {
        JOptionPane.showMessageDialog(this, "There is no open enrollment period for Subjects. You will be redirected to student Menu in 3 seconds.");
    }

    private void redirectToStudentMenu() {
        Timer timer = new Timer(2000, e -> {
            dispose();
            new studentMenuu(null, user);
        });
        timer.setRepeats(false);
        timer.start();
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
