import javax.swing.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public class Announcements {
    public int idannouncements;
    public String text;
    public String teacher_name;
    public String title;
    public String about;
    public String date;
    public String subject_id;

    public String getText() {
        return text;
    }
    public String getTeacher() {
        return teacher_name;
    }
    public String getAbout() {
        return about;
    }

    public String getSubject() {
        return subject_id;
    }
    public int getId() {
        return idannouncements;
    }

    public void displayAnnouncements(User user, List<String> textsAnnouncement, JList newsList) {
        try {
            Connection con = DB_config.getConnection();
            Statement statement = con.createStatement();

            String sqlStatement = "SELECT a.title, a.about, a.text, a.teacher_name, a.date FROM announcements a INNER JOIN my_subjects s ON a.subject_id = s.id_subject WHERE s.student = ?";

            PreparedStatement prepStatement = con.prepareStatement(sqlStatement);
            prepStatement.setString(1, user.username);
            ResultSet rs = prepStatement.executeQuery();

            DefaultListModel<String> modelAnnouncement = new DefaultListModel<>();
            StringBuilder textAnnouncement = new StringBuilder();
            while (rs.next()) {
                String Stext = rs.getString("a.text");
                String Steacher = rs.getString("a.teacher_name");
                String Stitle = rs.getString("a.title");
                String Sabout = rs.getString("a.about");
                String Sdate = rs.getString("a.date");
                // Format announcement
                textAnnouncement.append("<html>");
                textAnnouncement.append("From ").append(Steacher).append(": ").append(Stitle).append("<br>");
                textAnnouncement.append(Sabout).append("<br>");

                String StextSub = null;
                //if Announcement details > 20 don print the whole announcement
                if (Stext.length() > 20) {
                    StextSub = Stext.substring(0, 15) + "...";
                    textAnnouncement.append(StextSub).append("<br>");
                }
                else{
                    textAnnouncement.append(Stext).append("<br>");
                }
                textAnnouncement.append("On ").append(rs.getString("date")).append("<br><hr><br>");
                textAnnouncement.append("</html>");
                textsAnnouncement.add("<html> From " + Steacher + ": " + Stitle + " (" + Sabout + ")" + "<br>" + Stext + "<br>On: " + Sdate + "<br><hr></html>");

                modelAnnouncement.addElement(textAnnouncement.toString());
                textAnnouncement.setLength(0);
            }

            // Close database connection
            rs.close();
            statement.close();
            con.close();

            newsList.setModel(modelAnnouncement);

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch announcements from the database", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void loadAnnouncementDates(Map<LocalDate, String[]> announcementDetails) {
        String sql = "SELECT text, teacher_name, title, date, about FROM announcements WHERE date >= CURDATE() AND teacher_name = ?";
        try (Connection conn = DB_config.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, "admin");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                LocalDate date = rs.getDate("date").toLocalDate();
                String text = rs.getString("text");
                String admin = rs.getString("teacher_name");
                String title = rs.getString("title");
                String about = rs.getString("about");
                announcementDetails.put(date, new String[]{text, admin, title, about});
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
