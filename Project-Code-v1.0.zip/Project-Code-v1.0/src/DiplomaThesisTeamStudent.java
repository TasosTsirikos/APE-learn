import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;

public class DiplomaThesisTeamStudent extends JFrame{
    private JPanel coSharepanel;
    private JTree tree1;
    private JButton uploadFilesButton;
    private JButton messagesButton;
    private JButton enterCallButton;
    private JButton newBranchButton;
    private JTextField fileName;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JButton submitButton;
    private User user;
    private File selectedFile;
    private FilesCoShare fileManager;
    private String teamID;

    public DiplomaThesisTeamStudent(JFrame parent, User user, String teamID) {
        this.user = user;
        this.teamID = teamID;
        this.fileManager = new FilesCoShare(user, selectedFile, teamID);
        Branches branch = new Branches();
        setTitle("Diploma Thesis Co-Share");
        setContentPane(coSharepanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        branch.populateJTreeDT(tree1, teamID);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new studentMenuu(null, user);
            }
        });


        newBranchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                createNewBranch cnb = new createNewBranch(null, user, teamID);
                cnb.setVisible(true);
            }
        });

        uploadFilesButton.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int option = fileChooser.showOpenDialog(this);
            if (option == JFileChooser.APPROVE_OPTION) {
                selectedFile = fileChooser.getSelectedFile();
                fileManager.setSelectedFile(selectedFile);
                try {
                    String fileContent = new String(Files.readAllBytes(selectedFile.toPath()), StandardCharsets.UTF_8);
                    fileName.setText(selectedFile.getName());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error reading file: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        submitButton.addActionListener(e -> {
            String branchName = textField4.getText();
            if (!fileName.getText().trim().isEmpty() && !branchName.isEmpty()) {
                try {
                    byte[] fileContent = Files.readAllBytes(selectedFile.toPath());
                    String checkResult = fileManager.checkFile(selectedFile.getName(), fileContent);
                    if ("sameName".equals(checkResult)) {
                        Dialog sameName = new Dialog(DiplomaThesisTeamStudent.this, selectedFile, user, teamID);
                        sameName.showFileExistsDialog(branchName, fileContent);
                    } else if ("sameContent".equals(checkResult)) {
                        Dialog sameContent = new Dialog(DiplomaThesisTeamStudent.this, selectedFile, user, teamID);
                        sameContent.sameContentDialog(branchName, fileContent);
                    } else {
                        fileManager.insertFileIntoDatabaseDT(branchName, fileContent);
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please select a file and specify a branch.", "Error", JOptionPane.WARNING_MESSAGE);
            }
        });

        tree1.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    TreePath path = tree1.getPathForLocation(e.getX(), e.getY());
                    if (path != null) {
                        DefaultMutableTreeNode selectedNode = (DefaultMutableTreeNode) path.getLastPathComponent();
                        if (selectedNode.isLeaf()) {
                            Object userObject = selectedNode.getUserObject();
                            if (userObject instanceof String) {
                                String fileInfo = userObject.toString();
                                if (fileInfo.endsWith("KB)")) { // Simple check to identify file nodes
                                    openFileWithDesktopApp(fileInfo); // Method to extract file path and open
                                }
                            }
                        }
                    }
                }
            }
        });
    }

    private void openFileWithDesktopApp(String fileInfo) {
        String filePath = extractFilePath(fileInfo);
        File fileToOpen = new File(filePath);
        if (Desktop.isDesktopSupported()) {
            Desktop desktop = Desktop.getDesktop();
            try {
                desktop.open(fileToOpen);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Unable to open file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Desktop is not supported on this platform.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String extractFilePath(String fileInfo) {
        return "/path/to/file";
    }
}
