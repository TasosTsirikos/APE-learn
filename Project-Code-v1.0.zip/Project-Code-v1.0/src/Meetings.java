import java.sql.*;
import java.util.*;

public class Meetings {
    public void loadUserSubjectMeetings(User user, Map<String, List<String[]>> meetingDetails) {
        // SQL query to retrieve subjects for the user
        String subjectSql = "SELECT subject_name FROM my_subjects WHERE student = ?";
        // SQL query to retrieve meeting details based on subject names
        String meetingSql = "SELECT meetingsAbout, host, every1, startTime, endTime, status FROM meetings_schedule_subjects WHERE meetingsAbout = ?";

        Set<String> userSubjects = new HashSet<>();

        //collect all subjects related to the user
        try (Connection conn = DB_config.getConnection();
             PreparedStatement pstmtSubject = conn.prepareStatement(subjectSql)) {
            pstmtSubject.setString(1, user.getUsername());
            ResultSet rsSubject = pstmtSubject.executeQuery();
            while (rsSubject.next()) {
                userSubjects.add(rsSubject.getString("subject_name"));
            }
            rsSubject.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //fetch meeting details for each subject
        try (Connection conn = DB_config.getConnection();
             PreparedStatement pstmtMeeting = conn.prepareStatement(meetingSql)) {
            for (String subject : userSubjects) {
                pstmtMeeting.setString(1, subject);
                ResultSet rsMeeting = pstmtMeeting.executeQuery();
                while (rsMeeting.next()) {
                    String dayOfWeek = rsMeeting.getString("every1");
                    String meetingsAbout = rsMeeting.getString("meetingsAbout");
                    String host = rsMeeting.getString("host");
                    String startTime = rsMeeting.getString("startTime");
                    String endTime = rsMeeting.getString("endTime");
                    String status = rsMeeting.getString("status");

                    if (!meetingDetails.containsKey(dayOfWeek)) {
                        meetingDetails.put(dayOfWeek, new ArrayList<>());
                    }
                    meetingDetails.get(dayOfWeek).add(new String[] {meetingsAbout, host, startTime, endTime, status});
                }
                rsMeeting.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
