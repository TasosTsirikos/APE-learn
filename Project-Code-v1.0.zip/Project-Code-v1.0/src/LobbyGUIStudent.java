import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class LobbyGUIStudent extends JFrame{
    private JList list1;
    private JPanel lobbyPanel;
    private User user;

    public LobbyGUIStudent(JFrame parent, User user, String id) {
        this.user = user;
        Subjects subject = new Subjects();
        Lobby lobby = new Lobby();
        setTitle("Lobby...");
        setContentPane(lobbyPanel);

        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        lobby.addUserToLobby(user.getUsername(), id);

        // Update the JList with usernames
        lobby.updateLobbyList(list1);

        // Add window listener to remove the user when the window is closing
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                lobby.removeUserFromLobby(user.getUsername(), id);
                new userSubjectProfile(null, user, id);
            }
        });
        setVisible(true);
    }


}
