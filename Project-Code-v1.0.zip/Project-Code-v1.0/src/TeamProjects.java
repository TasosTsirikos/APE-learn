import javax.swing.*;
import java.sql.*;

public class TeamProjects {
    public boolean studentBelongsToTeam(String student, String projectName) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean belongsToTeam = false;
        try {
            conn = DB_config.getConnection();
            String sql = "SELECT * FROM teams_projects WHERE username = ? AND project_name = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, student);
            pstmt.setString(2, projectName);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(null, "This student already belongs to a team. You can't send a request.");
                belongsToTeam = true;
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }        }
        return belongsToTeam;
    }
}
