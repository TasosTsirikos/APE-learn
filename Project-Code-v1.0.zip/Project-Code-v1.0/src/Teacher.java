import javax.swing.*;
import java.sql.*;

public class Teacher extends User{
    public Teacher(String username) {
        super(username);
    }

    public String getUsername() {
        return super.getUsername();
    }

    public String getName() {
        return super.getName();
    }
    public String getType() {
        return super.getType();
    }
    public int getId() {
        return super.getId();
    }

    public void showTeacherInfo(JLabel nameLabel, JLabel emailLabel, JLabel usernameLabel, JLabel typeLabel, User user){
        try {
            Connection connection = DB_config.getConnection();
            Statement statement = connection.createStatement();

            // Execute query to get user information
            ResultSet resultSet = statement.executeQuery("SELECT name, email, username, type FROM users WHERE username = '" + user.username + "'");
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String userType = resultSet.getString("type");

                // Set retrieved information to the JLabels
                nameLabel.setText("Name: " + name);
                emailLabel.setText("Email: " + email);
                usernameLabel.setText("Username: " + user.username);
                typeLabel.setText("Type: " + userType);
            } else {
                JOptionPane.showMessageDialog(null, "User not found!");
            }

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to connect to the database.");
        }
    }
}
