import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class DiplomaThesisTeacher extends JFrame {
    private JTextField titleField;
    private JTextField descriptionField;
    private JButton addButton;
    private JButton searchButton;
    private JButton deleteButton;
    private JTable tableDT;
    private JPanel dtTeacher;
    private JScrollPane dtTable;
    private JTextField idField;
    private User user;

    public DiplomaThesisTeacher(JFrame parent, User user) {
        this.user = user;
        setTitle("My Diploma Thesis");
        setContentPane(dtTeacher);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        tableDT.setDefaultEditor(Object.class, null);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherMenuu(null, user);
            }
        });

        tableDT.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = tableDT.getSelectedRow();
                    if (selectedRow != -1) {
                        // Retrieve data from selected row
                        Object[] rowData = new Object[tableDT.getColumnCount()];
                        for (int i = 0; i < tableDT.getColumnCount(); i++) {
                            rowData[i] = tableDT.getValueAt(selectedRow, i);
                        }
                        // Open new window to display details
                        displayDetails(rowData);
                    }
                }
            }
        });

        deleteButton.addActionListener(e -> {
            String idToDelete = idField.getText();

            // Perform deletion
            try (Connection connection = DB_config.getConnection()) {
                String query = "DELETE FROM diploma_thesis WHERE id_diploma_thesis = ?";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setString(1, idToDelete);
                    int rowsAffected = statement.executeUpdate();
                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Record deleted successfully!");
                    } else {
                        JOptionPane.showMessageDialog(null, "No records found with the given ID.");
                    }
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error deleting record: " + ex.getMessage());
            }
            fetchAndPopulateTable();
        });

        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String title = titleField.getText();
                String description = descriptionField.getText();
                if (!title.isEmpty() && !description.isEmpty()) {
                    insertIntoDatabase(title, description, user.getName());
                    fetchAndPopulateTable();
                    titleField.setText("");
                    descriptionField.setText("");
                } else {
                    JOptionPane.showMessageDialog(DiplomaThesisTeacher.this, "Please fill in Title and Description fields.");
                }
            }
        });

        fetchAndPopulateTable();
    }

    private void fetchAndPopulateTable() {
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Title");
        model.addColumn("Description");
        model.addColumn("Student");
        model.addColumn("Date");

        try {
            Connection conn = DB_config.getConnection();
            String query = "SELECT id_diploma_thesis, title, description, student, assign_date FROM diploma_thesis WHERE teacher = ?";
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setString(1, user.getName());

            ResultSet resultSet = statement.executeQuery();

            // Populate the table model with the retrieved data
            while (resultSet.next()) {
                Object[] row = new Object[5];
                row[0] = resultSet.getInt("id_diploma_thesis");
                row[1] = resultSet.getString("title");
                row[2] = resultSet.getString("description");
                row[3] = resultSet.getString("student");
                row[4] = resultSet.getDate("assign_date");
                model.addRow(row);
            }

            // Close resources
            resultSet.close();
            statement.close();
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Set the table model
        tableDT.setModel(model);
    }

    private void displayDetails(Object[] rowData) {
        //new JFrame to display the details
        JFrame detailsFrame = new JFrame("Selected Item Details");
        detailsFrame.setSize(800, 400);
        detailsFrame.setLocationRelativeTo(this);

        // Create a JPanel to hold the details
        JPanel detailsPanel = new JPanel(new GridLayout(5, 1));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add JLabels with the details
        detailsPanel.add(new JLabel("ID: " + rowData[0]));
        detailsPanel.add(new JLabel("Title: " + rowData[1]));
        detailsPanel.add(new JLabel("Description: " + rowData[2]));
        detailsPanel.add(new JLabel("Student: " + rowData[3]));
        detailsPanel.add(new JLabel("Date: " + rowData[4]));

        // Add the details panel to the frame
        detailsFrame.add(detailsPanel);

        // Make the details frame visible
        detailsFrame.setVisible(true);
    }

    private void insertIntoDatabase(String title, String description, String teacher) {
        try (Connection connection = DB_config.getConnection()) {
            String query = "INSERT INTO diploma_thesis (title, description, teacher) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, title);
                statement.setString(2, description);
                statement.setString(3, teacher);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
