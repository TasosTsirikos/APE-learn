import com.sun.jna.Memory;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.GDI32;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef.HBITMAP;
import com.sun.jna.platform.win32.WinDef.HDC;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.platform.win32.WinDef.RECT;
import com.sun.jna.platform.win32.WinGDI;
import com.sun.jna.platform.win32.WinNT.HANDLE;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.DataBufferInt;
import java.awt.image.Kernel;

public class ScreenSharing extends JFrame {

    private JComboBox<String> comboBox1;
    private JPanel ScreenSharingPanel;
    private JLabel screenShareLabel;
    private User user;
    private Timer updateTimer;

    public ScreenSharing(JFrame parent, User user, String id) {
        ScreenCapture ss = new ScreenCapture();
        this.user = user;
        setTitle("Screen Sharing");
        setContentPane(ScreenSharingPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
        ss.populateWindows(comboBox1);

        comboBox1.addActionListener(e -> {
            if (updateTimer != null) {
                updateTimer.stop();
            }

            String selectedTitle = (String) comboBox1.getSelectedItem();
            HWND hWnd = ss.findWindowByTitle(selectedTitle);

            // Define the action to be performed at each timer tick
            ActionListener updateAction = new ActionListener() {
                public void actionPerformed(ActionEvent evt) {
                    BufferedImage capturedImage = captureWindow(hWnd);
                    if (capturedImage != null) {
                        BufferedImage sharpenedImage = applySharpeningFilter(capturedImage);

                        int targetWidth = 900;
                        int targetHeight = 650;
                        BufferedImage resizedImage = resizeImage(sharpenedImage, targetWidth, targetHeight);

                        // Now set the resized image as the icon of the label
                        ImageIcon icon = new ImageIcon(resizedImage);
                        screenShareLabel.setIcon(icon);
                    }
                }
            };

            // Set the timer to update every 100 milliseconds
            updateTimer = new Timer(100, updateAction);
            updateTimer.start();
        });


    }

    private BufferedImage captureWindow(HWND hWnd) {
        RECT bounds = new RECT();
        User32.INSTANCE.GetWindowRect(hWnd, bounds);

        int width = bounds.right - bounds.left;
        int height = bounds.bottom - bounds.top;

        // Check if the window has valid dimensions
        if (width <= 0 || height <= 0) {
            System.err.println("Window has invalid dimensions for capturing.");
            return null;
        }

        HDC windowDC = User32Extended.INSTANCE.GetWindowDC(hWnd);
        HDC blitDC = GDI32.INSTANCE.CreateCompatibleDC(windowDC);
        HBITMAP bitmap = GDI32.INSTANCE.CreateCompatibleBitmap(windowDC, width, height);
        HANDLE oldBitmap = GDI32.INSTANCE.SelectObject(blitDC, bitmap);
        User32Extended.INSTANCE.PrintWindow(hWnd, blitDC, 0);

        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        WinGDI.BITMAPINFO bmi = new WinGDI.BITMAPINFO();
        bmi.bmiHeader.biWidth = width;
        bmi.bmiHeader.biHeight = -height; // Flip the bitmap vertically
        bmi.bmiHeader.biPlanes = 1;
        bmi.bmiHeader.biBitCount = 32;
        bmi.bmiHeader.biCompression = WinGDI.BI_RGB;

        int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
        Pointer pixelPointer = new Memory(pixels.length * 4); // Integer is 4 bytes
        GDI32.INSTANCE.GetDIBits(blitDC, bitmap, 0, height, pixelPointer, bmi, WinGDI.DIB_RGB_COLORS);
        pixelPointer.read(0, pixels, 0, pixels.length);

        GDI32.INSTANCE.SelectObject(blitDC, oldBitmap);
        GDI32.INSTANCE.DeleteObject(bitmap);
        GDI32.INSTANCE.DeleteDC(blitDC);
        User32.INSTANCE.ReleaseDC(hWnd, windowDC);

        return image;
    }

    private BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        int originalWidth = originalImage.getWidth();
        int originalHeight = originalImage.getHeight();

        double ratio = Math.min((double) targetWidth / originalWidth, (double) targetHeight / originalHeight);

        int newWidth = (int) (originalWidth * ratio);
        int newHeight = (int) (originalHeight * ratio);

        // Create a new buffered image with transparency
        BufferedImage resizedImage = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics2D = resizedImage.createGraphics();

        // Improve rendering quality
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw the resized image
        graphics2D.drawImage(originalImage, 0, 0, newWidth, newHeight, null);
        graphics2D.dispose();

        return resizedImage;
    }

    private BufferedImage applySharpeningFilter(BufferedImage originalImage) {
        int width = originalImage.getWidth();
        int height = originalImage.getHeight();
        BufferedImage resultImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);

        float[] sharpen = new float[]{
                0.0f, -1.0f, 0.0f,
                -1.0f, 5.0f, -1.0f,
                0.0f, -1.0f, 0.0f
        };

        Kernel kernel = new Kernel(3, 3, sharpen);
        ConvolveOp op = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, null);
        op.filter(originalImage, resultImage);

        return resultImage;
    }

}
