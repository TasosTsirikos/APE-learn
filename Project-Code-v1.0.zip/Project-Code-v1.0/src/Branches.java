import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class Branches {
    public void populateJTreeDT(JTree tree1, String teamID) {
        String query = "SELECT b.branchName, b.parentBranchName, f.fileName, f.fileSize, f.dateUploaded, f.ownerUsername " +
                "FROM co_share_branch_diploma_thesis b " +
                "LEFT JOIN co_share_file_diploma_thesis f ON b.idbranch = f.branchId " +
                "WHERE b.teamId = ? ORDER BY b.branchName, f.dateUploaded";

        try (Connection conn = DB_config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, teamID);
            ResultSet rs = stmt.executeQuery();
            DefaultMutableTreeNode root = new DefaultMutableTreeNode("Thesis Branches");
            Map<String, DefaultMutableTreeNode> branches = new HashMap<>();

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            while (rs.next()) {
                String branchName = rs.getString("branchName");
                String parentBranchName = rs.getString("parentBranchName");
                String fileName = rs.getString("fileName");
                long fileSize = rs.getLong("fileSize");
                Timestamp dateUploaded = rs.getTimestamp("dateUploaded");
                String ownerUsername = rs.getString("ownerUsername");

                DefaultMutableTreeNode branchNode = branches.computeIfAbsent(branchName, k -> new DefaultMutableTreeNode(branchName));

                // Add files as child nodes if present
                if (fileName != null) {
                    String fileInfo = String.format("%s (%d KB, %s, %s)", fileName, fileSize / 1024,
                            dateUploaded != null ? sdf.format(dateUploaded) : "Unknown", ownerUsername);
                    branchNode.add(new DefaultMutableTreeNode(fileInfo));
                }

                if (parentBranchName == null || "No Parent (Main Branch)".equals(parentBranchName)) {
                    root.add(branchNode);
                } else {
                    branches.computeIfAbsent(parentBranchName, k -> new DefaultMutableTreeNode(parentBranchName)).add(branchNode);
                }
            }

            // Ensure all sub-branches are added under correct parents
            for (Map.Entry<String, DefaultMutableTreeNode> entry : branches.entrySet()) {
                String parentBranchName = entry.getKey();
                DefaultMutableTreeNode node = entry.getValue();

                if (node.getParent() == null) {  // If no parent set, it's a main branch
                    DefaultMutableTreeNode parent = branches.get(parentBranchName);
                    if (parent != null) {
                        parent.add(node);
                    } else {
                        root.add(node);  // Orphaned branches treated as main
                    }
                }
            }
            tree1.setModel(new DefaultTreeModel(root));
            tree1.validate();
            tree1.repaint();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
        }
    }

    public void populateJTree(JTree tree1, String teamID) {
        String query = "SELECT b.branchName, b.parentBranchName, f.fileName, f.fileSize, f.dateUploaded, f.ownerUsername " +
                "FROM co_share_branch_projects b " +
                "LEFT JOIN co_share_file_projects f ON b.idbranch = f.branchId " +
                "WHERE b.teamId = ? ORDER BY b.branchName, f.dateUploaded";

        try (Connection conn = DB_config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, teamID);
            ResultSet rs = stmt.executeQuery();
            DefaultMutableTreeNode root = new DefaultMutableTreeNode("Team Branches");
            Map<String, DefaultMutableTreeNode> branches = new HashMap<>();

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");

            while (rs.next()) {
                String branchName = rs.getString("branchName");
                String parentBranchName = rs.getString("parentBranchName");
                String fileName = rs.getString("fileName");
                long fileSize = rs.getLong("fileSize");
                Timestamp dateUploaded = rs.getTimestamp("dateUploaded");
                String ownerUsername = rs.getString("ownerUsername");

                DefaultMutableTreeNode branchNode = branches.computeIfAbsent(branchName, k -> new DefaultMutableTreeNode(branchName));

                // Add files as child nodes if present
                if (fileName != null) {
                    String fileInfo = String.format("%s (%d KB, %s, %s)", fileName, fileSize / 1024,
                            dateUploaded != null ? sdf.format(dateUploaded) : "Unknown", ownerUsername);
                    branchNode.add(new DefaultMutableTreeNode(fileInfo));
                }

                if (parentBranchName == null || "No Parent (Main Branch)".equals(parentBranchName)) {
                    root.add(branchNode);
                } else {
                    branches.computeIfAbsent(parentBranchName, k -> new DefaultMutableTreeNode(parentBranchName)).add(branchNode);
                }
            }

            // Ensure all sub-branches are added under correct parents
            for (Map.Entry<String, DefaultMutableTreeNode> entry : branches.entrySet()) {
                String parentBranchName = entry.getKey();
                DefaultMutableTreeNode node = entry.getValue();

                if (node.getParent() == null) {  // If no parent set, it's a main branch
                    DefaultMutableTreeNode parent = branches.get(parentBranchName);
                    if (parent != null) {
                        parent.add(node);
                    } else {
                        root.add(node);  // Orphaned branches treated as main
                    }
                }
            }
            tree1.setModel(new DefaultTreeModel(root));
            tree1.validate();
            tree1.repaint();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage());
        }
    }

}
