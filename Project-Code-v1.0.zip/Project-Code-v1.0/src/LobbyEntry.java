import java.util.Objects;

public class LobbyEntry {
    private String username;
    private String subjectId;

    public LobbyEntry(String username, String subjectId) {
        this.username = username;
        this.subjectId = subjectId;
    }

    public String getUsername() {
        return username;
    }

    public String getSubjectId() {
        return subjectId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        LobbyEntry that = (LobbyEntry) o;
        return username.equals(that.username) && subjectId.equals(that.subjectId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(username, subjectId);
    }

    @Override
    public String toString() {
        return username + " (" + subjectId + ")";
    }
}

