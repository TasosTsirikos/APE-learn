public class MeetingsDiplomaThesis extends Meetings{
}
