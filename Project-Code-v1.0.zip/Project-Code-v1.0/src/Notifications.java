import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Notifications {
    LocalDate tillDateBooks;
    LocalDate tillDateSubjects;
    public void checkNotification(JLabel bell, User user) {
        Regulations regulations = new Regulations();
        Regulations retrievedRegulations = regulations.retrieveRegulationDates();
        LocalDate tillDateSubjects = retrievedRegulations.getTillDateSubjects();
        LocalDate tillDateBooks = retrievedRegulations.getTillDateBooks();
        LocalDate today = LocalDate.now();

        long daysUntilDeadlineSubjects = ChronoUnit.DAYS.between(today, tillDateSubjects);
        long daysUntilDeadlineBooks = ChronoUnit.DAYS.between(today, tillDateBooks);

        ImageIcon bellIcon = new ImageIcon("src/notification.png");
        ImageIcon noNotificationIcon = new ImageIcon("src/bell.png");

        Requests requests = new Requests();
        String message = requests.checkRequests(user);
        System.out.println(message);

        if ((daysUntilDeadlineSubjects <= -2 || daysUntilDeadlineBooks <= -2) && message.equals("No processed requests for now")) {
            bell.setIcon(noNotificationIcon);
            bell.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    JOptionPane.showMessageDialog(null, "No emergency notifications for now.");
                }
            });
        } else if (today.isAfter(tillDateSubjects) && today.isAfter(tillDateBooks)) {
            bell.setIcon(bellIcon);
            bell.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    JOptionPane.showMessageDialog(null, "There is no open enrollment period for Books and Subjects");
                    bell.setIcon(noNotificationIcon);
                }
            });

        } else if (today.isAfter(tillDateSubjects)) {
            if ((daysUntilDeadlineBooks < 7) && !(today.isAfter(tillDateBooks))) {
                bell.setIcon(bellIcon);
                bell.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        JOptionPane.showMessageDialog(null, "There is no open enrollment period for Subjects. Also 1 week till closing system for Books!!");
                        bell.setIcon(noNotificationIcon);
                    }
                });

            }
        } else if (today.isAfter(tillDateBooks)) {
            if ((daysUntilDeadlineSubjects < 7) && !(today.isAfter(tillDateSubjects))) {
                bell.setIcon(bellIcon);
                bell.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        JOptionPane.showMessageDialog(null, "There is no open enrollment period for Books. Also 1 week till closing system for Subjects!!");
                        bell.setIcon(noNotificationIcon);
                    }
                });

            }
        } else if ((daysUntilDeadlineSubjects < 7) && (daysUntilDeadlineBooks < 7)) {
            bell.setIcon(bellIcon);
            bell.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    JOptionPane.showMessageDialog(null, "Less than 1 week till system close for Books and Subjects!");
                    bell.setIcon(noNotificationIcon);
                }
            });

        }else {
            bell.setIcon(noNotificationIcon);
            bell.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    JOptionPane.showMessageDialog(null, message);
                }
            });
        }
        bell.setIcon(noNotificationIcon);
    }


}
