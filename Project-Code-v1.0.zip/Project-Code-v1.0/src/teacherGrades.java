import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class teacherGrades extends JFrame{
    private JTextField idField;
    private JTextField writtenType;
    private JTextField writtenPer;
    private JTextField project1;
    private JTextField project1Per;
    private JTextField project2;
    private JTextField project2Per;
    private JButton addGradeButton;
    private JPanel gradePanel;
    private JTable gradeTable;
    private JLabel Labell;
    private JLabel addExam;
    private JLabel resultLabel;
    private JPanel newType;
    private JPanel newPer;
    private JPanel newProject;
    private JLabel gradeLabel;
    private JButton calculateButton;
    private User user;

    private String subjectName;
    public int count = 2;
    private ArrayList<JTextField> projectFields = new ArrayList<>();

    public teacherGrades(JFrame parent, User user, String id) {
        this.user = user;
        this.subjectName = fetchSubjectName(id);
        setTitle("Subject Grades");
        setContentPane(gradePanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        populateTable(id);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                new teacherSubjectProfile(null, user, id);
            }
        });

        Labell.setText("Grades for subject: " + subjectName);

        newProject.setLayout(new GridLayout(0, 1));
        newType.setLayout(new GridLayout(0, 1));
        newPer.setLayout(new GridLayout(0, 1));

        addExam.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                count++;


                JLabel label1 = new JLabel();
                label1.setText("Project " + count + ": ");

                label1.setHorizontalAlignment(SwingConstants.CENTER);

                JTextField textField1 = new JTextField();
                JTextField textField2 = new JTextField();

                textField1.setPreferredSize(new Dimension(300, 20));
                textField2.setPreferredSize(new Dimension(300, 20));

                projectFields.add(textField1);
                projectFields.add(textField2);

                Font textFieldFont = new Font("Arial Rounded MT Bold", Font.BOLD, 14);
                textField1.setFont(textFieldFont);
                label1.setFont(textFieldFont);
                textField2.setFont(textFieldFont);

                newProject.add(label1);
                newType.add(textField1);
                newPer.add(textField2);

                newType.revalidate();
                newType.repaint();
            }
        });

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Retrieve values from JTextFields
                    double writtenTypeValue = Double.parseDouble(writtenType.getText());
                    double writtenPerValue = Double.parseDouble(writtenPer.getText());

                    if (project1.getText().isEmpty()) {
                        project1.setText("0");
                        project1Per.setText("0");
                    }
                    double project1Value = Double.parseDouble(project1.getText());
                    double project1PerValue = Double.parseDouble(project1Per.getText());

                    if (project2.getText().isEmpty()) {
                        project2.setText("0");
                        project2Per.setText("0");
                    }
                    double project2Value = Double.parseDouble(project2.getText());
                    double project2PerValue = Double.parseDouble(project2Per.getText());

                    // Check if the sum of percentiles is equal to 1
                    if (Math.abs(writtenPerValue + project1PerValue + project2PerValue - 1.0) > 0.000001) {
                        JOptionPane.showMessageDialog(null, "The percentiles of the exams must have a total of 1.");
                        return;
                    }

                    // Perform calculation
                    double resultValue = (writtenTypeValue * writtenPerValue) + (project1Value * project1PerValue) + (project2Value * project2PerValue);

                    double totalProjectsValue = 0.0;

                    // Iterate through projectFields ArrayList to calculate total project score
                    for (int i = 0; i < projectFields.size(); i += 2) {
                        double projectValue = Double.parseDouble(projectFields.get(i).getText());
                        double projectPerValue = Double.parseDouble(projectFields.get(i + 1).getText());
                        totalProjectsValue += projectValue * projectPerValue;
                    }

                    double result = resultValue + totalProjectsValue;

                    // Format the result with two digits after the comma
                    DecimalFormat df = new DecimalFormat("##.##");
                    String formattedResult = df.format(result);

                    resultLabel.setText("Result: " + formattedResult);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Error: Invalid input");
                }
            }
        });

        addGradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addGrade(id);
            }
        });

    }

    private String fetchSubjectName(String id) {
        String subjectName = null;
        try {
            Connection connection = DB_config.getConnection();
            String query = "SELECT subject_name FROM subjects WHERE idsubjects = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                subjectName = resultSet.getString("subject_name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return subjectName;
    }

    private void populateTable(String id) {
        DefaultTableModel tableModel = new DefaultTableModel();

        tableModel.addColumn("Student ID");
        tableModel.addColumn("Student Name");
        tableModel.addColumn("Mark");

        try {
            Connection connection = DB_config.getConnection();
            String query = "SELECT student_id, student, mark FROM grades WHERE subject_id = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String studentID = resultSet.getString("student_id");
                String studentName = resultSet.getString("student");
                double mark = resultSet.getDouble("mark"); // Fetch the mark instead of idGrades

                // Add a row to the table model
                tableModel.addRow(new Object[]{studentID, studentName, mark});
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }

        gradeTable.setModel(tableModel);
        gradeTable.setDefaultEditor(Object.class, null);
    }

    private void addGrade(String id){
        try {
            // Get the current date
            Date currentDate = new Date(System.currentTimeMillis());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = dateFormat.format(currentDate);

            // Retrieve values needed for insertion
            String studentId = idField.getText();
            double mark = Double.parseDouble(resultLabel.getText().split(":")[1].trim());

            // Retrieve student name
            String studentName = fetchStudentName(studentId);

            // Insert into the grades table
            insertGrade(id, user.getUsername(), studentId, studentName, mark, formattedDate);

            populateTable(id);

            JOptionPane.showMessageDialog(null, "Grade added successfully!");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Error: Invalid input");
        }
    }

    private String fetchStudentName(String studentId) {
        String studentName = null;
        try {

            Connection connection = DB_config.getConnection();
            String query = "SELECT name FROM users WHERE id_users = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, studentId);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                studentName = resultSet.getString("name");
            }
            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return studentName;
    }

    private void insertGrade(String id, String teacher, String studentId, String studentName, double mark, String date) {
        try {
            Connection connection = DB_config.getConnection();
            String query = "INSERT INTO grades (subject_id, subjectName, teacher, student_id, mark, date, student) VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, id);
            preparedStatement.setString(2, subjectName);
            preparedStatement.setString(3, teacher);
            preparedStatement.setString(4, studentId);
            preparedStatement.setDouble(5, mark);
            preparedStatement.setString(6, date);
            preparedStatement.setString(7, studentName);
            preparedStatement.executeUpdate();

            preparedStatement.close();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

}
