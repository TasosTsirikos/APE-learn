import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class teacherSendMessage extends JFrame {
    private JPanel sendMessage;
    private JTextField recipientField;
    private JCheckBox toAll;
    private JCheckBox toAllTeachers;
    private JCheckBox toAllStudents;
    private JList inList;
    private JList outList;
    private JTextArea messageBody;
    private JPanel sendMessagePanel;
    private JButton sendButton;
    private JLabel titleLabel;
    private JTextField titleField;
    private JLabel attachFileIcon;
    private JList listFiles;
    private JScrollPane FilesNamesPanel;
    private User user;
    private DefaultListModel<String> listFilesModel;
    private List<FileAttachment> fileAttachments;
    public teacherSendMessage(JFrame parent, User user) {
        this.user = user;
        this.fileAttachments = new ArrayList<>();
        Messages messages = new Messages();
        setTitle("My Messages");
        setContentPane(sendMessagePanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                sendMessage();
                new teacherMenuu(null, user);
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new teacherMenuu(null, user);
            }
        });

        messages.showInMessages(user, inList);
        messages.showOutMessages(user, outList);

        attachFileIcon.setToolTipText("Attach no more than 2 files to the message");
        FilesNamesPanel.setPreferredSize(new Dimension(100, 50));

        listFilesModel = new DefaultListModel<>();
        listFiles.setModel(listFilesModel);

        attachFileIcon.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (listFilesModel.size() > 2) {
                    JOptionPane.showMessageDialog(teacherSendMessage.this, "You can only attach up to 2 files.");
                    return;
                }
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setMultiSelectionEnabled(true);
                int result = fileChooser.showOpenDialog(teacherSendMessage.this);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File[] selectedFiles = fileChooser.getSelectedFiles();
                    for (File file : selectedFiles) {
                        if (listFilesModel.size() <= 2) {
                            try {
                                FileAttachment attachment = new FileAttachment(file);
                                fileAttachments.add(attachment);
                                listFilesModel.addElement(attachment.getFileName());
                            } catch (IOException ex) {
                                JOptionPane.showMessageDialog(teacherSendMessage.this, "Error reading file: " + file.getName());
                            }                        } else {
                            JOptionPane.showMessageDialog(teacherSendMessage.this, "You can only attach up to 2 files.");
                            break;
                        }
                    }
                }
            }
        });
    }


    private void sendMessage() {
        if (fileAttachments.size() > 2) {
            JOptionPane.showMessageDialog(this, "You can only attach up to 2 files.");
            return;
        }

        String recipient = recipientField.getText().trim();
        String messageText = messageBody.getText();
        String title = titleField.getText();
        Date currentDate = Date.valueOf(LocalDate.now());

        if (recipient.isEmpty() && (!toAll.isSelected()) && (!toAllTeachers.isSelected()) && (!toAllStudents.isSelected())) {
            JOptionPane.showMessageDialog(this, "Please select a recipient.");
            return;
        }

        if (title.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please give a title to your message.");
            return;
        }

        if (messageText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your message doesn't have any body.");
            return;
        }

        try {
            Connection connection = DB_config.getConnection();
            String sql = "INSERT INTO my_messages (sender, recipient, message_text, title, date, archive_name1, archive_content1, archive_name2, archive_content2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);

            for (String recipientUsername : User.getRecipients(connection, user, toAll, toAllTeachers, toAllStudents, recipientField)) {
                preparedStatement.setString(1, user.getUsername());
                preparedStatement.setString(2, recipientUsername);
                preparedStatement.setString(3, messageText);
                preparedStatement.setString(4, title);
                preparedStatement.setDate(5, currentDate);

                if (fileAttachments.size() > 0) {
                    preparedStatement.setString(6, fileAttachments.get(0).getFileName());
                    preparedStatement.setBytes(7, fileAttachments.get(0).getFileContent());
                } else {
                    preparedStatement.setNull(6, Types.VARCHAR);
                    preparedStatement.setNull(7, Types.BLOB);
                }

                if (fileAttachments.size() > 1) {
                    preparedStatement.setString(8, fileAttachments.get(1).getFileName());
                    preparedStatement.setBytes(9, fileAttachments.get(1).getFileContent());
                } else {
                    preparedStatement.setNull(8, Types.VARCHAR);
                    preparedStatement.setNull(9, Types.BLOB);
                }

                preparedStatement.executeUpdate();
            }

            preparedStatement.close();
            connection.close();
            JOptionPane.showMessageDialog(this, "Message sent successfully!");
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending message: " + ex.getMessage());
        }
    }


}


