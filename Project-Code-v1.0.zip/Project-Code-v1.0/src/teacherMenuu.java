import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class teacherMenuu extends JFrame {
    private User user;
    private JLabel timeLabel;
    private JLabel nameLabel;
    private JLabel emailLabel;
    private JLabel usernameLabel;
    private JLabel typeLabel;
    private JPanel teacherPanel;
    private JList subjectList;
    private JList newsList;
    private JList messageList;
    private JScrollPane newsPanel;
    private JScrollPane messagePanel;
    private JToolBar jToolBarTeacher;
    private JScrollPane subjectPanel;
    private JButton editProfileButton;
    private JTable calendarTable;

    private JScrollPane calendarPanel;

    public teacherMenuu(JFrame parent, User user) {
        this.user = user;
        Calendar cal = new Calendar();
        Subjects subject = new Subjects();
        Teacher teacher = new Teacher(user.getUsername());
        setTitle("Teacher Menu");
        setContentPane(teacherPanel);

        subject.showTeacherSubjects(subjectList, user);
        teacher.showTeacherInfo(nameLabel, emailLabel, usernameLabel, typeLabel, user);

        newsPanel.setViewportView(newsList);
        subjectPanel.setViewportView(subjectList);
        messagePanel.setViewportView(messageList);

        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        cal.setupCalendar(calendarTable);

        JButton subjectsButton = new JButton("My Subjects");
        JButton dtTeamButton = new JButton("Diploma Thesis Teams");
        JButton editProfileButton = new JButton("Edit Profile");
        JButton sendMessageButton = new JButton("Send a Message");
        JButton dThesisButton = new JButton("Diploma Thesis");
        JButton logoutButton = new JButton("Logout");

        jToolBarTeacher.add(subjectsButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        jToolBarTeacher.add(dtTeamButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        jToolBarTeacher.add(sendMessageButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarTeacher.add(dThesisButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarTeacher.add(editProfileButton);
        jToolBarTeacher.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarTeacher.add(logoutButton);

        subjectsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                teacherSubjects subjects = new teacherSubjects(null, user);
                subjects.setVisible(true);
            }
        });

        sendMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                teacherSendMessage sendMessage = new teacherSendMessage(null, user);
                sendMessage.setVisible(true);
            }
        });

        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                teacherProfile profile = new teacherProfile(null, user);
                profile.setVisible(true);
            }
        });

        dThesisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                DiplomaThesisTeacher dtTeacher = new DiplomaThesisTeacher(null, user);
                dtTeacher.setVisible(true);
            }
        });

        dtTeamButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (checkUserHasTeam(user.getUsername())) {
                    promptForTeamID();
                } else {
                    JOptionPane.showMessageDialog(teacherMenuu.this, "You do not have any team for the diploma thesis.", "No Team Found", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login(null);
            }
        });

        Timer timer = new Timer(1000, e -> updateTime());
        timer.start();

        subjectList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Get the selected item from the subjectList
                    String selectedItem = (String) subjectList.getSelectedValue();

                    // Check if selectedItem is not null and contains "<br>"
                    if (selectedItem != null && selectedItem.contains("<br>")) {
                        // Extract the subject ID before "<br>"
                        String subjectId = selectedItem.substring(0, selectedItem.indexOf("<br>")).trim();
                        String idWithHtml = subjectId.split(":")[0].trim();
                        String id = idWithHtml.substring("<html>".length());
                        System.out.println(id);
                        String name = selectedItem.substring(1, selectedItem.indexOf("<br>")).trim();
                        System.out.println(name);
                        dispose();

                        // Open the teacherSubjectProfile panel with subject details
                        teacherSubjectProfile subjectProfile = new teacherSubjectProfile(null, user, id);
                        subjectProfile.setVisible(true);
                    }
                }
            }
        });
    }

    private void updateTime() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm:ss");
        String formattedDateTime = now.format(formatter);
        timeLabel.setText(formattedDateTime);
    }
    private void promptForTeamID() {
        // Create a JOptionPane to get the team ID from the teacher
        String teamID = JOptionPane.showInputDialog(this, "Enter your team ID:");

        if (teamID != null && !teamID.trim().isEmpty()) {
            validateTeamID(teamID.trim(), user.getUsername());
        } else {
            JOptionPane.showMessageDialog(this, "You must enter a team ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void validateTeamID(String teamID, String username) {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            Connection conn = DB_config.getConnection();
            String sql = "SELECT teacher FROM diplomaThesisTeams WHERE iddiplomaThesisTeams = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, teamID);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String teacher = rs.getString("teacher");
                if (teacher.equals(username)) {
                    dispose();
                    DiplomaThesisTeamTeacher dtTeam = new DiplomaThesisTeamTeacher(null, user, teamID);
                    dtTeam.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "You do not belong to this team.", "Access Denied", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Invalid team ID.", "Error", JOptionPane.ERROR_MESSAGE);
            }

            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error connecting to database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean checkUserHasTeam(String username) {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean hasTeam = false;
        try {
            Connection conn = DB_config.getConnection();
            String sql = "SELECT COUNT(*) AS count FROM diplomaThesisTeams WHERE teacher = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                hasTeam = rs.getInt("count") > 0;
            }

            if (rs != null) rs.close();
            if (pstmt != null) pstmt.close();
            if (conn != null) conn.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(teacherMenuu.this, "Error connecting to database.", "Database Error", JOptionPane.ERROR_MESSAGE);
        }
        return hasTeam;
    }

}
