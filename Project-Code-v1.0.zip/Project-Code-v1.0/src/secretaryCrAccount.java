import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class secretaryCrAccount extends JFrame{
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JCheckBox teacherCheckBox;
    private JCheckBox studentCheckBox;
    private JPanel secrCrAccPanel;
    private User user;

    public secretaryCrAccount(JFrame parent, User user) {
        this.user = user;
        setTitle("Admin Menu");
        setContentPane(secrCrAccPanel);
        setMinimumSize(new Dimension(1100, 700));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                new secretaryHome(null, user);
            }
        });

    }
}
