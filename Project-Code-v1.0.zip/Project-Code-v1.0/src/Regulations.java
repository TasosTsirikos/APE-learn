import java.sql.*;
import java.time.LocalDate;

public class Regulations {
    private LocalDate tillDateSubjects;
    private LocalDate tillDateBooks;

    public Regulations() {
    }

    public Regulations(LocalDate tillDateSubjects, LocalDate tillDateBooks) {
        this.tillDateSubjects = tillDateSubjects;
        this.tillDateBooks = tillDateBooks;
    }

    public LocalDate getTillDateSubjects() {
        return tillDateSubjects;
    }

    public LocalDate getTillDateBooks() {
        return tillDateBooks;
    }

    public Regulations retrieveRegulationDates() {
        LocalDate tillDateSubjects = null;
        LocalDate tillDateBooks = null;
        try {

            Connection con = DB_config.getConnection();
            Statement statement = con.createStatement();
            String sql = "SELECT tillDateSubjects, tillDateBooks FROM regulations";
            ResultSet res = statement.executeQuery(sql);

            if (res.next()) {
                Date tillDateSubjectsDB = res.getDate("tillDateSubjects");
                Date tillDateBooksDB = res.getDate("tillDateBooks");

                tillDateSubjects = ((java.sql.Date) tillDateSubjectsDB).toLocalDate();
                tillDateBooks = ((java.sql.Date) tillDateBooksDB).toLocalDate();
            }

            con.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return new Regulations(tillDateSubjects, tillDateBooks);
    }

    public boolean isEnrollmentPeriodOpen() {
        LocalDate today = LocalDate.now();
        try (Connection conn = DB_config.getConnection();
             PreparedStatement statement = conn.prepareStatement("SELECT tillDateDiplomaThesis FROM regulations");
             ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                Date tillDateSubjects = resultSet.getDate("tillDateDiplomaThesis");
                return tillDateSubjects.toLocalDate().isAfter(today);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
