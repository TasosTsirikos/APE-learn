import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.List;


public class studentMenuu extends JFrame{
    private JList newsList;
    private JLabel nameLabel;
    private JLabel emailLabel;
    private JLabel usernameLabel;
    private JLabel typeLabel;
    private JLabel timeLabel;
    private JPanel studentPanel;
    private JToolBar jToolBarStudent;
    private JList subjectList;
    private JScrollPane scrollNews;
    private JList messagesList;
    private JScrollPane scrollMessages;
    private JScrollPane scrollSubjects;
    private JScrollPane calendarPanel;
    private JTable calendarTable;
    private JLabel bell;
    private JLabel SM;
    private JLabel MR;
    private JLabel PD;
    private JLabel PR;

    private User user;

    public studentMenuu(JFrame parent, User user) {
        SystemApeLearn sal = new SystemApeLearn();
        Notifications not = new Notifications();
        Student st = new Student(user.getUsername());
        Subjects subject = new Subjects();
        Calendar cal = new Calendar();
        Announcements ann = new Announcements();
        Messages mess = new Messages();
        DiplomaThesis dt = new DiplomaThesis();
        this.user = user;
        setTitle("Student Menu");
        setContentPane(studentPanel);

        int dotSize = 8;
        SM.setIcon(new ColorDotIcon(Color.RED, dotSize));
        MR.setIcon(new ColorDotIcon(Color.GREEN, dotSize));
        PD.setIcon(new ColorDotIcon(Color.BLUE, dotSize));
        PR.setIcon(new ColorDotIcon(Color.BLACK, dotSize));

        scrollNews.setViewportView(newsList);
        scrollSubjects.setViewportView(subjectList);
        scrollMessages.setViewportView(messagesList);
        calendarPanel.setViewportView(calendarTable);

        st.showStudentInfo(user, usernameLabel, emailLabel, nameLabel, typeLabel);

        cal.drawCalendar(calendarTable, user);
        mess.showEMessages(user, messagesList, messageTexts);

        not.checkNotification(bell, user);
        subject.retrieveStudentSubjects(subjectList, user);

        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JButton registerButton = new JButton("Register to Subject");
        JButton sendMessageButton = new JButton("Send a Message");
        JButton findThesisButton = new JButton("Diploma Thesis");
        JButton myProgressButton = new JButton("My Progress");
        JButton editProfileButton = new JButton("My Profile");
        JButton logoutButton = new JButton("Logout");

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                registerSubject registrationWindow = new registerSubject(null, user);
                registrationWindow.setVisible(true);
            }
        });

        editProfileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                myProfile profile = new myProfile(null, user);
                profile.setVisible(true);
            }
        });

        sendMessageButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                studentSendMessage sendMessage = new studentSendMessage(null, user);
                sendMessage.setVisible(true);
            }
        });

        myProgressButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                myProgress myProgressWindow = new myProgress(null, user);
                myProgressWindow.setVisible(true);
            }
        });

        jToolBarStudent.add(registerButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL)); // Add separator
        jToolBarStudent.add(sendMessageButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(findThesisButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(myProgressButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(editProfileButton);
        jToolBarStudent.add(new JSeparator(SwingConstants.VERTICAL));
        jToolBarStudent.add(logoutButton);

        findThesisButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String teamID = dt.getDiplomaThesisTeamID(user.getUsername());
                if (teamID != null) {
                    System.out.println("You have a team! Moving to CoShare.");
                    dispose();
                    DiplomaThesisTeamStudent dtTeamOpener = new DiplomaThesisTeamStudent(null, user, teamID);
                    dtTeamOpener.setVisible(true);
                } else {
                    dispose();
                    DiplomaThesisStudent dtOpener = new DiplomaThesisStudent(null, user);
                    dtOpener.setVisible(true);
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose();
                new Login(null);
            }
        });

        // Create a Timer to update the time label every second
        Timer timer = new Timer(1000, e -> sal.updateTime(timeLabel));
        timer.start();

        setContentPane(studentPanel);
        ann.displayAnnouncements(user, announcementTexts, newsList);

        newsList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Retrieve the selected announcement
                    int selectedIndex = newsList.getSelectedIndex();
                    if (selectedIndex != -1) {
                        // Display the full announcement text in detailsFrame
                        dispose();
                        showAnnouncementDetails(announcementTexts.get(selectedIndex));
                    }
                }
            }
        });

        messagesList.addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Retrieve the selected announcement
                    int selectedIndex = messagesList.getSelectedIndex();
                    if (selectedIndex != -1) {
                        // Display the full announcement text in detailsFrame
                        showMessageDetails(messageTexts.get(selectedIndex));
                    }
                }
            }
        });

        subjectList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    // Get the selected subject
                    String selectedValue = (String) subjectList.getSelectedValue();
                    String idWithHtml = selectedValue.split(":")[0].trim();
                    String id = idWithHtml.substring("<html>".length());
                    System.out.println(id);
                    dispose();
                    JFrame profileFrame = new userSubjectProfile(null, user, id);
                    profileFrame.setVisible(true);
                }
            }
        });

        setVisible(true);
    }



    private List<String> announcementTexts = new ArrayList<>();


    private void showAnnouncementDetails(String announce) {
        dispose();
        JFrame detailsFrame = new JFrame("Announcement Details");
        JEditorPane detailsPane = new JEditorPane();
        detailsPane.setContentType("text/html");
        detailsPane.setEditable(false);
        detailsPane.setText(announce);
        JScrollPane scrollPane = new JScrollPane(detailsPane);

        detailsFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                detailsFrame.dispose();
                new studentMenuu(null, user);
            }
        });

        detailsFrame.add(scrollPane);
        detailsFrame.setSize(500, 400);
        detailsFrame.setLocationRelativeTo(this);
        detailsFrame.setVisible(true);
    }

    private void showMessageDetails(String announce) {
        dispose();
        JFrame detailsFrame = new JFrame("Message Details");
        JEditorPane detailsPane = new JEditorPane();
        detailsPane.setContentType("text/html");
        detailsPane.setEditable(false);
        detailsPane.setText(announce);
        JScrollPane scrollPane = new JScrollPane(detailsPane);

        detailsFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                detailsFrame.dispose();
                new studentMenuu(null, user);
            }
        });

        detailsFrame.add(scrollPane);
        detailsFrame.setSize(500, 400);
        detailsFrame.setLocationRelativeTo(this);
        detailsFrame.setVisible(true);
    }

    private List<String> messageTexts = new ArrayList<>();


}
