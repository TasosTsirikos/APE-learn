import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.time.LocalDate;

public class Reminder {
    public void handleReminderInput(LocalDate date, JTable calendarTable, User user) {
        // Create a JPanel to hold input fields
        JPanel panel = new JPanel(new GridLayout(0, 1));
        JTextField titleField = new JTextField(10);
        JTextArea textArea = new JTextArea(5, 10);

        panel.add(new JLabel("Title:"));
        panel.add(titleField);
        panel.add(new JLabel("Text:"));
        panel.add(new JScrollPane(textArea));

        // Show the dialog
        int result = JOptionPane.showConfirmDialog(calendarTable, panel, "Set Reminder for " + date.toString(),
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            String title = titleField.getText();
            String text = textArea.getText();

            insertReminderIntoDatabase(user.getUsername(), title, text, date, calendarTable, user);
        }
    }

    private void insertReminderIntoDatabase(String username, String title, String text, LocalDate date, JTable calendarTable, User user) {
        String sql = "INSERT INTO reminders (username, remindersTitle, remindersText, date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DB_config.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            pstmt.setString(2, title);
            pstmt.setString(3, text);
            pstmt.setDate(4, java.sql.Date.valueOf(date)); // Convert LocalDate to sql.Date

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(calendarTable, "Reminder saved successfully.");
                Calendar cal = new Calendar();
                cal.drawCalendar(calendarTable, user);
            } else {
                JOptionPane.showMessageDialog(calendarTable, "Failed to save the reminder.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(calendarTable, "Error while saving the reminder: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}
