import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DiplomaThesisApplications {
    public void insertDiplomaThesisApplication(String student, String date, String title, String teacher) {


        try (Connection connection = DB_config.getConnection()) {
            String query = "INSERT INTO diploma_thesis_applications (student, date, dt_title, teacher) VALUES (?, ?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, student);
                preparedStatement.setString(2, date);
                preparedStatement.setString(3, title);
                preparedStatement.setString(4, teacher);
                preparedStatement.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean isTopicAssignedToAnotherStudent(String title, String student) {
        boolean isAssigned = false;

        try (Connection connection = DB_config.getConnection()) {
            String query = "SELECT COUNT(*) FROM diploma_thesis_applications WHERE dt_title = ? AND student <> ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, title);
                preparedStatement.setString(2, student);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        isAssigned = resultSet.getInt(1) > 0;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return isAssigned;
    }
}
