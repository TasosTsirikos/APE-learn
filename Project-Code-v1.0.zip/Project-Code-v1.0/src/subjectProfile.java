import javax.swing.*;
import java.sql.*;

public class subjectProfile extends JFrame {
    private JLabel subjectTitle;
    private JTextField teacherField;
    private JPanel subjectDetails;
    private JTextField infoField;
    private JLabel ectsField;

    private User user;

    public subjectProfile(JFrame parent, User user, String id) {
        this.user = user;
        setTitle("Subject Details");
        setContentPane(subjectDetails);

        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        teacherField.setEditable(false);
        teacherField.setFocusable(false);
        infoField.setEditable(false);
        infoField.setFocusable(false);
        displaySubjectInfo(id);
        setVisible(true);
    }

    private void displaySubjectInfo(String id) {

        // SQL query to retrieve subject information
        String query = "SELECT subject_name, subject_decription, teacher, type, ects, year, semester FROM subjects WHERE idsubjects = ?";

        try (Connection connection = DB_config.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if a record is found
            if (resultSet.next()) {
                String subjectName = resultSet.getString("subject_name");
                String subjectDescription = resultSet.getString("subject_decription");
                String teacher = resultSet.getString("teacher");
                String type = resultSet.getString("type");
                int ects = resultSet.getInt("ects");
                int year = resultSet.getInt("year");
                String semester = resultSet.getString("semester");

                // Format the information
                String subjectTitleText = id + ": " + subjectName + " (" + type + ")";
                String teacherFieldText = "Professor: " + teacher;
                String infoTextField = null;
                if(type.equals("obligatory")){
                    infoTextField = "Info: The subject is taught on the " + year + " year in " + semester + " semester. " + subjectDescription;
                }else {
                    infoTextField = "Info: The subject is taught in " + semester + " semester. " + subjectDescription;
                }

                String ectsText = "Ects: " + ects;

                // Set the text to the components
                subjectTitle.setText(subjectTitleText);
                teacherField.setText(teacherFieldText);
                infoField.setText(infoTextField);
                ectsField.setText(ectsText);
            } else {
                // No record found for the given ID
                JOptionPane.showMessageDialog(this, "Subject not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
    }
}