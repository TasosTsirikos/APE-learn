import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;

public class myProfile extends JFrame{
    private JPanel profilePanel;
    private JTextField nameField;
    private JTextField emailField;
    private JTextField usernameField;
    private JTextField yearField;
    private JTextField semesterField;
    private JButton uploadButton;
    private JButton saveButton;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JLabel imagePhoto;
    private JLabel confirmLabel;
    private User user;

    public String uploadedPhotoName;
    public byte[] uploadedPhotoContent;


    public myProfile(JFrame parent, User user) {
        this.user = user;

        setTitle("My Profile");
        setContentPane(profilePanel);
        setMinimumSize(new Dimension(1300, 800));
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setVisible(true);

        yearField.setEditable(false);
        semesterField.setEditable(false);

        uploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                uploadImage();
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                Announcements announcement = null;
                Messages message = null;
                new studentMenuu(null, user);
            }
        });


        passwordField1.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateConfirmLabel();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateConfirmLabel();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateConfirmLabel();
            }
        });

        passwordField2.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                updateConfirmLabel();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                updateConfirmLabel();
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                updateConfirmLabel();
            }
        });

        populateFields();

        saveButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveProfile();
            }
        });

    }

    private void populateFields() {
        try {
            Connection connection = DB_config.getConnection();
            String query = "SELECT username, password, name, email, year, semester, photo, photo_name FROM users WHERE username = '" + user.username + "'";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                usernameField.setText(resultSet.getString("username"));
                passwordField1.setText(resultSet.getString("password"));
                nameField.setText(resultSet.getString("name"));
                emailField.setText(resultSet.getString("email"));
                yearField.setText(resultSet.getString("year"));
                semesterField.setText(resultSet.getString("semester"));

                byte[] photoBytes = resultSet.getBytes("photo");
                String photoName = resultSet.getString("photo_name");

                // Update public variables with retrieved photo content and name
                uploadedPhotoContent = photoBytes;
                uploadedPhotoName = photoName;

                // Set the photo as the icon of the photoPatient JLabel
                if (photoBytes != null) {
                    ImageIcon icon = new ImageIcon(photoBytes);
                    // Resize the image to 64x64 pixels
                    Image image = icon.getImage();
                    Image resizedImage = image.getScaledInstance(64, 64, Image.SCALE_SMOOTH);
                    ImageIcon resizedIcon = new ImageIcon(resizedImage);
                    imagePhoto.setIcon(resizedIcon);
                }else{
                    ImageIcon defaultIcon = new ImageIcon(getClass().getResource("/profile.png"));
                    imagePhoto.setIcon(defaultIcon);
                }
            }

            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void uploadImage() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Choose a photo");
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        // Add file filters for supported image file types
        FileNameExtensionFilter filter = new FileNameExtensionFilter("Image Files", "png", "jpeg", "jpg", "svg");
        fileChooser.setFileFilter(filter);

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            // User selected a file
            File selectedFile = fileChooser.getSelectedFile();
            String filePath = selectedFile.getPath();
            String extension = getFileExtension(filePath);

            // Check if the selected file has a supported extension
            if ("png".equals(extension) || "jpeg".equals(extension) || "jpg".equals(extension) || "svg".equals(extension)) {
                uploadedPhotoName = selectedFile.getName();
                uploadedPhotoContent = getPhotoBytes(selectedFile);

                // Load the selected image and resize it to 64x64 pixels
                ImageIcon icon = new ImageIcon(filePath);
                Image image = icon.getImage();
                Image resizedImage = image.getScaledInstance(64, 64, Image.SCALE_SMOOTH);
                ImageIcon resizedIcon = new ImageIcon(resizedImage);

                // Set the resized image as the icon of the JLabel
                imagePhoto.setIcon(resizedIcon);
            } else {
                // Display message indicating unsupported file extension
                JOptionPane.showMessageDialog(this, "You can only upload .png, .jpeg, .jpg, or .svg files.");
            }
        }
    }

    private byte[] getPhotoBytes(File photoFile) {
        byte[] photoBytes = null;
        try (FileInputStream fis = new FileInputStream(photoFile);
             ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            byte[] buf = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buf)) != -1) {
                bos.write(buf, 0, bytesRead);
            }
            photoBytes = bos.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return photoBytes;
    }


    // Helper method to extract file extension
    private String getFileExtension(String filePath) {
        int dotIndex = filePath.lastIndexOf('.');
        if (dotIndex > 0 && dotIndex < filePath.length() - 1) {
            return filePath.substring(dotIndex + 1).toLowerCase();
        }
        return "";
    }

    private void updateConfirmLabel() {
        String password1 = new String(passwordField1.getPassword());
        String password2 = new String(passwordField2.getPassword());
        if (password1.equals(password2)) {
            confirmLabel.setText("Same Passwords");
        } else {
            confirmLabel.setText("Different Passwords");
        }
    }

    private void saveProfile() {
        String username = usernameField.getText();
        String password = new String(passwordField1.getPassword());
        String name = nameField.getText();
        String email = emailField.getText();
        ImageIcon icon = (ImageIcon) imagePhoto.getIcon();

        // Check if passwords match
        if (!confirmLabel.getText().equals("Same Passwords")) {
            JOptionPane.showMessageDialog(myProfile.this, "Your passwords don't match. Cannot continue to update profile.");
            return; // Stop execution
        }



        try {
            Connection connection = DB_config.getConnection();
            String newUsername = usernameField.getText();
            PreparedStatement checkStatement = connection.prepareStatement("SELECT * FROM users WHERE username=?");
            checkStatement.setString(1, newUsername);
            ResultSet resultSet = checkStatement.executeQuery();

            if (resultSet.next()) {
                // Username already exists
                JOptionPane.showMessageDialog(myProfile.this, "This username is already used by someone. Please change it.");
            } else {

                try {
                    String sql = "UPDATE users SET username = ?, password = ?, name = ?, email = ?, photo = ?, photo_name = ? WHERE username = ?";
                    PreparedStatement statement = connection.prepareStatement(sql);
                    statement.setString(1, username);
                    statement.setString(2, password);
                    statement.setString(3, name);
                    statement.setString(4, email);

                    if (uploadedPhotoContent != null && uploadedPhotoName != null) {
                        statement.setBytes(5, uploadedPhotoContent);
                        statement.setString(6, uploadedPhotoName);
                    } else {
                        statement.setNull(5, Types.BLOB);
                        statement.setNull(6, Types.VARCHAR);
                    }

                    statement.setString(7, user.username);
                    // Execute update
                    int rowsUpdated = statement.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(myProfile.this, "Profile updated successfully. You will be redirected to Login Page!");
                        dispose();
                        new Login(null);
                    } else {
                        JOptionPane.showMessageDialog(myProfile.this, "Failed to update profile");
                    }
                    // Close connection
                    connection.close();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(myProfile.this, "Error: " + ex.getMessage());
                }
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private byte[] imageToByteArray (ImageIcon icon){
        Image image = icon.getImage();
        BufferedImage bufferedImage = new BufferedImage(image.getWidth(null), image.getHeight(null), BufferedImage.TYPE_INT_RGB);
        Graphics g = bufferedImage.createGraphics();
        g.drawImage(image, 0, 0, null);
        g.dispose();

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(bufferedImage, "jpg", baos);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return baos.toByteArray();
    }
}
