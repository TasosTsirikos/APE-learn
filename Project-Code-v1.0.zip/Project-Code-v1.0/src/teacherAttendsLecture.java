import org.opencv.core.Core;
import org.opencv.videoio.VideoCapture;

import javax.sound.sampled.TargetDataLine;
import javax.swing.*;
import java.awt.event.*;

public class teacherAttendsLecture extends JFrame{
    private JPanel attendingPanel;
    private JLabel titleAttending;
    private JLabel cameraLabel;
    private JLabel leaveCall;
    private JLabel shareScreenLabel;
    private JLabel microphoneLabel;
    private JButton showParticipantsButton;
    private JPanel chatPanel;
    private JPanel speakerPanel;
    private JLabel speakerLabel;
    private JScrollPane participantsPanel;
    private JButton lobbyButton;
    private User user;

    private String subjectName;

    private final Object cameraLock = new Object();
    private final Object microphoneLock = new Object();
    TargetDataLine line;
    private VideoCapture capture;

    public teacherAttendsLecture(JFrame parent, User user, String id) {
        this.user = user;
        Camera camera = new Camera(cameraLabel, speakerLabel);
        Microphone microphone = new Microphone(microphoneLabel);
        Subjects subject = new Subjects();
        this.subjectName = subject.fetchSubjectName(id);
        setTitle("Subject Details");
        setContentPane(attendingPanel);
        setSize(1300, 800);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                camera.releaseCamera();
                microphone.releaseMicrophone();
                new teacherSubjectProfile(null, user, id);
            }
        });

        titleAttending.setText(user.getName() + " attends for subject: " + subjectName);


        lobbyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new LobbyGUITeacher(null, user, id);
            }
        });

        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

        int response = JOptionPane.showConfirmDialog(this,
                "This application needs to access your camera and microphone. Do you agree?",
                "Camera and Microphone Access",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE);

        if (response != JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Access denied. Returning to Subject Profile.");
            dispose();
            new teacherSubjectProfile(null, user, id);
        }else {
            camera.openCamera();
        }

        cameraLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (capture != null && capture.isOpened()) {
                    camera.releaseCamera();
                } else {
                    camera.openCamera();
                }
            }
        });


        leaveCall.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to leave the call?", "Leave Call", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (capture != null && capture.isOpened()) {
                        camera.releaseCamera();
                        microphone.releaseMicrophone();
                    }
                    dispose();
                    new teacherSubjectProfile(null, user, id);
                }
            }
        });

        microphoneLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                if (line != null && line.isOpen()) {
                    microphone.releaseMicrophone();
                } else {
                    microphone.openMicrophone();
                }
            }
        });

        shareScreenLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                new ScreenSharing(null, user, id);
            }
        });
    }
}
