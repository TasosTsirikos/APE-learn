import javax.swing.*;
import java.sql.*;

public class Student extends User{
    public Student(String username) {
        super(username);
    }

    public String getUsername() {
        return super.getUsername();
    }

    public String getName() {
        return super.getName();
    }
    public String getType() {
        return super.getType();
    }
    public int getId() {
        return super.getId();
    }
    public void showStudentInfo(User user, JLabel usernameLabel, JLabel emailLabel, JLabel nameLabel, JLabel typeLabel){
        try {
            Connection con = DB_config.getConnection();
            Statement statement = con.createStatement();

            String sql = "SELECT name, email, username, type FROM users WHERE username = '" + user.username + "'";
            // execute the query to retrieve user information
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                String name = resultSet.getString("name");
                String email = resultSet.getString("email");
                String userType = resultSet.getString("type");

                // set retrieved information to the labels
                nameLabel.setText("Name: " + name);
                emailLabel.setText("Email: " + email);
                usernameLabel.setText("Username: " + user.username);
                typeLabel.setText("Type: " + userType);
            } else {
                JOptionPane.showMessageDialog(null, "User not found!");
            }

            resultSet.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: Unable to connect to the database.");
        }
    }
}
