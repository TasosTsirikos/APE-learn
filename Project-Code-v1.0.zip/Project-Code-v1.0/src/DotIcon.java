import javax.swing.*;
import java.awt.*;

class DotIcon implements Icon {
    private final Color color;

    public DotIcon(Color color) {
        this.color = color;
    }

    @Override
    public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        int diameter = 6;
        g.fillOval(x + c.getWidth() - 10 - diameter, y + 2, diameter, diameter);  // Draw the dot in the upper right corner
    }

    @Override
    public int getIconWidth() {
        return 6;
    }

    @Override
    public int getIconHeight() {
        return 6;
    }
}